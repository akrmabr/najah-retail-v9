import { db, getPharmacyId } from './db';
import { now, uid } from '../utils/ids';
import { STORAGE_KEYS } from './storageKeys';

function safeMessage(error: unknown) {
  if (error instanceof Error) return error.message.slice(0, 1000);
  return String(error || 'unknown_error').slice(0, 1000);
}

export async function logCrash(error: unknown, action?: string) {
  try {
    const settings = await db.settings.get('settings');
    let userId: string | undefined;
    try { userId = JSON.parse(localStorage.getItem(STORAGE_KEYS.session) || '{}')?.userId; }
    catch { userId = undefined; }
    await db.crash_reports.add({
      id: uid('crash'), pharmacy_id: getPharmacyId(), user_id: userId,
      device: navigator.userAgent.slice(0, 500),
      os: navigator.platform || 'unknown',
      app_version: String(import.meta.env.VITE_APP_VERSION || '1.0.0'),
      activity: String(settings?.business_type || ''),
      page: `${location.pathname}${location.hash}`,
      action, message: safeMessage(error),
      stack: error instanceof Error ? String(error.stack || '').slice(0, 5000) : undefined,
      created_at: now(),
    });
  } catch {
    // Crash reporting must never cause a second application failure.
  }
}