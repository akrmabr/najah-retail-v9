import { getCachedLicense } from './license';
export async function setupRemoteBusiness(input: { name: string; ownerName: string; email: string; phone?: string; password: string; businessTypeId: string }) {
  const endpoint = String(localStorage.getItem('alshifaa_license_endpoint') || '').replace(/\/+$/, '');
  const license = getCachedLicense();
  if (!endpoint || !license?.license_key) throw new Error('بيانات التفعيل غير موجودة. أعد تفعيل الترخيص قبل إنشاء النشاط.');
  let response: Response;
  try { response = await fetch(`${endpoint}/functions/v1/setup-business`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ licenseKey: license.license_key, businessTypeId: input.businessTypeId, name: input.name, ownerName: input.ownerName, email: input.email, phone: input.phone || '', password: input.password }) }); } catch { throw new Error('تعذر الاتصال بخادم إعداد النشاط.'); }
  const data: any = await response.json().catch(() => null);
  if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'تعذر إنشاء النشاط على الخادم.');
  return data as { ok: true; user_id: string; business_id: string };
}
