export const now=()=>new Date().toISOString();
// PostgreSQL entities use UUID primary keys. The optional prefix is kept for call-site compatibility but is not added to the value.
export const uid=(_p='id')=>crypto.randomUUID();
export const today=()=>new Date().toISOString().slice(0,10);
export const money=(n:number,c='ج.س')=>`${Number(n||0).toFixed(2)} ${c}`;
export const dateDaysFromNow=(days:number)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
