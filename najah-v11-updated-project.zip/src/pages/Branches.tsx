import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import type { User } from '../types/models';
import { cancelTransfer, createBranch, createTransfer, receiveTransfer, sendTransfer, switchBranch } from '../services/branches';

export default function Branches({ user }: { user: User }) {
  const branches = useLiveQuery(() => db.branches.toArray(), []) || [];
  const batches = useLiveQuery(() => db.batches.toArray(), []) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const transfers = useLiveQuery(() => db.stock_transfers.orderBy('created_at').reverse().toArray(), []) || [];
  const settings = useLiveQuery(() => db.settings.get('settings'), []);
  const [branch, setBranch] = useState({ name: '', code: '', address: '', phone: '' });
  const [form, setForm] = useState({ from: '', to: '', batch: '', quantity: '1', notes: '' });
  const [message, setMessage] = useState('');
  async function addBranch(event: React.FormEvent) {
    event.preventDefault();
    try { await createBranch(user, branch); setBranch({ name: '', code: '', address: '', phone: '' }); setMessage('تم إنشاء الفرع.'); }
    catch (error: any) { setMessage(error.message); }
  }
  async function addTransfer(event: React.FormEvent) {
    event.preventDefault();
    try {
      await createTransfer(user, form.from, form.to, form.batch, Number(form.quantity), form.notes);
      setForm({ from: '', to: '', batch: '', quantity: '1', notes: '' });
      setMessage('تم إنشاء التحويل كمسودة. راجعه ثم أرسله.');
    } catch (error: any) { setMessage(error.message); }
  }
  const sourceBatches = batches.filter((batch) => !form.from || batch.branch_id === form.from || (!batch.branch_id && settings?.branch_id === form.from));
  return (
    <section>
      <h1>الفروع وتحويل المخزون</h1>
      {message && <div className="alert">{message}</div>}
      <div className="grid two">
        <form className="card formgrid" onSubmit={addBranch}><h3>إضافة فرع</h3>
          <input required value={branch.name} onChange={(event) => setBranch({ ...branch, name: event.target.value })} placeholder="اسم الفرع" />
          <input required value={branch.code} onChange={(event) => setBranch({ ...branch, code: event.target.value })} placeholder="رمز الفرع" />
          <input value={branch.address} onChange={(event) => setBranch({ ...branch, address: event.target.value })} placeholder="العنوان" />
          <input value={branch.phone} onChange={(event) => setBranch({ ...branch, phone: event.target.value })} placeholder="الهاتف" />
          <button>إنشاء الفرع</button>
        </form>
        <div className="card"><h3>الفرع المستخدم على هذا الجهاز</h3>
          <select value={settings?.branch_id || ''} onChange={(event) => switchBranch(user, event.target.value)}>
            <option value="">اختر الفرع</option>{branches.filter((row) => row.active).map((row) => <option key={row.id} value={row.id}>{row.name} — {row.code}</option>)}
          </select>
          <p className="muted">المبيعات والمشتريات الجديدة ستُسجل على الفرع المحدد.</p>
        </div>
      </div>
      <form className="card formgrid" onSubmit={addTransfer}><h3>تحويل مخزون جديد</h3>
        <select required value={form.from} onChange={(event) => setForm({ ...form, from: event.target.value, batch: '' })}>
          <option value="">فرع المصدر</option>{branches.map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}
        </select>
        <select required value={form.to} onChange={(event) => setForm({ ...form, to: event.target.value })}>
          <option value="">فرع الوجهة</option>{branches.filter((row) => row.id !== form.from).map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}
        </select>
        <select required value={form.batch} onChange={(event) => setForm({ ...form, batch: event.target.value })}>
          <option value="">اختر الدفعة</option>{sourceBatches.filter((row) => row.quantity > 0).map((row) => <option key={row.id} value={row.id}>
            {products.find((product) => product.id === row.product_id)?.arabic_name} — {row.batch_number} — متاح {row.quantity}
          </option>)}
        </select>
        <input required type="number" min="0.001" step="0.001" value={form.quantity} onChange={(event) => setForm({ ...form, quantity: event.target.value })} />
        <input value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} placeholder="ملاحظات" />
        <button>إنشاء مسودة التحويل</button>
      </form>
      <div className="card"><table><thead><tr><th>من</th><th>إلى</th><th>الحالة</th><th>التاريخ</th><th>الإجراء</th></tr></thead>
        <tbody>{transfers.map((transfer) => <tr key={transfer.id}>
          <td>{branches.find((row) => row.id === transfer.from_branch_id)?.name}</td>
          <td>{branches.find((row) => row.id === transfer.to_branch_id)?.name}</td>
          <td>{transfer.status}</td><td>{transfer.created_at.slice(0, 10)}</td>
          <td className="button-row">
            {transfer.status === 'DRAFT' && <><button onClick={() => sendTransfer(user, transfer.id)}>إرسال</button><button className="danger" onClick={() => cancelTransfer(user, transfer.id)}>إلغاء</button></>}
            {transfer.status === 'SENT' && <button className="primary" onClick={() => receiveTransfer(user, transfer.id)}>استلام</button>}
          </td>
        </tr>)}</tbody></table>{!transfers.length && <p className="empty">لا توجد تحويلات.</p>}</div>
    </section>
  );
}