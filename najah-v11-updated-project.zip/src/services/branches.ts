import { db, getPharmacyId } from './db';
import type { Branch, StockTransfer, StockTransferItem, User } from '../types/models';
import { now, uid } from '../utils/ids';
import { PLAN_LIMITS } from './plans';
import { audit } from './audit';
import { enqueueOperation } from './sync';

export async function createBranch(user: User, input: { name: string; code: string; address?: string; phone?: string }) {
  const name = input.name.trim(), code = input.code.trim().toUpperCase();
  if (!name || !code) throw new Error('اسم الفرع ورمزه مطلوبان.');
  const settings = await db.settings.get('settings');
  const limit = PLAN_LIMITS[String(settings?.plan_code || 'basic')]?.branches || 1;
  if (await db.branches.count() >= limit) throw new Error(`خطة الاشتراك تسمح بعدد ${limit} فرع/فروع.`);
  if (await db.branches.where('code').equals(code).first()) throw new Error('رمز الفرع مستخدم مسبقاً.');
  const timestamp = now();
  const branch: Branch = {
    id: uid('branch'), pharmacy_id: getPharmacyId(), name, code,
    address: input.address?.trim(), phone: input.phone?.trim(), active: true,
    created_at: timestamp, updated_at: timestamp,
  };
  await db.transaction('rw', db.branches, db.audit_logs, async () => {
    await db.branches.add(branch);
    await audit(user.id, 'branch_created', 'branches', branch.id, branch);
  });
  return branch;
}

export async function switchBranch(user: User, branchId: string) {
  const branch = await db.branches.get(branchId);
  if (!branch?.active) throw new Error('الفرع غير متاح.');
  await db.settings.update('settings', { branch_id: branch.id, updated_at: now() });
  await audit(user.id, 'branch_switched', 'branches', branch.id, { branch: branch.name });
}

export async function createTransfer(
  user: User, fromBranchId: string, toBranchId: string, batchId: string,
  quantity: number, notes?: string,
) {
  if (fromBranchId === toBranchId) throw new Error('فرع المصدر والوجهة يجب أن يكونا مختلفين.');
  if (!Number.isFinite(quantity) || quantity <= 0) throw new Error('كمية التحويل غير صالحة.');
  const batch = await db.batches.get(batchId);
  if (!batch || (batch.branch_id && batch.branch_id !== fromBranchId) || batch.quantity < quantity) {
    throw new Error('الكمية المطلوبة غير متاحة في فرع المصدر.');
  }
  const timestamp = now(), pharmacy_id = getPharmacyId();
  const transfer: StockTransfer = {
    id: uid('transfer'), pharmacy_id, from_branch_id: fromBranchId,
    to_branch_id: toBranchId, status: 'DRAFT', notes: notes?.trim(),
    created_by: user.id, created_at: timestamp, updated_at: timestamp,
  };
  const item: StockTransferItem = {
    id: uid('transferitem'), pharmacy_id, transfer_id: transfer.id,
    product_id: batch.product_id, variant_id: batch.variant_id,
    batch_id: batch.id, quantity, created_at: timestamp,
  };
  await db.transaction('rw', db.stock_transfers, db.stock_transfer_items, db.audit_logs, async () => {
    await db.stock_transfers.add(transfer); await db.stock_transfer_items.add(item);
    await audit(user.id, 'stock_transfer_created', 'stock_transfers', transfer.id, { transfer, item });
  });
  return transfer;
}

export async function sendTransfer(user: User, transferId: string) {
  const transfer = await db.stock_transfers.get(transferId);
  if (!transfer || transfer.status !== 'DRAFT') throw new Error('التحويل غير قابل للإرسال.');
  const items = await db.stock_transfer_items.where('transfer_id').equals(transferId).toArray();
  const timestamp = now();
  await (db.transaction as any)('rw', [
    db.stock_transfers, db.stock_transfer_items, db.batches, db.stock_movements,
    db.audit_logs, db.sync_operations,
  ], async () => {
    for (const item of items) {
      const batch = item.batch_id ? await db.batches.get(item.batch_id) : undefined;
      if (!batch || batch.quantity < item.quantity ||
          (batch.branch_id && batch.branch_id !== transfer.from_branch_id)) {
        throw new Error('مخزون فرع المصدر تغيّر ولا يكفي لإرسال التحويل.');
      }
      await db.batches.update(batch.id, { quantity: batch.quantity - item.quantity, updated_at: timestamp });
      await db.stock_movements.add({
        id: uid('move'), pharmacy_id: transfer.pharmacy_id, branch_id: transfer.from_branch_id,
        product_id: item.product_id, batch_id: batch.id, type: 'transfer_out',
        quantity: -item.quantity, before_qty: batch.quantity,
        after_qty: batch.quantity - item.quantity, reference_id: transfer.id,
        user_id: user.id, created_at: timestamp, updated_at: timestamp,
      });
    }
    await db.stock_transfers.update(transfer.id, { status: 'SENT', updated_at: timestamp });
    await audit(user.id, 'stock_transfer_sent', 'stock_transfers', transfer.id, transfer);
    await enqueueOperation('stock_transfer_send', { transfer, items }, `transfer-send:${transfer.id}`);
  });
}

export async function receiveTransfer(user: User, transferId: string) {
  const transfer = await db.stock_transfers.get(transferId);
  if (!transfer || transfer.status !== 'SENT') throw new Error('التحويل غير جاهز للاستلام.');
  const items = await db.stock_transfer_items.where('transfer_id').equals(transferId).toArray();
  const timestamp = now();
  await (db.transaction as any)('rw', [
    db.stock_transfers, db.stock_transfer_items, db.batches, db.stock_movements,
    db.audit_logs, db.sync_operations,
  ], async () => {
    for (const item of items) {
      const source = item.batch_id ? await db.batches.get(item.batch_id) : undefined;
      if (!source) throw new Error('دفعة التحويل غير موجودة.');
      let target = (await db.batches.where('product_id').equals(item.product_id).toArray()).find((batch) =>
        batch.branch_id === transfer.to_branch_id && batch.variant_id === item.variant_id &&
        batch.batch_number === source.batch_number && batch.expiry_date === source.expiry_date);
      if (!target) {
        target = {
          ...source, id: uid('batch'), branch_id: transfer.to_branch_id,
          quantity: 0, initial_quantity: 0, created_at: timestamp, updated_at: timestamp,
        };
        await db.batches.add(target);
      }
      const before = target.quantity, after = before + item.quantity;
      await db.batches.update(target.id, { quantity: after, updated_at: timestamp });
      await db.stock_movements.add({
        id: uid('move'), pharmacy_id: transfer.pharmacy_id, branch_id: transfer.to_branch_id,
        product_id: item.product_id, batch_id: target.id, type: 'transfer_in',
        quantity: item.quantity, before_qty: before, after_qty: after,
        reference_id: transfer.id, user_id: user.id, created_at: timestamp, updated_at: timestamp,
      });
    }
    await db.stock_transfers.update(transfer.id, { status: 'RECEIVED', updated_at: timestamp });
    await audit(user.id, 'stock_transfer_received', 'stock_transfers', transfer.id, transfer);
    await enqueueOperation('stock_transfer_receive', { transfer_id: transfer.id }, `transfer-receive:${transfer.id}`);
  });
}

export async function cancelTransfer(user: User, transferId: string) {
  const transfer = await db.stock_transfers.get(transferId);
  if (!transfer || transfer.status !== 'DRAFT') throw new Error('يمكن إلغاء التحويل قبل الإرسال فقط.');
  await db.stock_transfers.update(transferId, { status: 'CANCELLED', updated_at: now() });
  await audit(user.id, 'stock_transfer_cancelled', 'stock_transfers', transferId, transfer);
}