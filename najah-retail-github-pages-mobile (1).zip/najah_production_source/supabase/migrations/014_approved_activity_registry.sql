-- Approved activity registry supplied by the business owner (13 verticals).
-- Existing business/license records keep their original IDs for compatibility;
-- the application resolves historical IDs through its legacy alias map.
insert into public.business_types (id, name_ar, name_en, sort_order, is_enabled)
values
  ('pharmacy','صيدلية','Pharmacy',10,true),
  ('auto_parts','قطع غيار سيارات','Auto Parts',20,true),
  ('grocery_supermarket','بقالة وسوبر ماركت','Grocery & Supermarket',30,true),
  ('homeware','أواني منزلية','Homeware',40,true),
  ('furniture_decor','أثاث وديكور','Furniture & Decor',50,true),
  ('clothing','محل ملابس','Clothing Store',60,true),
  ('perfume_cosmetics','عطور وكريمات','Perfumes & Creams',70,true),
  ('shoes','محل أحذية','Shoes Store',80,true),
  ('bookstore','محل مكتبة','Bookstore',90,true),
  ('mobile','هواتف','Mobile Phones',100,true),
  ('building_materials','مواد بناء','Building Materials',110,true),
  ('electronics','إلكترونيات','Electronics',120,true),
  ('electrical','أجهزة كهربائية','Electrical Appliances',130,true)
on conflict (id) do update set
  name_ar=excluded.name_ar,
  name_en=excluded.name_en,
  sort_order=excluded.sort_order,
  is_enabled=true,
  updated_at=now();

-- These old choices are retained as rows so existing foreign keys and data stay valid,
-- but they can no longer be chosen for a new business or license.
update public.business_types
set is_enabled=false, updated_at=now()
where id in (
  'spare_parts','car_accessories','grocery','supermarket','furniture','hardware',
  'home_furnishings','cosmetics','perfume','stationery','general','other'
);

insert into public.business_feature_configs (business_type_id,module_key,enabled,config) values
  ('pharmacy','product_attributes',true,'{"fields":["scientific_name","concentration","dosage","form","manufacturer","batch_number","expiry_date","prescription_required"],"units":["tablet","box","bottle","tube","injection","carton"],"expiry_tracking":true,"variants":["concentration","dosage","form","batch_number"]}'::jsonb),
  ('auto_parts','product_attributes',true,'{"fields":["part_number","brand","model","vehicle","year","serial_number","accessory_type"],"units":["piece","set","box","carton"],"serialized":true,"variants":["model","vehicle"]}'::jsonb),
  ('grocery_supermarket','product_attributes',true,'{"fields":["unit","weight","pack","carton","batch_number","expiry_date","barcode"],"units":["piece","kg","g","liter","ml","pack","carton"],"expiry_tracking":true,"batch_tracking":true,"unit_conversion":true}'::jsonb),
  ('homeware','product_attributes',true,'{"fields":["product_type","material","size","color","brand","pieces","set","weight"],"units":["piece","set","carton"],"variants":["size","color"]}'::jsonb),
  ('furniture_decor','product_attributes',true,'{"fields":["product_type","material","wood_type","fabric","color","dimensions","length","width","height","weight","warranty","brand","model","pattern"],"units":["piece","set","meter","carton"],"variants":["color","dimensions","material"]}'::jsonb),
  ('clothing','product_attributes',true,'{"fields":["size","color","gender","brand","fabric","season","style"],"units":["piece","set"],"variants":["size","color"]}'::jsonb),
  ('perfume_cosmetics','product_attributes',true,'{"fields":["brand","manufacturer","fragrance_family","shade","size","batch_number","expiry_date"],"units":["bottle","container","piece","carton"],"expiry_tracking":true,"batch_tracking":true,"variants":["fragrance_family","shade","size"]}'::jsonb),
  ('shoes','product_attributes',true,'{"fields":["size","color","gender","brand","material","style","season"],"units":["pair","piece"],"variants":["size","color"]}'::jsonb),
  ('bookstore','product_attributes',true,'{"fields":["category","author","publisher","isbn","edition","subject","grade","brand","color","size"],"units":["book","piece","notebook","box","carton"],"variants":["edition","grade"]}'::jsonb),
  ('mobile','product_attributes',true,'{"fields":["brand","model","ram","storage","color","network","imei","serial_number","warranty"],"units":["device","piece","carton"],"serialized":true,"imei_tracking":true,"variants":["ram","storage","color"]}'::jsonb),
  ('building_materials','product_attributes',true,'{"fields":["material_type","material","unit","weight","length","width","height","brand"],"units":["piece","meter","square_meter","cubic_meter","kg","ton","bag","carton"],"unit_conversion":true}'::jsonb),
  ('electronics','product_attributes',true,'{"fields":["brand","model","ram","storage","serial_number","warranty","voltage","power","weight","color"],"units":["piece","device","carton"],"serialized":true,"variants":["ram","storage","color"]}'::jsonb),
  ('electrical','product_attributes',true,'{"fields":["brand","model","serial_number","warranty","warranty_start","warranty_end","voltage","power","color","dimensions"],"units":["piece","device","carton"],"serialized":true,"variants":["color"]}'::jsonb)
on conflict (business_type_id,module_key) do update
set enabled=excluded.enabled, config=excluded.config, updated_at=now();

create or replace function public.canonical_business_type_id(p_type text)
returns text
language sql
immutable
set search_path = public
as $$
  select case lower(coalesce(p_type,''))
    when 'spare_parts' then 'auto_parts'
    when 'car_accessories' then 'auto_parts'
    when 'grocery' then 'grocery_supermarket'
    when 'supermarket' then 'grocery_supermarket'
    when 'furniture' then 'furniture_decor'
    when 'home_furnishings' then 'furniture_decor'
    when 'hardware' then 'legacy_hardware'
    when 'cosmetics' then 'perfume_cosmetics'
    when 'perfume' then 'perfume_cosmetics'
    when 'stationery' then 'bookstore'
    when 'general' then 'legacy_generic'
    when 'other' then 'legacy_generic'
    else lower(coalesce(p_type,''))
  end;
$$;

-- Enforce the approved set even when license creation bypasses the UI.
create or replace function public.guard_license_activity_enabled()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.business_types
    where id = new.business_type_id and is_enabled
  ) then
    raise exception using errcode='23514', message='business_type_invalid';
  end if;
  return new;
end;
$$;
drop trigger if exists licenses_activity_enabled on public.licenses;
create trigger licenses_activity_enabled
before insert or update of business_type_id on public.licenses
for each row execute function public.guard_license_activity_enabled();

-- Re-define setup RPCs to require the license and selected activity to agree,
-- accepting historical aliases only when they map to the same approved vertical.
create or replace function public.setup_business_for_user(
  p_user_id uuid,
  p_license_key_hash text,
  p_business_type_id text,
  p_name text,
  p_owner_name text,
  p_phone text,
  p_email text
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare
  v_license public.licenses%rowtype;
  v_business uuid;
  v_branch uuid;
begin
  if p_user_id is null or nullif(trim(p_license_key_hash),'') is null then
    raise exception 'setup_parameters_required';
  end if;
  select * into v_license from public.licenses
    where license_key_hash=p_license_key_hash for update;
  if not found then raise exception 'license_not_found'; end if;
  if v_license.status <> 'active'
     or (v_license.expires_at is not null and v_license.expires_at < now()) then
    raise exception 'license_not_active';
  end if;
  if v_license.business_id is not null then raise exception 'license_already_claimed'; end if;
  if not exists(select 1 from public.business_types where id=p_business_type_id and is_enabled) then
    raise exception 'business_type_invalid';
  end if;
  if public.canonical_business_type_id(v_license.business_type_id)
     is distinct from public.canonical_business_type_id(p_business_type_id) then
    raise exception 'license_activity_mismatch';
  end if;
  insert into public.businesses(business_type_id,name,owner_name,phone,email,created_by)
  values(p_business_type_id,trim(p_name),trim(p_owner_name),nullif(trim(p_phone),''),lower(trim(p_email)),p_user_id)
  returning id into v_business;
  insert into public.branches(business_id,name,code)
    values(v_business,'الفرع الرئيسي','MAIN') returning id into v_branch;
  insert into public.business_settings(business_id) values(v_business);
  insert into public.business_members(business_id,branch_id,user_id,display_name,username,role,permissions)
  values(v_business,v_branch,p_user_id,trim(p_owner_name),lower(trim(p_email)),'owner','["*"]'::jsonb);
  update public.licenses set business_id=v_business,business_type_id=p_business_type_id,
    store_name=trim(p_name),owner_name=trim(p_owner_name),
    activation_date=coalesce(activation_date,now()),updated_at=now()
  where id=v_license.id;
  insert into public.license_events(license_id,event_type,actor_user_id,details)
  values(v_license.id,'business_setup',p_user_id,
    jsonb_build_object('business_id',v_business,'business_type_id',p_business_type_id));
  return v_business;
end;
$$;

create or replace function public.claim_license_for_business(
  p_license_key_hash text,
  p_business_type_id text,
  p_name text,
  p_owner_name text,
  p_phone text,
  p_email text
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare
  v_license public.licenses%rowtype;
  v_business uuid;
begin
  if auth.uid() is null then raise exception 'authentication_required'; end if;
  select * into v_license from public.licenses
    where license_key_hash=p_license_key_hash for update;
  if not found then raise exception 'license_not_found'; end if;
  if v_license.status <> 'active'
     or (v_license.expires_at is not null and v_license.expires_at < now()) then
    raise exception 'license_not_active';
  end if;
  if not exists(select 1 from public.business_types where id=p_business_type_id and is_enabled) then
    raise exception 'business_type_invalid';
  end if;
  if public.canonical_business_type_id(v_license.business_type_id)
     is distinct from public.canonical_business_type_id(p_business_type_id) then
    raise exception 'license_activity_mismatch';
  end if;
  if v_license.business_id is not null then raise exception 'license_already_claimed'; end if;
  insert into public.businesses(business_type_id,name,owner_name,phone,email,created_by)
  values(p_business_type_id,p_name,p_owner_name,p_phone,p_email,auth.uid()) returning id into v_business;
  insert into public.branches(business_id,name,code) values(v_business,'الفرع الرئيسي','MAIN');
  insert into public.business_settings(business_id) values(v_business);
  insert into public.business_members(business_id,user_id,display_name,role)
    values(v_business,auth.uid(),p_owner_name,'owner');
  update public.licenses set business_id=v_business,business_type_id=p_business_type_id,
    store_name=p_name,owner_name=p_owner_name,activation_date=coalesce(activation_date,now()),updated_at=now()
  where id=v_license.id;
  insert into public.license_events(license_id,event_type,actor_user_id,details)
    values(v_license.id,'claimed',auth.uid(),jsonb_build_object('business_id',v_business));
  return v_business;
end;
$$;