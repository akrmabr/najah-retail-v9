export const STORAGE_KEYS = {
  pharmacyId: 'najah_retail_business_id',
  licenseCache: 'najah_retail_license_cache',
  deviceFingerprint: 'najah_retail_device_fingerprint',
  licenseEndpoint: 'najah_retail_license_endpoint',
  session: 'najah_retail_session',
  setupCompleted: 'najah_retail_setup_completed',
  persistentStorage: 'najah_retail_storage_persistent',
} as const;

const LEGACY_KEYS: Record<string, string> = {
  alshifaa_pharmacy_id: STORAGE_KEYS.pharmacyId,
  alshifaa_license_cache: STORAGE_KEYS.licenseCache,
  alshifaa_device_fingerprint: STORAGE_KEYS.deviceFingerprint,
  alshifaa_license_endpoint: STORAGE_KEYS.licenseEndpoint,
  alshifaa_session: STORAGE_KEYS.session,
  alshifaa_setup_completed: STORAGE_KEYS.setupCompleted,
  alshifaa_storage_persistent: STORAGE_KEYS.persistentStorage,
};

/** Keep legacy values as a recovery copy until a future release. */
export function migrateLegacyStorageKeys() {
  for (const [legacy, current] of Object.entries(LEGACY_KEYS)) {
    if (localStorage.getItem(current) === null) {
      const value = localStorage.getItem(legacy);
      if (value !== null) localStorage.setItem(current, value);
    }
  }
}