import { db } from './db';

function esc(value: unknown) {
  return String(value ?? '').replace(/[&<>\"]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]!));
}

export async function printInvoice(saleId: string, target?: Window | null) {
  const sale = await db.sales.get(saleId);
  if (!sale) throw new Error('الفاتورة غير موجودة');
  const [items, settings, customer, user] = await Promise.all([
    db.sale_items.where('sale_id').equals(saleId).toArray(),
    db.settings.get('settings'),
    sale.customer_id ? db.customers.get(sale.customer_id) : Promise.resolve(undefined),
    db.users.get(sale.cashier_id),
  ]);
  const products = await db.products.bulkGet(items.map((i) => i.product_id));
  const symbol = String(settings?.currency_symbol || '');
  const amount = (value: number, withSymbol = false) => `${Number(value || 0).toFixed(2)}${withSymbol && symbol ? ` ${esc(symbol)}` : ''}`;
  const rows = items.map((it, idx) => {
    const p = products[idx];
    return `<tr><td>${idx + 1}</td><td>${esc(p?.arabic_name || p?.english_name || it.product_id)}</td><td>${it.quantity}</td><td>${amount(it.unit_price)}</td><td>${amount(it.discount)}</td><td>${amount(it.line_total)}</td></tr>`;
  }).join('');
  const configuredPaper = String(settings?.default_paper || '80mm').toLowerCase();
  const isA4 = configuredPaper.includes('a4');
  const paperWidth = isA4 ? '210mm' : configuredPaper.includes('58') ? '58mm' : '80mm';
  const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>فاتورة ${esc(sale.invoice_no)}</title><style>
  *{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;margin:0;background:#f3f4f6;color:#111}.toolbar{position:sticky;top:0;background:#111827;color:#fff;padding:12px;display:flex;gap:8px;justify-content:center}.toolbar button{border:0;border-radius:8px;padding:10px 16px;font-weight:700;cursor:pointer}.print{background:#0f766e;color:white}.close{background:#374151;color:white}.sheet{position:relative;overflow:hidden;width:${paperWidth};min-height:${isA4 ? '297mm' : 'auto'};margin:18px auto;background:#fff;padding:${isA4 ? '16mm' : '4mm'};box-shadow:0 6px 30px #0002}.head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:8px}.brand{display:flex;gap:8px;align-items:center}.brand img{width:${isA4 ? '72px' : '36px'};height:${isA4 ? '72px' : '36px'};object-fit:contain}.no-logo{width:${isA4 ? '72px' : '36px'};height:${isA4 ? '72px' : '36px'};border:1px dashed #cbd5e1;border-radius:6px;display:grid;place-items:center;color:#94a3b8;font-size:8px;text-align:center}.brand h1{margin:0;font-size:${isA4 ? '24px' : '14px'}}h2{font-size:${isA4 ? '20px' : '14px'};margin:0 0 4px}.muted{color:#6b7280;font-size:${isA4 ? '12px' : '8px'};line-height:1.55}.box{background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:7px;margin:10px 0;display:grid;grid-template-columns:repeat(${isA4 ? '3' : '1'},1fr);gap:4px;font-size:${isA4 ? '12px' : '9px'}}table{width:100%;border-collapse:collapse;margin-top:10px}th{background:#111;color:white}td,th{padding:${isA4 ? '8px' : '4px 2px'};border-bottom:1px solid #e5e7eb;text-align:right;font-size:${isA4 ? '12px' : '8px'}}.totals{width:${isA4 ? '45%' : '100%'};margin-right:auto;margin-top:10px;border:1px solid #e5e7eb;font-size:${isA4 ? '12px' : '9px'}}.totals div{display:flex;justify-content:space-between;padding:${isA4 ? '8px 10px' : '5px'};border-bottom:1px solid #e5e7eb}.totals b{background:#111;color:white}.watermark{position:absolute;z-index:0;inset:35% 20% auto;height:180px;background:url('${esc(settings?.logo || '')}') center/contain no-repeat;opacity:.06;pointer-events:none}.sheet>*{position:relative;z-index:1}.footer{text-align:center;color:#6b7280;border-top:1px solid #e5e7eb;margin-top:20px;padding-top:8px;font-size:${isA4 ? '11px' : '8px'}}@media(max-width:800px){.sheet{width:100%;min-height:auto;margin:0;padding:10px}.box{grid-template-columns:1fr}.totals{width:100%}.toolbar{bottom:0;top:auto;position:fixed;width:100%;z-index:9}}@media print{body{background:white}.toolbar{display:none}.sheet{box-shadow:none;margin:0;width:${paperWidth};min-height:auto;padding:${isA4 ? '8mm' : '3mm'}}@page{size:${isA4 ? 'A4' : `${paperWidth} auto`};margin:${isA4 ? '8mm' : '0'}}}
  </style></head><body><div class="toolbar"><button class="print" onclick="window.print()">طباعة الفاتورة</button><button class="close" onclick="window.close()">إغلاق</button></div><main class="sheet"><div class="watermark"></div><section class="head"><div class="brand">${settings?.logo ? `<img src="${esc(settings.logo)}" alt="شعار النشاط">` : `<div class="no-logo">شعار النشاط</div>`}<div><h1>${esc(settings?.pharmacy_name || 'اسم النشاط')}</h1><div class="muted">${esc(settings?.address || '')}<br>${esc(settings?.phone || '')} ${settings?.email ? ' — ' + esc(settings.email) : ''}<br>${settings?.tax_number ? 'الرقم الضريبي: ' + esc(settings.tax_number) : ''}</div></div></div><div><h2>فاتورة بيع</h2><div class="muted">رقم الفاتورة: ${esc(sale.invoice_no)}<br>التاريخ: ${new Date(sale.created_at).toLocaleString('ar')}<br>الحالة: ${sale.status === 'COMPLETED' ? 'مكتملة' : sale.status === 'CANCELLED' ? 'ملغاة' : 'مرتجعة'}</div></div></section><section class="box"><div>العميل: <b>${esc(customer?.name || 'نقدي')}</b></div><div>الكاشير: <b>${esc(user?.name || '')}</b></div><div>طريقة الدفع: <b>${sale.payment_method === 'Cash' ? 'نقدي' : sale.payment_method}</b></div></section><table><thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th></tr></thead><tbody>${rows}</tbody></table><section class="totals"><div><span>المجموع الفرعي</span><span>${amount(sale.subtotal, true)}</span></div><div><span>الخصم</span><span>${amount(sale.discount, true)}</span></div><div><span>الضريبة</span><span>${amount(sale.tax, true)}</span></div><div><b>الإجمالي</b><b>${amount(sale.total, true)}</b></div><div><span>المدفوع</span><span>${amount(sale.paid, true)}</span></div><div><span>المتبقي</span><span>${amount(Math.max(0, sale.total - sale.paid), true)}</span></div>${sale.paid > sale.total ? `<div><b>الباقي للعميل</b><b>${amount(sale.paid - sale.total, true)}</b></div>` : ''}</section><div class="footer">${esc(settings?.invoice_footer || 'شكراً لتعاملك معنا')}<br><small>النظام بواسطة النجاح لإدارة المحال التجارية — 0121164581 — واتساب 0969696787</small></div></main></body></html>`;
  const blobUrl = URL.createObjectURL(new Blob([html], {type:'text/html;charset=utf-8'}));
  const win = target && !target.closed ? target : window.open(blobUrl, '_blank');
  if (!win) { URL.revokeObjectURL(blobUrl); throw new Error('تعذر فتح شاشة الطباعة. اسمح بالنوافذ المنبثقة ثم أعد المحاولة من سجل المبيعات.'); }
  if (target && !target.closed) win.location.href = blobUrl;
  win.onload = () => win.focus();
  setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
}
