import {useEffect,useState} from 'react';
import {licenseGate} from '../services/license';
import {pendingSyncCount,syncPendingOperations} from '../services/sync';
export default function OfflineBadge(){
 const [online,setOnline]=useState(navigator.onLine); const [pending,setPending]=useState(0);
 async function refresh(){setPending(await pendingSyncCount()); if(navigator.onLine) await syncPendingOperations(); setPending(await pendingSyncCount())}
 useEffect(()=>{const f=()=>{setOnline(navigator.onLine); void refresh()}; addEventListener('online',f); addEventListener('offline',f); void refresh(); const timer=window.setInterval(()=>void refresh(),30000); return()=>{removeEventListener('online',f); removeEventListener('offline',f); window.clearInterval(timer)}},[]);
 const gate=licenseGate(); return <div className={online?'badge ok':'badge warn'}>{online?'● متصل':'● غير متصل'} <small>{gate.message}{pending>0?` — ${pending} عملية بانتظار المزامنة`:''}</small></div>
}
