-- Permission-aware incremental pull for offline clients. No service key is needed by the client.
create or replace function public.get_sync_snapshot(p_since timestamptz default null)
returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object(
 'server_time',now(),
 'business',(select to_jsonb(b) from public.businesses b where b.id=public.app_business_id()),
 'products',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.products where business_id=public.app_business_id() and (p_since is null or updated_at>p_since) order by updated_at limit 5000)x),'[]'::jsonb),
 'variants',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.product_variants where business_id=public.app_business_id() order by id limit 10000)x),'[]'::jsonb),
 'batches',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.product_batches where business_id=public.app_business_id() order by id limit 10000)x),'[]'::jsonb),
 'serials',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.product_serial_numbers where business_id=public.app_business_id() order by id limit 20000)x),'[]'::jsonb),
 'customers',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.customers where business_id=public.app_business_id() order by id limit 10000)x),'[]'::jsonb),
 'suppliers',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.suppliers where business_id=public.app_business_id() order by id limit 10000)x),'[]'::jsonb),
 'branches',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.branches where business_id=public.app_business_id() order by id limit 1000)x),'[]'::jsonb),
 'sales',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.sales where business_id=public.app_business_id() and (p_since is null or created_at>p_since) order by created_at desc limit 5000)x),'[]'::jsonb),
 'sale_items',coalesce((select jsonb_agg(to_jsonb(x)) from (select si.* from public.sale_items si join public.sales s on s.id=si.sale_id where si.business_id=public.app_business_id() and (p_since is null or s.created_at>p_since) order by si.id limit 20000)x),'[]'::jsonb),
 'purchases',coalesce((select jsonb_agg(to_jsonb(x)) from (select * from public.purchases where business_id=public.app_business_id() and (p_since is null or created_at>p_since) order by created_at desc limit 5000)x),'[]'::jsonb),
 'purchase_items',coalesce((select jsonb_agg(to_jsonb(x)) from (select pi.* from public.purchase_items pi join public.purchases p on p.id=pi.purchase_id where pi.business_id=public.app_business_id() and (p_since is null or p.created_at>p_since) order by pi.id limit 20000)x),'[]'::jsonb)
);
$$;
revoke all on function public.get_sync_snapshot(timestamptz) from public;
grant execute on function public.get_sync_snapshot(timestamptz) to authenticated;
