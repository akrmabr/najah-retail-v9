import { db } from './db';
import { getBusinessType, type BusinessTypeConfig, type BusinessTypeId } from '../config/businessTypes';

type BusinessSettingsRecord = {
  business_type?: BusinessTypeId;
  business_name?: string;
  pharmacy_name?: string;
  logo?: string;
  [key: string]: unknown;
};

export async function getBusinessContext(): Promise<BusinessTypeConfig> {
  const settings = await db.settings.get('settings') as BusinessSettingsRecord | undefined;
  return getBusinessType(settings?.business_type);
}

export async function getBusinessSettings(): Promise<BusinessSettingsRecord> {
  return (await db.settings.get('settings') as BusinessSettingsRecord | undefined) || {};
}

export async function saveBusinessType(businessType: BusinessTypeId): Promise<void> {
  const current = await getBusinessSettings();
  await db.settings.put({
    ...current,
    id: 'settings',
    business_type: businessType,
    updated_at: new Date().toISOString(),
  } as never);
}