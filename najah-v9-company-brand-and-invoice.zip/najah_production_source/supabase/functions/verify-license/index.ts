// Deploy with Supabase CLI. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY as server secrets.
// The service role key must never be included in the frontend.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ valid: false, status: 'method_not_allowed' }, 405);
  try {
    const body = await req.json();
    const keyHash = String(body.licenseKeyHash || '').trim();
    const deviceHash = String(body.deviceFingerprintHash || '').trim();
    const requestedBusinessType = String(body.businessTypeId || '').trim();
    if (!keyHash || !deviceHash) return json({ valid: false, status: 'invalid_request' }, 400);

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
    const { data: license, error } = await admin.from('licenses').select('id,business_id,business_type_id,store_name,owner_name,status,expires_at,device_limit').eq('license_key_hash', keyHash).maybeSingle();
    if (error) return json({ valid: false, status: 'server_error' }, 500);
    if (!license) return json({ valid: false, status: 'invalid' }, 404);
    if (requestedBusinessType && license.business_type_id && requestedBusinessType !== license.business_type_id) return json({ valid: false, status: 'business_type_mismatch' }, 403);
    if (license.status === 'suspended') return json({ valid: false, status: 'suspended' }, 403);
    if (license.status === 'revoked') return json({ valid: false, status: 'revoked' }, 403);
    if (license.expires_at && new Date(license.expires_at).getTime() <= Date.now()) return json({ valid: false, status: 'expired' }, 403);

    const { data: existing } = await admin.from('license_devices').select('id,revoked_at').eq('license_id', license.id).eq('device_fingerprint_hash', deviceHash).maybeSingle();
    if (existing?.revoked_at) return json({ valid: false, status: 'device_revoked' }, 403);
    if (!existing) {
      const { count } = await admin.from('license_devices').select('id', { count: 'exact', head: true }).eq('license_id', license.id).is('revoked_at', null);
      if ((count ?? 0) >= license.device_limit) return json({ valid: false, status: 'device_limit_reached' }, 403);
      const { error: insertError } = await admin.from('license_devices').insert({ license_id: license.id, device_fingerprint_hash: deviceHash });
      if (insertError) return json({ valid: false, status: 'device_registration_failed' }, 500);
    } else {
      await admin.from('license_devices').update({ last_seen_at: new Date().toISOString() }).eq('id', existing.id);
    }
    return json({ valid: true, status: 'active', licenseId: license.id, businessId: license.business_id, businessTypeId: license.business_type_id, storeName: license.store_name, ownerName: license.owner_name, expires_at: license.expires_at });
  } catch { return json({ valid: false, status: 'invalid_request' }, 400); }
});
