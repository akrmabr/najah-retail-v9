import { useEffect, useRef, useState } from 'react';

type Props = {
  open: boolean;
  onClose: () => void;
  onDetected: (code: string) => void;
};

export default function BarcodeScanner({ open, onClose, onDetected }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const controlsRef = useRef<any>(null);
  const stoppedRef = useRef(false);
  const onCloseRef = useRef(onClose);
  const onDetectedRef = useRef(onDetected);
  const [message, setMessage] = useState('');
  onCloseRef.current = onClose;
  onDetectedRef.current = onDetected;

  useEffect(() => {
    if (!open) return;
    stoppedRef.current = false;
    setMessage('جاري فتح الكاميرا...');

    async function stopAll() {
      try { controlsRef.current?.stop?.(); } catch {}
      try { streamRef.current?.getTracks().forEach((t) => t.stop()); } catch {}
      controlsRef.current = null;
      streamRef.current = null;
    }

    async function start() {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          setMessage('المتصفح لا يدعم فتح الكاميرا. استخدم إدخال الباركود اليدوي.');
          return;
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: false,
        });
        streamRef.current = stream;
        if (!videoRef.current) return;
        videoRef.current.srcObject = stream;
        await videoRef.current.play();

        const NativeBarcodeDetector = (window as any).BarcodeDetector;
        if (NativeBarcodeDetector) {
          try {
          const formats = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code'];
          const detector = new NativeBarcodeDetector({ formats });
          setMessage('وجّه الكاميرا نحو الباركود.');
          const scan = async () => {
            if (stoppedRef.current || !videoRef.current) return;
            try {
              const codes = await detector.detect(videoRef.current);
              if (codes?.length) {
                stoppedRef.current = true;
                const value = String(codes[0].rawValue || '').trim();
                await stopAll();
                if (value) onDetectedRef.current(value);
                onCloseRef.current();
                return;
              }
            } catch {}
            requestAnimationFrame(scan);
          };
          requestAnimationFrame(scan);
          return;
          } catch {
            // Some browsers expose BarcodeDetector but reject one of the
            // requested formats. Continue with the ZXing fallback below.
          }
        }

        const mod: any = await import('@zxing/browser');
        const reader = new mod.BrowserMultiFormatReader();
        setMessage('وجّه الكاميرا نحو الباركود.');
        controlsRef.current = await reader.decodeFromVideoElement(videoRef.current, async (result: any) => {
          if (result && !stoppedRef.current) {
            stoppedRef.current = true;
            const value = String(result.getText()).trim();
            await stopAll();
            if (value) onDetectedRef.current(value);
            onCloseRef.current();
          }
        });
      } catch (error: any) {
        const text = String(error?.message || error || '');
        if (text.includes('Permission') || text.includes('NotAllowed')) {
          setMessage('تم رفض إذن الكاميرا. اسمح للمتصفح باستخدام الكاميرا ثم حاول مرة أخرى.');
        } else if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
          setMessage('فتح الكاميرا يحتاج رابط آمن HTTPS.');
        } else {
          setMessage('تعذر فتح الكاميرا. يمكنك إدخال الباركود يدوياً.');
        }
      }
    }

    start();
    return () => {
      stoppedRef.current = true;
      stopAll();
    };
  }, [open]);

  if (!open) return null;
  return (
    <div className="modal-backdrop">
      <div className="scanner-modal">
        <div className="modal-head">
          <h3>مسح الباركود بالكاميرا</h3>
          <button className="ghost" onClick={onClose}>إغلاق</button>
        </div>
        <div className="scanner-box">
          <video ref={videoRef} muted playsInline />
          <div className="scan-frame" />
        </div>
        <p>{message}</p>
      </div>
    </div>
  );
}
