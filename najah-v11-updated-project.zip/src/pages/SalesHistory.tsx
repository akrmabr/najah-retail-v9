import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import { cancelSale } from '../services/sales';
import { returnSale } from '../services/returns';
import { printInvoice } from '../services/invoice';
import type { User } from '../types/models';
import { money } from '../utils/ids';
import ActionDialog from '../components/ActionDialog';

export default function SalesHistory({ user }: { user: User }) {
  const sales = useLiveQuery(() => db.sales.orderBy('created_at').reverse().toArray(), []) || [];
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const [message, setMessage] = useState('');
  const [action,setAction]=useState<{type:'cancel'|'return';id:string}|null>(null);
  async function viewInvoice(id: string) {
    try { await printInvoice(id); setMessage('تم فتح معاينة الفاتورة داخل التطبيق.'); }
    catch (e: any) { setMessage(e?.message || 'تعذر فتح الفاتورة للطباعة.'); }
  }
  return <section><h1>سجل المبيعات</h1>{message&&<div className="alert">{message}</div>}<div className="card"><table><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العميل</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th><th>إجراءات</th></tr></thead><tbody>{sales.map(s=><tr key={s.id}><td>{s.invoice_no}</td><td>{new Date(s.created_at).toLocaleDateString('ar')}</td><td>{customers.find(c=>c.id===s.customer_id)?.name||'نقدي'}</td><td>{money(s.total)}</td><td>{money(s.paid)}</td><td>{money(s.remaining)}</td><td><span className={`status ${s.status==='COMPLETED'?'ok':'bad'}`}>{s.status==='COMPLETED'?'مكتملة':s.status==='CANCELLED'?'ملغاة':'مرتجعة'}</span></td><td><button onClick={()=>viewInvoice(s.id)}>عرض/طباعة</button>{s.status==='COMPLETED'&&<><button className="danger" onClick={()=>setAction({type:'cancel',id:s.id})}>إلغاء</button><button className="danger" onClick={()=>setAction({type:'return',id:s.id})}>مرتجع</button></>}</td></tr>)}</tbody></table>{!sales.length&&<p className="empty">لا توجد مبيعات بعد.</p>}</div><ActionDialog open={!!action} title={action?.type==='cancel'?'إلغاء الفاتورة':'ترجيع الفاتورة'} danger onClose={()=>setAction(null)} onConfirm={async reason=>{if(!action)return;if(action.type==='cancel'){await cancelSale(user.id,action.id,reason);setMessage('تم إلغاء الفاتورة وعكس أثرها.')}else{await returnSale(user.id,action.id,reason);setMessage('تم ترجيع الفاتورة وإعادة الكميات.')}}}/></section>;
}
