create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, name text not null, phone text, email text, address text, opening_balance numeric(14,3) not null default 0, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, name text not null, phone text, email text, address text, opening_balance numeric(14,3) not null default 0, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete restrict, branch_id uuid references public.branches(id) on delete set null, customer_id uuid references public.customers(id) on delete set null, cashier_id uuid references auth.users(id), invoice_number text not null, status text not null default 'completed' check (status in ('draft','completed','cancelled','returned','partial_return')),
  payment_method text not null default 'cash', subtotal numeric(14,3) not null default 0, discount numeric(14,3) not null default 0, tax numeric(14,3) not null default 0, total numeric(14,3) not null default 0, paid numeric(14,3) not null default 0, remaining numeric(14,3) not null default 0, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now(), unique (business_id,invoice_number)
);
create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(), sale_id uuid not null references public.sales(id) on delete cascade, business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id), variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), serial_id uuid references public.product_serial_numbers(id), quantity numeric(14,3) not null check (quantity > 0), unit_price numeric(14,3) not null check (unit_price >= 0), discount numeric(14,3) not null default 0, total numeric(14,3) not null default 0
);

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete restrict, branch_id uuid references public.branches(id) on delete set null, supplier_id uuid references public.suppliers(id) on delete set null, invoice_number text not null, status text not null default 'received' check (status in ('draft','received','cancelled','partial_return')), payment_method text, subtotal numeric(14,3) not null default 0, discount numeric(14,3) not null default 0, tax numeric(14,3) not null default 0, total numeric(14,3) not null default 0, paid numeric(14,3) not null default 0, remaining numeric(14,3) not null default 0, created_at timestamptz not null default now(), unique (business_id,invoice_number)
);
create table if not exists public.purchase_items (
  id uuid primary key default gen_random_uuid(), purchase_id uuid not null references public.purchases(id) on delete cascade, business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id), variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), serial_id uuid references public.product_serial_numbers(id), quantity numeric(14,3) not null check (quantity > 0), unit_cost numeric(14,3) not null check (unit_cost >= 0), total numeric(14,3) not null default 0
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id) on delete set null, product_id uuid not null references public.products(id), variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), movement_type text not null check (movement_type in ('opening','purchase','sale','sale_return','purchase_return','damage','adjustment','transfer_in','transfer_out')),
  quantity_delta numeric(14,3) not null check (quantity_delta <> 0), source_type text, source_id uuid, reason text, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, customer_id uuid references public.customers(id) on delete set null, supplier_id uuid references public.suppliers(id) on delete set null, sale_id uuid references public.sales(id) on delete set null, purchase_id uuid references public.purchases(id) on delete set null, amount numeric(14,3) not null check (amount > 0), payment_method text not null, notes text, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id) on delete set null, category text not null, amount numeric(14,3) not null check (amount > 0), description text, payment_method text, created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(), business_id uuid references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id) on delete set null, user_id uuid references auth.users(id), action text not null, entity_type text, entity_id uuid, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create table if not exists public.sync_operations (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, operation_key text not null, operation_type text not null, payload jsonb not null, status text not null default 'pending' check (status in ('pending','applied','failed','conflict')), error_message text, created_at timestamptz not null default now(), applied_at timestamptz, unique (business_id,operation_key)
);

