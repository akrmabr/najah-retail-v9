# Najah production rebuild — initial audit

This workspace is the recovered source from the existing source maps plus the Supabase migrations/functions supplied by the user. It is not a release build.

## Confirmed existing source
- React pages for dashboard, POS, sales, products, inventory, purchases, customers/suppliers, returns, payments, reports, settings, users, license, backup.
- Dexie IndexedDB data layer and local transactions.
- Local password hashing/authentication and role UI.
- Barcode scanner component and invoice/backup services.
- Supabase schema migrations 001–006 and verify-license Edge Function.

## Release blockers to fix before delivery
- IndexedDB is still the authoritative source in the current UI; server sync must become authoritative online.
- The frontend source is pharmacy-specific and needs the configuration-driven activity engine.
- License activation and owner setup are not one server transaction.
- The license client contract does not match the supplied verify-license Edge Function.
- Sync bridge needs server operation acknowledgements, conflict states, retry/backoff and recovery.
- Return logic needs sold/received quantity validation and financial ledger adjustments.
- Purchase returns, stock transfers, damage, held sales and server-side reporting need completion.
- RLS needs cross-business negative tests and deterministic multi-business membership selection.
- Printing needs A4/58mm/80mm rendering without opening an unrelated blank tab.
- Product variants, batches, IMEI/serial and activity-specific fields need normalized persistence.

## تنفيذ الدفعة الحالية
- تمت إضافة إعدادات 20 نشاطاً تجارياً وربط الاسم والوحدات والحقول ونقطة البيع والمخزون والمشتريات والتقارير بالنشاط المحفوظ.
- تمت إزالة النصوص الثابتة التي كانت تعرض الصيدلية لكل الأنشطة من الإعداد الأولي وتسجيل الدخول والواجهة الرئيسية.
- تمت إضافة محرر متغيرات المنتج للملابس والأحذية والمفروشات وغيرها، مع SKU/باركود/كمية وأسعار مستقلة لكل متغير.
- تمت ترقية IndexedDB إلى الإصدار 3 وإضافة product_variants وطابور sync_operations قابل للاستعادة من النسخة الاحتياطية.
- تمت إضافة طابور عمليات durable بمعرّف idempotency، محاولات، حالات failed/conflict/applied، وإعادة المحاولة تلقائياً عند عودة الاتصال.
- تمت إضافة migration 007_sync_and_atomic_setup.sql: حارس business_id، RPC للعمليات المسموح بها، ومنع تكرار إعداد الترخيص/النشاط والفرع والعضوية.
- تمت إضافة علامة مائية لشعار النشاط في طباعة الفواتير وتحسين التحقق من استعادة النسخ الاحتياطية حتى لا تُستعاد نسخة نشاط آخر.

## المتبقي قبل إعلان الإنتاج
الاعتماديات لم تُثبت داخل بيئة العمل الحالية بسبب عدم توفرها محلياً، لذلك لم يتم إعلان نجاح build النهائي بعد. كما يلزم ربط جلسة Supabase Auth الفعلية بواجهة الدخول الحالية واختبار RPC/RLS على مشروع Supabase حقيقي، ثم تنفيذ اختبارات E2E للأجهزة والطباعة والمزامنة. هذه نقاط تحقق لازمة قبل تسليم نسخة تجارية، وليست ميزات وهمية.

## دفعة إضافية: الترخيص المركزي
- تم تصحيح عميل الترخيص ليتصل بـ `verify-license` بدلاً من endpoint قديم غير موجود.
- أصبح التحقق يرسل SHA-256 لمفتاح الترخيص وبصمة الجهاز، ولا يرسل المفتاح الخام إلى الخادم.
- أصبحت شاشة التفعيل تطلب نوع النشاط قبل التفعيل، وتتحقق من مطابقته للترخيص.
- أضيفت `009_platform_admin.sql` وجدول `platform_admins` و`activation_requests`.
- أضيفت دالتا `owner-control` و`owner-dashboard` مع فحص مستخدم Supabase وصلاحية مسؤول المنصة، وإصدار/إيقاف/إلغاء/تمديد الترخيص وفك ربط الأجهزة.
- أضيفت تعليمات النشر والتسجيل في `supabase/README.md`.

## دفعة إضافية: التهيئة الخادمة
- أضيفت migration 010 ودالة `setup_business_for_user` التي تنشئ النشاط والفرع والإعدادات والعضوية وتربط الترخيص داخل معاملة واحدة.
- أضيفت Edge Function `setup-business` لإنشاء حساب Supabase Auth وتأكيد البريد آلياً ثم تنفيذ التهيئة الخادمة، مع حذف الحساب عند فشل العملية.
- رُبطت شاشة إعداد المالك بالدالة الخادمة بدلاً من اعتبار IndexedDB مصدراً وحيداً.
- أضيفت مصادقة Supabase اختيارية عند تسجيل الدخول مع حفظ Access Token للمزامنة، مع استمرار العمليات المحلية عند انقطاع الشبكة.

## دفعة إضافية: ضمان عدم فقدان العمليات
- أصبحت معرّفات السجلات الجديدة UUID متوافقة مع PostgreSQL بدلاً من معرّفات نصية ذات بادئة.
- أصبح البيع والشراء وحفظ المنتج والمتغيرات والجرد الافتتاحي والتسويات يكتبون العملية المحلية وطابور المزامنة داخل نفس معاملة IndexedDB.
- أصبح البحث في نقطة البيع يدعم باركود وSKU المتغيرات.
- أضيف الدفع الآجل والجزئي وربط العميل بالبيع مع حساب المتبقي.
- أضيفت معالجة الخادم لمزامنة الجرد الافتتاحي والتسويات ومتغيرات المنتجات.
- تم تصحيح قبول دفع أعلى من إجمالي البيع وحساب الباقي للعميل.

## دفعة إضافية: دورة المرتجعات
- تمت إضافة مرتجع جزئي فعلي على مستوى الصنف والكمية.
- يمنع النظام تجاوز الكمية المباعة محلياً وخادمياً.
- يتم تحديث الدفعة وحركة المخزون وحالة الفاتورة ورصيد العميل وسجل التدقيق داخل معاملة واحدة.
- تمت إضافة مزامنة المرتجع الجزئي إلى دالة `record_sale_return` الخادمة.

## دفعة إضافية: الحسابات والمدفوعات
- أصبحت المصروفات تحفظ مع سجل تدقيق وطابور مزامنة، مع فئة ووصف ومبلغ واضح.
- أصبحت دفعات العملاء والموردين ذرية مع تحديث الرصيد وسجل التدقيق والمزامنة.
- أضيفت مزامنة الدفعات والمصروفات على الخادم.
- تم تحسين صفحة العملاء والموردين بالبحث والتعديل ورسائل واضحة وحفظ ذري.

## دفعة إضافية: الجرد والاستيراد ومرتجعات الموردين
- أضيفت شاشة الجرد الدوري مع كمية دفترية وكمية معدودة وفروقات مسجلة في حركات المخزون.
- أضيفت جداول الجرد ومزامنتها على Supabase.
- أضيف استيراد المنتجات من CSV مع التحقق الأساسي للحقول والأسعار وربطه بطابور المزامنة.
- أضيف مرتجع شراء جزئي مع عكس المخزون وتحديث رصيد المورد والتحقق من الحد المستلم محلياً وخادمياً.
- أصبحت شاشة المرتجعات تدعم مرتجع البيع ومرتجع الشراء.

## دفعة إضافية: الباركود والأمان
- أضيف توليد Code 39 قابل للطباعة من سجل المنتجات مع اختيار الباركود أو SKU تلقائياً.
- أضيفت طباعة ملصق 50mm × 30mm من دون تحويل المستخدم إلى Supabase.
- أضيفت migration 011 لفرض الصلاحيات داخل RLS، بحيث لا يكفي إخفاء الأزرار في الواجهة لتجاوز صلاحيات الكاشير.
- أصبحت صلاحيات البيع والشراء والمخزون والعملاء والموردين والمصروفات والمدفوعات والمرتجعات مفروضة خادمياً.

## دفعة إضافية: النزاهة المالية والتكلفة التاريخية
- أضيفت migration 012 مع تكلفة تاريخية لكل سطر بيع، مرتبطة بسعر شراء الدفعة وقت الاستلام بدلاً من سعر المنتج الحالي.
- تم تحديث دوال البيع والشراء لتسجيل تكلفة الدفعة، ومنع دفع يتجاوز إجمالي العملية على الخادم.
- تم تحديث تقرير الربح ليحسب الإيراد ناقص تكلفة البضاعة المباعة ناقص المصروفات.
- أصبحت أرصدة العملاء والموردين في التقرير تخصم مبالغ المرتجعات المكتملة.
- أصبح ترحيل الجرد يحدّث كمية الدفعة الخادمة بالإضافة إلى تسجيل حركة الجرد.
- تم منع تكرار الحقول الديناميكية في نموذج المنتج، وإخفاء الحقول غير الخاصة بالنشاط، مع تسجيل أرشفة المنتج في التدقيق والمزامنة.
- اكتملت دالة `syncPendingOperations` مع حالات syncing/applied/failed وإعادة محاولة تدريجية، وإرسال رقم العملية والدفعة لمنع التكرار أو فقدان البيع عند عودة الإنترنت.
- أصبحت حركة المخزون الخادمة تحدّث كمية الدفعة عبر trigger أمني، مع سياسة RLS تسمح للحركة التابعة للبيع/الشراء/المرتجع فقط ولا تفتح المخزون عشوائياً.
- أصبح تقرير الربح يخصم مرتجعات البيع، وتبقى أعمدة التقرير متوافقة مع الإصدار السابق لتفادي كسر العملاء الحاليين.
