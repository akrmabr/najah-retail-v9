import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db, getPharmacyId } from '../services/db';
import { now, uid } from '../utils/ids';

const statuses = ['NEW','RECEIVED','DIAGNOSIS','REPAIR','WAITING','READY','DELIVERED','REJECTED'] as const;
export default function WarrantyCenter() {
  const warranties = useLiveQuery(() => db.warranties.toArray(), []) || [];
  const tickets = useLiveQuery(() => db.warranty_tickets.toArray(), []) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const serials = useLiveQuery(() => db.serial_numbers.toArray(), []) || [];
  const [warrantyId, setWarrantyId] = useState('');
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState('');
  async function createTicket(event: React.FormEvent) {
    event.preventDefault();
    const warranty = warranties.find((row) => row.id === warrantyId);
    if (!warranty) return setMessage('اختر ضماناً صالحاً.');
    const timestamp = now();
    await db.warranty_tickets.add({
      id: uid('ticket'), pharmacy_id: getPharmacyId(), warranty_id: warranty.id,
      customer_id: warranty.customer_id, product_id: warranty.product_id,
      serial_id: warranty.serial_id, status: 'NEW', notes: notes.trim(),
      created_at: timestamp, updated_at: timestamp,
    });
    if (warranty.serial_id) await db.serial_numbers.update(warranty.serial_id, { status: 'service', updated_at: timestamp });
    setWarrantyId(''); setNotes(''); setMessage('تم فتح تذكرة الضمان.');
  }
  async function changeStatus(id: string, status: typeof statuses[number]) {
    const ticket = await db.warranty_tickets.get(id);
    await db.warranty_tickets.update(id, { status, updated_at: now() });
    if (ticket?.serial_id && ['DELIVERED','REJECTED'].includes(status)) {
      await db.serial_numbers.update(ticket.serial_id, { status: 'sold', updated_at: now() });
    }
  }
  return (
    <section>
      <h1>الضمان والصيانة</h1>
      <form className="card formgrid" onSubmit={createTicket}>
        <select required value={warrantyId} onChange={(event) => setWarrantyId(event.target.value)}>
          <option value="">اختر ضماناً</option>
          {warranties.filter((row) => row.status === 'ACTIVE').map((warranty) => {
            const serial = serials.find((row) => row.id === warranty.serial_id);
            return <option key={warranty.id} value={warranty.id}>
              {products.find((row) => row.id === warranty.product_id)?.arabic_name} — {serial?.imei || serial?.serial_number || warranty.end_date}
            </option>;
          })}
        </select>
        <input value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="وصف المشكلة" />
        <button className="primary">فتح تذكرة</button>
        {message && <div className="alert">{message}</div>}
      </form>
      <div className="card"><table>
        <thead><tr><th>العميل</th><th>المنتج</th><th>الجهاز</th><th>الحالة</th><th>الملاحظات</th></tr></thead>
        <tbody>{tickets.map((ticket) => <tr key={ticket.id}>
          <td>{customers.find((row) => row.id === ticket.customer_id)?.name || '—'}</td>
          <td>{products.find((row) => row.id === ticket.product_id)?.arabic_name || '—'}</td>
          <td>{serials.find((row) => row.id === ticket.serial_id)?.imei || serials.find((row) => row.id === ticket.serial_id)?.serial_number || '—'}</td>
          <td><select value={ticket.status} onChange={(event) => changeStatus(ticket.id, event.target.value as typeof statuses[number])}>
            {statuses.map((status) => <option key={status} value={status}>{status}</option>)}
          </select></td><td>{ticket.notes || ''}</td>
        </tr>)}</tbody>
      </table>{!tickets.length && <p className="empty">لا توجد تذاكر ضمان.</p>}</div>
    </section>
  );
}