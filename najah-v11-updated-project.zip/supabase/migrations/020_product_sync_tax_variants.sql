create or replace function public.apply_product_sync(
 p_operation_key text,p_operation_type text,p_payload jsonb
) returns jsonb language plpgsql security invoker set search_path=public as $$
declare v_business uuid:=public.app_business_id();v_product uuid;v_variant jsonb;v_status text;v_result uuid;
begin
 if v_business is null then raise exception 'business_not_authenticated';end if;
 if p_operation_type<>'product' then raise exception 'unsupported_catalog_operation';end if;
 select status,nullif(payload->>'result','')::uuid into v_status,v_result from public.sync_operations where business_id=v_business and operation_key=p_operation_key;
 if v_status='applied' then return jsonb_build_object('status','applied','result',v_result);end if;
 insert into public.sync_operations(business_id,operation_key,operation_type,payload,status) values(v_business,p_operation_key,p_operation_type,p_payload,'pending')
 on conflict(business_id,operation_key) do update set payload=excluded.payload,status='pending',error_message=null;
 v_product:=coalesce(nullif(p_payload->>'id','')::uuid,gen_random_uuid());
 insert into public.products(business_id,id,name,sku,base_barcode,purchase_price,sale_price,wholesale_price,minimum_stock,tax_rate,attributes,is_active)
 values(v_business,v_product,p_payload->>'name',nullif(p_payload->>'sku',''),nullif(p_payload->>'base_barcode',''),coalesce((p_payload->>'purchase_price')::numeric,0),coalesce((p_payload->>'sale_price')::numeric,0),nullif(p_payload->>'wholesale_price','')::numeric,coalesce((p_payload->>'minimum_stock')::numeric,0),coalesce((p_payload->>'tax_rate')::numeric,0),coalesce(p_payload->'attributes','{}'::jsonb),coalesce((p_payload->>'is_active')::boolean,true))
 on conflict(id) do update set name=excluded.name,sku=excluded.sku,base_barcode=excluded.base_barcode,purchase_price=excluded.purchase_price,sale_price=excluded.sale_price,wholesale_price=excluded.wholesale_price,minimum_stock=excluded.minimum_stock,tax_rate=excluded.tax_rate,attributes=excluded.attributes,is_active=excluded.is_active,updated_at=now();
 for v_variant in select value from jsonb_array_elements(coalesce(p_payload->'attributes'->'variants','[]'::jsonb)) loop
  insert into public.product_variants(id,business_id,product_id,sku,barcode,attributes,purchase_price,sale_price,minimum_stock,is_active)
  values(coalesce(nullif(v_variant->>'id','')::uuid,gen_random_uuid()),v_business,v_product,nullif(v_variant->>'sku',''),nullif(v_variant->>'barcode',''),coalesce(v_variant->'attributes','{}'::jsonb),coalesce((v_variant->>'purchase_price')::numeric,0),coalesce((v_variant->>'selling_price')::numeric,0),coalesce((v_variant->>'quantity')::numeric,0),coalesce((v_variant->>'active')::boolean,true))
  on conflict(id) do update set sku=excluded.sku,barcode=excluded.barcode,attributes=excluded.attributes,purchase_price=excluded.purchase_price,sale_price=excluded.sale_price,minimum_stock=excluded.minimum_stock,is_active=excluded.is_active;
 end loop;
 update public.sync_operations set status='applied',applied_at=now(),payload=jsonb_set(p_payload,'{result}',to_jsonb(v_product),true),error_message=null where business_id=v_business and operation_key=p_operation_key;
 return jsonb_build_object('status','applied','result',v_product);
end;$$;
revoke all on function public.apply_product_sync(text,text,jsonb) from public;
grant execute on function public.apply_product_sync(text,text,jsonb) to authenticated;