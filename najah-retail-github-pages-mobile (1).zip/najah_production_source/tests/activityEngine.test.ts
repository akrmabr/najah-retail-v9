import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { ACTIVITY_REGISTRY, getActivityDefinition, validateActivityProduct } from '../src/config/activityEngine';
import { BUSINESS_TYPE_OPTIONS } from '../src/config/businessTypes';

test('every existing activity has an explicit engine profile', () => {
  const ids = Object.keys(ACTIVITY_REGISTRY);
  assert.equal(ids.length, 13);
  assert.equal(BUSINESS_TYPE_OPTIONS.length, 13);
  for (const id of ids) {
    const activity = getActivityDefinition(id);
    assert.equal(activity.id, id);
    assert.ok(activity.dashboardMetrics.length > 0, `${id} dashboard metrics`);
    assert.ok(activity.inventoryStrategies.length > 0, `${id} inventory strategy`);
    assert.ok(activity.searchFields.length > 0, `${id} search fields`);
    assert.ok(activity.invoiceFields.length > 0, `${id} invoice fields`);
  }
});

test('frontend registry and approved Supabase migration have the same 13 IDs', () => {
  const registrySql = readFileSync(new URL('../supabase/migrations/014_approved_activity_registry.sql', import.meta.url), 'utf8');
  const registryIds = Object.keys(ACTIVITY_REGISTRY).sort();
  const activityIds = [...registrySql.matchAll(/^\s*\('([a-z][a-z0-9_]*)','[^']*','[^']*',\d+,true\)/gm)].map((match) => match[1]).sort();
  const featureIds = [...registrySql.matchAll(/^\s*\('([a-z][a-z0-9_]*)','product_attributes',true,/gm)].map((match) => match[1]).sort();
  assert.deepEqual(activityIds, registryIds);
  assert.deepEqual(featureIds, registryIds);
});

test('historic vertical IDs resolve to their approved merged activities', () => {
  assert.equal(getActivityDefinition('spare_parts').id, 'auto_parts');
  assert.equal(getActivityDefinition('supermarket').id, 'grocery_supermarket');
  assert.equal(getActivityDefinition('home_furnishings').id, 'furniture_decor');
  assert.equal(getActivityDefinition('cosmetics').id, 'perfume_cosmetics');
  assert.equal(getActivityDefinition('stationery').id, 'bookstore');
  assert.equal(getActivityDefinition('hardware').id, 'hardware');
  assert.equal(getActivityDefinition('general').label, 'نشاط قديم غير مصنّف');
  assert.throws(() => getActivityDefinition('unregistered_vertical'), /Unsupported business activity/);
});

test('activity-specific schemas do not leak mobile and pharmacy fields', () => {
  const mobileFields = new Set(getActivityDefinition('mobile').fields);
  const pharmacyFields = new Set(getActivityDefinition('pharmacy').fields);
  assert.ok(mobileFields.has('imei'));
  assert.ok(mobileFields.has('ram'));
  assert.ok(mobileFields.has('storage'));
  assert.ok(!pharmacyFields.has('imei'));
  assert.ok(!pharmacyFields.has('ram'));
  assert.ok(pharmacyFields.has('scientific_name'));
  assert.ok(pharmacyFields.has('concentration'));
  assert.ok(getActivityDefinition('bookstore').fields.includes('isbn'));
});

test('product validation rejects units and variants outside an activity schema', () => {
  const general = getActivityDefinition('general');
  assert.throws(() => validateActivityProduct(general, { unit: 'جهاز' }), /الوحدة غير مدعومة/);
  assert.throws(() => validateActivityProduct(general, { variants: [{ name: 'x' }] }), /المتغيرات غير مفعّلة/);
  assert.doesNotThrow(() => validateActivityProduct(getActivityDefinition('mobile'), {
    unit: 'جهاز',
    variants: [{ name: '128 GB / أسود' }],
  }));
});