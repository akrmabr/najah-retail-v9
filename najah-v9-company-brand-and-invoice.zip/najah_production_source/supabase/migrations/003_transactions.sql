create or replace function public.app_business_id() returns uuid language sql stable security definer set search_path=public as $$
  select business_id from public.business_members where user_id=auth.uid() and is_active=true limit 1;
$$;
create or replace function public.app_is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.business_members where user_id=auth.uid() and is_active=true and role in ('owner','administrator'));
$$;



alter table public.businesses enable row level security;
drop policy if exists businesses_read on public.businesses;
drop policy if exists businesses_insert on public.businesses;
drop policy if exists businesses_update on public.businesses;
create policy businesses_read on public.businesses for select using (id = public.app_business_id() or created_by = auth.uid());
create policy businesses_insert on public.businesses for insert with check (created_by = auth.uid());
create policy businesses_update on public.businesses for update using (id = public.app_business_id() and public.app_is_admin()) with check (id = public.app_business_id() and public.app_is_admin());

create index if not exists idx_business_members_user on public.business_members(user_id,is_active);
create index if not exists idx_products_business_name on public.products(business_id,name);
create index if not exists idx_products_business_barcode on public.products(business_id,base_barcode);
create index if not exists idx_variants_business_barcode on public.product_variants(business_id,barcode);
create index if not exists idx_sales_business_created on public.sales(business_id,created_at desc);
create index if not exists idx_purchases_business_created on public.purchases(business_id,created_at desc);
create index if not exists idx_stock_business_product on public.stock_movements(business_id,product_id,created_at desc);
create index if not exists idx_audit_business_created on public.audit_logs(business_id,created_at desc);
create index if not exists idx_sync_business_status on public.sync_operations(business_id,status,created_at);

-- Tenant isolation policies. Store users never receive rows from another business.
do $$
declare t text;
begin
  foreach t in array array['branches','business_members','categories','brands','units','products','product_variants','product_barcodes','product_batches','product_serial_numbers','customers','suppliers','sales','sale_items','purchases','purchase_items','stock_movements','payments','expenses','audit_logs','sync_operations'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists tenant_select on public.%I', t);
    execute format('drop policy if exists tenant_insert on public.%I', t);
    execute format('drop policy if exists tenant_update on public.%I', t);
    execute format('drop policy if exists tenant_delete on public.%I', t);
    execute format('create policy tenant_select on public.%I for select using (business_id = public.app_business_id())', t);
    execute format('create policy tenant_insert on public.%I for insert with check (business_id = public.app_business_id())', t);
    execute format('create policy tenant_update on public.%I for update using (business_id = public.app_business_id()) with check (business_id = public.app_business_id())', t);
    execute format('create policy tenant_delete on public.%I for delete using (business_id = public.app_business_id() and public.app_is_admin())', t);
  end loop;
end $$;

alter table public.business_types enable row level security;
drop policy if exists business_types_read on public.business_types;
create policy business_types_read on public.business_types for select using (is_enabled=true or public.app_is_admin());

alter table public.licenses enable row level security;
drop policy if exists licenses_owner_read on public.licenses;
create policy licenses_owner_read on public.licenses for select using (business_id = public.app_business_id() and public.app_is_admin());

-- Automatically maintain updated_at on new tables.
create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
do $$
declare t text;
begin
  foreach t in array array['business_types','businesses','branches','business_members','licenses','categories','brands','customers','suppliers','products'] loop
    execute format('drop trigger if exists %I_updated_at on public.%I', t, t);
    execute format('create trigger %I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

