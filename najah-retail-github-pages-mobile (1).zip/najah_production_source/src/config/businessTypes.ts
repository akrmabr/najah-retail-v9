export type CanonicalBusinessTypeId =
  | 'pharmacy'
  | 'auto_parts'
  | 'grocery_supermarket'
  | 'homeware'
  | 'furniture_decor'
  | 'clothing'
  | 'perfume_cosmetics'
  | 'shoes'
  | 'bookstore'
  | 'mobile'
  | 'building_materials'
  | 'electronics'
  | 'electrical';

export type LegacyBusinessTypeId =
  | 'spare_parts'
  | 'car_accessories'
  | 'grocery'
  | 'supermarket'
  | 'furniture'
  | 'home_furnishings'
  | 'hardware'
  | 'cosmetics'
  | 'perfume'
  | 'stationery'
  | 'general'
  | 'other';

export type BusinessTypeId = CanonicalBusinessTypeId | LegacyBusinessTypeId;

export type BusinessField =
  | 'brand' | 'model' | 'size' | 'color' | 'gender' | 'material' | 'fabric'
  | 'season' | 'style' | 'shade' | 'weight' | 'unit' | 'pack' | 'carton'
  | 'batch_number' | 'expiry_date' | 'serial_number' | 'imei' | 'warranty'
  | 'warranty_start' | 'warranty_end' | 'voltage' | 'power' | 'dimensions'
  | 'length' | 'width' | 'height' | 'scientific_name' | 'dosage' | 'form'
  | 'prescription_required' | 'manufacturer' | 'vehicle' | 'year' | 'part_number'
  | 'tool_type' | 'fragrance_family' | 'pattern' | 'pieces' | 'set'
  | 'ram' | 'storage' | 'network' | 'concentration' | 'wood_type'
  | 'product_type' | 'material_type' | 'grade' | 'accessory_type'
  | 'author' | 'publisher' | 'isbn' | 'edition' | 'subject' | 'category';

export type BusinessTypeConfig = {
  id: BusinessTypeId;
  label: string;
  productLabel: string;
  inventoryLabel: string;
  purchaseLabel: string;
  reportLabel: string;
  fields: BusinessField[];
  units: string[];
  variants: BusinessField[];
  supportsExpiry?: boolean;
  supportsSerials?: boolean;
  supportsImei?: boolean;
};

const common = {
  general: ['قطعة', 'عبوة', 'كرتون'],
  clothing: ['قطعة', 'طقم'],
  pharmacy: ['قرص', 'علبة', 'زجاجة', 'أنبوب', 'حقنة', 'كرتون'],
  weight: ['قطعة', 'كجم', 'جرام', 'لتر', 'مل', 'عبوة', 'كرتون'],
  building: ['قطعة', 'متر', 'متر مربع', 'متر مكعب', 'كجم', 'طن', 'كيس', 'كرتون'],
} as const;

/** The approved 13 business activities, used for onboarding and runtime config. */
export const BUSINESS_TYPES: Record<CanonicalBusinessTypeId, BusinessTypeConfig> = {
  pharmacy: {
    id: 'pharmacy', label: 'صيدلية', productLabel: 'الأدوية والمستلزمات الطبية',
    inventoryLabel: 'مخزون الأدوية والصلاحية', purchaseLabel: 'المشتريات الدوائية',
    reportLabel: 'تقارير الأدوية والصلاحية',
    fields: ['scientific_name', 'concentration', 'dosage', 'form', 'manufacturer', 'batch_number', 'expiry_date', 'prescription_required'],
    units: [...common.pharmacy], variants: ['concentration', 'dosage', 'form', 'batch_number'], supportsExpiry: true,
  },
  auto_parts: {
    id: 'auto_parts', label: 'قطع غيار سيارات', productLabel: 'قطع الغيار وإكسسوارات السيارات',
    inventoryLabel: 'مخزون قطع غيار السيارات', purchaseLabel: 'مشتريات قطع غيار السيارات',
    reportLabel: 'تقارير القطع والمركبات',
    fields: ['part_number', 'brand', 'model', 'vehicle', 'year', 'serial_number', 'accessory_type'],
    units: ['قطعة', 'طقم', 'علبة', 'كرتون'], variants: ['model', 'vehicle'],
    supportsSerials: true,
  },
  grocery_supermarket: {
    id: 'grocery_supermarket', label: 'بقالة وسوبر ماركت', productLabel: 'المواد الغذائية وأصناف السوبر ماركت',
    inventoryLabel: 'مخزون البقالة والسوبر ماركت', purchaseLabel: 'مشتريات المواد الغذائية',
    reportLabel: 'تقارير الأصناف والصلاحية',
    fields: ['unit', 'weight', 'pack', 'carton', 'batch_number', 'expiry_date'],
    units: [...common.weight], variants: [], supportsExpiry: true,
  },
  homeware: {
    id: 'homeware', label: 'أواني منزلية', productLabel: 'الأواني والأدوات المنزلية',
    inventoryLabel: 'مخزون الأواني المنزلية', purchaseLabel: 'مشتريات الأواني المنزلية',
    reportLabel: 'تقارير الأواني والأطقم',
    fields: ['product_type', 'material', 'size', 'color', 'brand', 'pieces', 'set', 'weight'],
    units: ['قطعة', 'طقم', 'كرتون'], variants: ['size', 'color'],
  },
  furniture_decor: {
    id: 'furniture_decor', label: 'أثاث وديكور', productLabel: 'الأثاث وقطع الديكور',
    inventoryLabel: 'مخزون الأثاث والديكور', purchaseLabel: 'مشتريات الأثاث والديكور',
    reportLabel: 'تقارير الموديلات والخامات والأبعاد',
    fields: ['product_type', 'material', 'wood_type', 'fabric', 'color', 'dimensions', 'length', 'width', 'height', 'weight', 'warranty', 'brand', 'model', 'pattern'],
    units: ['قطعة', 'طقم', 'متر', 'كرتون'], variants: ['color', 'dimensions', 'material'],
  },
  clothing: {
    id: 'clothing', label: 'محل ملابس', productLabel: 'الملابس والأصناف',
    inventoryLabel: 'مخزون الملابس والمقاسات', purchaseLabel: 'مشتريات الملابس',
    reportLabel: 'تقارير المقاسات والألوان والمبيعات',
    fields: ['size', 'color', 'gender', 'brand', 'fabric', 'season', 'style'],
    units: [...common.clothing], variants: ['size', 'color'],
  },
  perfume_cosmetics: {
    id: 'perfume_cosmetics', label: 'عطور وكريمات', productLabel: 'العطور والكريمات ومستحضرات التجميل',
    inventoryLabel: 'مخزون العطور والكريمات والصلاحية', purchaseLabel: 'مشتريات العطور والكريمات',
    reportLabel: 'تقارير الماركات والدرجات والصلاحية',
    fields: ['brand', 'manufacturer', 'fragrance_family', 'shade', 'size', 'batch_number', 'expiry_date'],
    units: ['زجاجة', 'عبوة', 'قطعة', 'كرتون'], variants: ['fragrance_family', 'shade', 'size'], supportsExpiry: true,
  },
  shoes: {
    id: 'shoes', label: 'محل أحذية', productLabel: 'الأحذية',
    inventoryLabel: 'مخزون الأحذية والمقاسات', purchaseLabel: 'مشتريات الأحذية',
    reportLabel: 'تقارير المقاسات والألوان والمبيعات',
    fields: ['size', 'color', 'gender', 'brand', 'material', 'style', 'season'],
    units: ['زوج', 'قطعة'], variants: ['size', 'color'],
  },
  bookstore: {
    id: 'bookstore', label: 'محل مكتبة', productLabel: 'الكتب والقرطاسية',
    inventoryLabel: 'مخزون المكتبة والقرطاسية', purchaseLabel: 'مشتريات المكتبة',
    reportLabel: 'تقارير الكتب والتصنيفات',
    fields: ['category', 'author', 'publisher', 'isbn', 'edition', 'subject', 'grade', 'brand', 'color', 'size'],
    units: ['كتاب', 'قطعة', 'دفتر', 'علبة', 'كرتون'], variants: ['edition', 'grade'],
  },
  mobile: {
    id: 'mobile', label: 'هواتف', productLabel: 'الهواتف وإكسسواراتها',
    inventoryLabel: 'مخزون الهواتف والأرقام التسلسلية', purchaseLabel: 'مشتريات الهواتف',
    reportLabel: 'تقارير الهواتف والضمان والأرقام التسلسلية',
    fields: ['brand', 'model', 'ram', 'storage', 'color', 'network', 'imei', 'serial_number', 'warranty'],
    units: ['جهاز', 'قطعة', 'كرتون'], variants: ['ram', 'storage', 'color'], supportsSerials: true, supportsImei: true,
  },
  building_materials: {
    id: 'building_materials', label: 'مواد بناء', productLabel: 'مواد البناء',
    inventoryLabel: 'مخزون مواد البناء والوحدات', purchaseLabel: 'مشتريات مواد البناء',
    reportLabel: 'تقارير الوحدات والأبعاد والكميات',
    fields: ['material_type', 'material', 'unit', 'weight', 'length', 'width', 'height', 'brand'],
    units: [...common.building], variants: [],
  },
  electronics: {
    id: 'electronics', label: 'إلكترونيات', productLabel: 'الأجهزة الإلكترونية',
    inventoryLabel: 'مخزون الإلكترونيات والأرقام التسلسلية', purchaseLabel: 'مشتريات الإلكترونيات',
    reportLabel: 'تقارير الموديلات والضمان',
    fields: ['brand', 'model', 'ram', 'storage', 'serial_number', 'warranty', 'voltage', 'power', 'weight', 'color'],
    units: ['قطعة', 'جهاز', 'كرتون'], variants: ['ram', 'storage', 'color'], supportsSerials: true,
  },
  electrical: {
    id: 'electrical', label: 'أجهزة كهربائية', productLabel: 'الأجهزة الكهربائية',
    inventoryLabel: 'مخزون الأجهزة والضمان', purchaseLabel: 'مشتريات الأجهزة الكهربائية',
    reportLabel: 'تقارير الضمان والأرقام التسلسلية',
    fields: ['brand', 'model', 'serial_number', 'warranty', 'warranty_start', 'warranty_end', 'voltage', 'power', 'color', 'dimensions'],
    units: ['قطعة', 'جهاز', 'كرتون'], variants: ['color'], supportsSerials: true,
  },
};

/** Kept only to read existing installs; these IDs are not offered for new stores. */
export const LEGACY_ACTIVITY_ALIASES: Readonly<Record<LegacyBusinessTypeId, CanonicalBusinessTypeId | 'legacy_generic' | 'legacy_hardware'>> = {
  spare_parts: 'auto_parts',
  car_accessories: 'auto_parts',
  grocery: 'grocery_supermarket',
  supermarket: 'grocery_supermarket',
  furniture: 'furniture_decor',
  home_furnishings: 'furniture_decor',
  hardware: 'legacy_hardware',
  cosmetics: 'perfume_cosmetics',
  perfume: 'perfume_cosmetics',
  stationery: 'bookstore',
  general: 'legacy_generic',
  other: 'legacy_generic',
};

export const BUSINESS_TYPE_OPTIONS = Object.values(BUSINESS_TYPES);
