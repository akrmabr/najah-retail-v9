import React from 'react';
import { logCrash } from '../services/crashReporting';

export default class ErrorBoundary extends React.Component<
  { children: React.ReactNode }, { error: Error | null }
> {
  state: { error: Error | null } = { error: null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) {
    void logCrash(new Error(`${error.message}\n${info.componentStack || ''}`), 'react_render');
  }
  render() {
    if (this.state.error) return (
      <div className="error">
        <h2>حدث خطأ غير متوقع</h2>
        <p>بيانات النشاط المحلية ما زالت آمنة. أُنشئ تقرير فني محلي للمساعدة في التشخيص.</p>
        <button onClick={() => location.reload()}>إعادة تشغيل الواجهة</button>
      </div>
    );
    return this.props.children;
  }
}