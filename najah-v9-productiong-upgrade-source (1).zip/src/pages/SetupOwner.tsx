import { useEffect, useState } from 'react';
import { createInitialOwner, usersCount } from '../services/auth';
import { getCachedLicense } from '../services/license';
import { restoreBackup } from '../services/backup';
import type { User } from '../types/models';
import { BUSINESS_TYPE_OPTIONS } from '../config/businessTypes';
import { setupRemoteBusiness } from '../services/remoteSetup';

export default function SetupOwner({ onDone, onExisting }: { onDone: (user: User) => void; onExisting: () => void }) {
  const license = getCachedLicense();
  const [form, setForm] = useState({
    pharmacyName: license?.pharmacy_name || '',
    ownerName: license?.owner_name || '',
    email: license?.owner_email || '',
    phone: '',
    businessType: license?.business_type_id || 'general',
    password: '',
    confirm: '',
  });
  const [message, setMessage] = useState('');
  const [recovering, setRecovering] = useState(false);
  const recoveryDetected = localStorage.getItem('alshifaa_setup_completed') === 'true';

  useEffect(() => {
    usersCount().then((count) => {
      if (count > 0) onExisting();
    });
  }, [onExisting]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage('');
    if (form.password.length < 8) return setMessage('كلمة المرور يجب ألا تقل عن 8 أحرف.');
    if (form.password !== form.confirm) return setMessage('تأكيد كلمة المرور غير مطابق.');
    try {
      const remote = await setupRemoteBusiness({ name: form.pharmacyName.trim(), ownerName: form.ownerName.trim(), email: form.email.trim(), phone: form.phone.trim(), password: form.password, businessTypeId: form.businessType });
      // Use the server business id as the local tenant id so offline records
      // and queued operations remain attributable to the same business.
      if (remote.business_id) localStorage.setItem('alshifaa_pharmacy_id', remote.business_id);
      const user = await createInitialOwner({
        pharmacyName: form.pharmacyName.trim(),
        ownerName: form.ownerName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        businessType: form.businessType,
        password: form.password,
      });
      onDone(user);
    } catch (error: any) {
      const text = error?.message || 'تعذر إنشاء النشاط أو حساب المالك.';
      setMessage(text);
      if (text.includes('مسبقاً')) {
        setTimeout(onExisting, 700);
      }
    }
  }

  async function restore(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setMessage('');
    setRecovering(true);
    try {
      await restoreBackup(file);
      setMessage('تمت استعادة البيانات. اضغط الانتقال لتسجيل الدخول.');
      setTimeout(onExisting, 700);
    } catch (error: any) {
      setMessage(error?.message || 'تعذر استعادة النسخة الاحتياطية.');
    } finally {
      setRecovering(false);
      e.target.value = '';
    }
  }

  const set = (key: string, value: string) => setForm((f) => ({ ...f, [key]: value }));

  return (
    <div className="onboarding">
      <form onSubmit={submit} className="onboarding-card owner-setup">
        <img src="brand-logo.png" alt="النجاح لإدارة الصيدليات" />
        <h1>إعداد حساب مالك النشاط</h1>
        <p>بعد تفعيل الترخيص، أنشئ حساب المالك المحلي لإدارة نشاطك التجاري على هذا الجهاز.</p>
        <input value={form.pharmacyName} onChange={(e) => set('pharmacyName', e.target.value)} placeholder="اسم المتجر / النشاط" required />
        <input value={form.ownerName} onChange={(e) => set('ownerName', e.target.value)} placeholder="اسم المالك" required />
        <input value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="البريد الإلكتروني" type="email" required />
        <input value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="رقم الهاتف" inputMode="tel" />
        <select value={form.businessType} onChange={(e) => set('businessType', e.target.value)} required>
          <option value="">اختر نوع النشاط</option>
          {BUSINESS_TYPE_OPTIONS.map((activity) => <option key={activity.id} value={activity.id}>{activity.label}</option>)}
        </select>
        <input value={form.password} onChange={(e) => set('password', e.target.value)} placeholder="كلمة المرور" type="password" autoComplete="new-password" required />
        <input value={form.confirm} onChange={(e) => set('confirm', e.target.value)} placeholder="تأكيد كلمة المرور" type="password" autoComplete="new-password" required />
        <button className="primary">إنشاء الحساب والدخول</button>
        {recoveryDetected && <div className="recovery-warning"><b>تم العثور على ترخيص سابق لكن قاعدة البيانات المحلية فارغة.</b><span>لا تنشئ حساباً جديداً إذا كنت تملك نسخة احتياطية. استعدها أولاً حتى لا تبدأ صيدلية جديدة.</span><label className="upload">{recovering ? 'جاري الاستعادة...' : 'استعادة نسخة JSON'}<input hidden type="file" accept="application/json" onChange={restore} disabled={recovering} /></label></div>}
        {message && <div className="alert">{message}</div>}
        {message.includes('مسبقاً') && <button type="button" className="ghost" onClick={onExisting}>الانتقال إلى تسجيل الدخول</button>}
        <div className="login-support">الدعم والمبيعات: <a href="tel:0121164581">0121164581</a> — واتساب: <a href="https://wa.me/249969696787">0969696787</a></div>
      </form>
    </div>
  );
}
