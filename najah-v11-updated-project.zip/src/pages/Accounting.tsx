import { useEffect, useState } from 'react';
import { financialStatements, generalLedger, trialBalance } from '../services/accounting';
import { money } from '../utils/ids';

export default function Accounting() {
  const [rows, setRows] = useState<any[]>([]);
  const [ledger, setLedger] = useState<any[]>([]);
  const [statements, setStatements] = useState<any>();
  useEffect(() => {
    Promise.all([trialBalance(), generalLedger(), financialStatements()]).then(([balance, entries, reports]) => {
      setRows(balance); setLedger(entries); setStatements(reports);
    });
  }, []);
  const debit = rows.reduce((sum, row) => sum + row.debit, 0);
  const credit = rows.reduce((sum, row) => sum + row.credit, 0);
  return (
    <section>
      <h1>المحاسبة</h1>
      <div className="grid cards">
        <div className="card stat"><span>إجمالي المدين</span><b>{money(debit)}</b></div>
        <div className="card stat"><span>إجمالي الدائن</span><b>{money(credit)}</b></div>
        <div className="card stat"><span>فرق ميزان المراجعة</span><b>{money(debit - credit)}</b></div>
        <div className="card stat"><span>صافي الربح</span><b>{money(statements?.income.netProfit || 0)}</b></div>
      </div>
      {statements && <div className="grid three">
        <div className="card"><h3>قائمة الدخل</h3>
          <p>الإيرادات: <b>{money(statements.income.revenue)}</b></p>
          <p>تكلفة المبيعات: <b>{money(statements.income.cogs)}</b></p>
          <p>المصروفات: <b>{money(statements.income.expenses)}</b></p>
          <p>صافي الربح: <b>{money(statements.income.netProfit)}</b></p>
        </div>
        <div className="card"><h3>الميزانية</h3>
          <p>الأصول: <b>{money(statements.balance.assets)}</b></p>
          <p>الالتزامات: <b>{money(statements.balance.liabilities)}</b></p>
          <p>حقوق الملكية والأرباح: <b>{money(statements.balance.liabilitiesAndEquity)}</b></p>
          <p>فرق التوازن: <b>{money(statements.balance.difference)}</b></p>
        </div>
        <div className="card"><h3>التدفق النقدي</h3>
          <p>داخل: <b>{money(statements.cashFlow.cashIn)}</b></p>
          <p>خارج: <b>{money(statements.cashFlow.cashOut)}</b></p>
          <p>الصافي: <b>{money(statements.cashFlow.net)}</b></p>
        </div>
      </div>}
      <div className="card"><h3>ميزان المراجعة</h3>
        <table><thead><tr><th>الكود</th><th>الحساب</th><th>النوع</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead>
          <tbody>{rows.map((row) => <tr key={row.id}><td>{row.code}</td><td>{row.name}</td><td>{row.type}</td>
            <td>{money(row.debit)}</td><td>{money(row.credit)}</td><td>{money(row.balance)}</td></tr>)}</tbody></table>
      </div>
      <div className="card"><h3>دفتر الأستاذ العام</h3>
        <table><thead><tr><th>التاريخ</th><th>الحساب</th><th>البيان</th><th>مدين</th><th>دائن</th></tr></thead>
          <tbody>{ledger.slice(0, 500).map((row) => <tr key={row.id}>
            <td>{row.date}</td><td>{row.account_code} — {row.account_name}</td>
            <td>{row.description}</td><td>{money(row.debit)}</td><td>{money(row.credit)}</td>
          </tr>)}</tbody></table>
        {!ledger.length && <p className="empty">لا توجد قيود محاسبية بعد.</p>}
      </div>
    </section>
  );
}