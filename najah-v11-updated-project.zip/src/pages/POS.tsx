import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import type { KeyboardEvent } from 'react';
import type { PaymentMethod, TaxRule, User } from '../types/models';
import { getBusinessContext } from '../services/businessContext';
import { db } from '../services/db';
import { productSearchOptions, type ProductSearchOption } from '../services/inventory';
import { completeSale } from '../services/sales';
import { resolveTaxRate } from '../services/tax';
import { money, uid } from '../utils/ids';
import { printInvoice } from '../services/invoice';
import BarcodeScanner from '../components/BarcodeScanner';
import { roundMoney } from '../domain/calculations';
import { useBarcodeWedge } from '../hooks/useBarcodeWedge';

type Line = {
  id: string;
  option: ProductSearchOption;
  quantity: number;
  discount: number;
  serialId?: string;
};

export default function POS({ user }: { user: User }) {
  const activity = useLiveQuery(getBusinessContext, []) || null;
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const serials = useLiveQuery(() => db.serial_numbers.where('status').equals('in_stock').toArray(), []) || [];
  const taxRules = (useLiveQuery(() => db.tax_rules.toArray(), []) || []) as TaxRule[];
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ProductSearchOption[]>([]);
  const [cart, setCart] = useState<Line[]>([]);
  const [paid, setPaid] = useState(0);
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [customerId, setCustomerId] = useState('');
  const [message, setMessage] = useState('');
  const [scannerOpen, setScannerOpen] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const tracked = Boolean(activity?.posRules.requireSerialSelection);

  useEffect(() => {
    let active = true;
    productSearchOptions(query).then((rows) => { if (active) setResults(rows); }).catch(() => setResults([]));
    return () => { active = false; };
  }, [query]);

  function add(option: ProductSearchOption) {
    setCart((current) => {
      const existing = !tracked && current.find((line) =>
        line.option.product.id === option.product.id && line.option.variant?.id === option.variant?.id);
      if (existing) return current.map((line) => line.id === existing.id ? { ...line, quantity: line.quantity + 1 } : line);
      return [...current, { id: uid('cart'), option, quantity: 1, discount: 0 }];
    });
    setQuery('');
    setMessage('');
    input.current?.focus();
  }

  async function findAndAdd(code: string) {
    const found = await productSearchOptions(code);
    const normalized = code.trim().toLowerCase();
    const exact = found.find((row) =>
      [row.variant?.barcode, row.product.barcode, row.product.alternative_barcode, row.variant?.sku, row.product.sku]
        .some((value) => String(value || '').toLowerCase() === normalized)) || found[0];
    if (exact) add(exact);
    else {
      setQuery(code);
      setMessage('المنتج غير موجود. يمكنك إضافته من صفحة المنتجات.');
    }
  }
  useBarcodeWedge((code)=>{void findAndAdd(code)});

  async function handleSearchEnter(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    if (query.trim()) await findAndAdd(query.trim());
  }

  const totals = cart.reduce((summary, line) => {
    const subtotal = roundMoney(Math.max(0, line.quantity) * line.option.price);
    const discount = roundMoney(Math.min(Math.max(0, line.discount), subtotal));
    const tax = roundMoney((subtotal - discount) * resolveTaxRate(line.option.product, taxRules) / 100);
    return {
      subtotal: roundMoney(summary.subtotal + subtotal),
      discount: roundMoney(summary.discount + discount),
      tax: roundMoney(summary.tax + tax),
      total: roundMoney(summary.total + subtotal - discount + tax),
    };
  }, { subtotal: 0, discount: 0, tax: 0, total: 0 });

  async function sell() {
    setMessage('');
    if (!cart.length) return setMessage('السلة فارغة.');
    if ((method === 'Credit' || activity?.posRules.requireCustomer) && !customerId) {
      return setMessage('اختر العميل لإكمال هذه العملية.');
    }
    if (tracked && cart.some((line) => !line.serialId)) {
      return setMessage('اختر الرقم التسلسلي/IMEI لكل جهاز في السلة.');
    }
    if (method !== 'Credit' && paid < totals.total) {
      return setMessage('المبلغ المدفوع أقل من الإجمالي. اضغط «استخدام الإجمالي» أو اختر البيع الآجل.');
    }
    try {
      const sale = await completeSale(user.id, cart.map((line) => ({
        product_id: line.option.product.id,
        variant_id: line.option.variant?.id,
        serial_id: line.serialId,
        quantity: line.quantity,
        unit_price: line.option.price,
        discount: line.discount / Math.max(1, line.quantity),
        tax: resolveTaxRate(line.option.product, taxRules),
        activity_data: line.option.variant?.attributes || {},
      })), paid, method, customerId || undefined);
      setCart([]); setPaid(0); setCustomerId(''); setMethod('Cash');
      try {
        await printInvoice(sale.id);
        setMessage('تم البيع وحفظ العملية وفتح معاينة الفاتورة.');
      } catch (printError: any) {
        setMessage(`تم البيع بنجاح، لكن تعذرت المعاينة. ${printError?.message || ''}`);
      }
    } catch (error: any) {
      setMessage(error?.message || 'تعذر إكمال البيع.');
    }
  }

  const selectedSerials = new Set(cart.map((line) => line.serialId).filter(Boolean));

  return (
    <section>
      <h1>نقطة بيع {activity?.label || 'النشاط'}</h1>
      <div className="grid two">
        <div className="card">
          <div className="pos-tools">
            <button type="button" className="primary" onClick={() => setScannerOpen(true)}>مسح بالكاميرا</button>
            <span>أو استخدم قارئ USB/Bluetooth أو اكتب الباركود.</span>
          </div>
          <input ref={input} autoFocus value={query} onChange={(event) => setQuery(event.target.value)}
            placeholder="امسح الباركود أو ابحث عن منتج/متغير/IMEI" onKeyDown={handleSearchEnter} />
          <div className="list">{results.map((option) => (
            <button key={`${option.product.id}:${option.variant?.id || 'base'}`} onClick={() => add(option)}>
              {option.label} <small>{option.barcode}</small> <b>{money(option.price)}</b>
            </button>
          ))}</div>
        </div>
        <div className="card">
          <h3>السلة</h3>
          <table>
            <thead><tr><th>الصنف</th><th>الكمية</th>{tracked && <th>IMEI/Serial</th>}<th>الخصم</th><th>الإجمالي</th><th /></tr></thead>
            <tbody>{cart.map((line) => {
              const available = serials.filter((serial) =>
                serial.product_id === line.option.product.id &&
                (!line.option.variant || serial.variant_id === line.option.variant.id) &&
                (!selectedSerials.has(serial.id) || serial.id === line.serialId));
              return (
                <tr key={line.id}>
                  <td>{line.option.label}</td>
                  <td><input type="number" min={activity?.inventoryRules.allowFractional ? 0.001 : 1}
                    step={activity?.inventoryRules.allowFractional ? 0.001 : 1}
                    disabled={tracked} value={line.quantity}
                    onChange={(event) => setCart((current) => current.map((item) =>
                      item.id === line.id ? { ...item, quantity: Math.max(activity?.inventoryRules.allowFractional ? 0.001 : 1, Number(event.target.value) || 1) } : item))} /></td>
                  {tracked && <td><select value={line.serialId || ''} onChange={(event) => setCart((current) =>
                    current.map((item) => item.id === line.id ? { ...item, serialId: event.target.value || undefined } : item))}>
                    <option value="">اختر الرقم</option>
                    {available.map((serial) => <option key={serial.id} value={serial.id}>{serial.imei || serial.serial_number}</option>)}
                  </select></td>}
                  <td><input type="number" min={0} max={line.quantity * line.option.price} step="0.01"
                    value={line.discount} onChange={(event) => setCart((current) => current.map((item) =>
                      item.id === line.id ? { ...item, discount: Math.max(0, Number(event.target.value) || 0) } : item))} /></td>
                  <td>{money(line.option.price * line.quantity)}</td>
                  <td><button onClick={() => setCart((current) => current.filter((item) => item.id !== line.id))}>حذف</button></td>
                </tr>
              );
            })}</tbody>
          </table>
          <div className="invoice-summary">
            <p>الفرعي: {money(totals.subtotal)}</p>
            <p>الخصم: {money(totals.discount)}</p>
            <p>الضريبة: {money(totals.tax)}</p>
            <h2>الإجمالي: {money(totals.total)}</h2>
          </div>
          <select value={method} onChange={(event) => setMethod(event.target.value as PaymentMethod)}>
            <option value="Cash">نقدي</option><option value="Credit">آجل / حساب عميل</option>
            <option value="Card">بطاقة</option><option value="Bank">تحويل بنكي</option>
          </select>
          {(method === 'Credit' || activity?.posRules.requireCustomer) && <select value={customerId} onChange={(event) => setCustomerId(event.target.value)}>
            <option value="">اختر العميل</option>{customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name}</option>)}
          </select>}
          <div className="payment-row">
            <input type="number" min={0} step="0.01" value={paid} onChange={(event) => setPaid(Math.max(0, Number(event.target.value) || 0))}
              placeholder={method === 'Credit' ? 'المدفوع الآن (اختياري)' : 'المبلغ المدفوع'} />
            {method !== 'Credit' && <button type="button" onClick={() => setPaid(totals.total)}>استخدام الإجمالي</button>}
          </div>
          <p>المتبقي: {money(Math.max(0, totals.total - paid))}</p>
          {paid > totals.total && <p>الباقي للعميل: {money(paid - totals.total)}</p>}
          <button className="primary" onClick={sell}>إكمال البيع وطباعة</button>
          {message && <div className="alert">{message}</div>}
        </div>
      </div>
      <BarcodeScanner open={scannerOpen} onClose={() => setScannerOpen(false)} onDetected={findAndAdd} />
    </section>
  );
}