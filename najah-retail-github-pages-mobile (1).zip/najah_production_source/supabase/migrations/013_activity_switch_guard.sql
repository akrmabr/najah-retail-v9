-- Activity changes can affect product schemas, stock, sales, reporting,
-- licences and sync payloads. Do not permit an in-place switch without an
-- explicit compatibility-checked migration workflow.
create or replace function public.prevent_business_activity_switch()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  -- Permit assigning a type to a legacy business that has never had one.
  -- Once set, the type is immutable through ordinary updates.
  if old.business_type_id is not null
     and new.business_type_id is distinct from old.business_type_id then
    raise exception using
      errcode = '23514',
      message = 'activity_migration_required';
  end if;
  return new;
end;
$$;

drop trigger if exists businesses_activity_immutable on public.businesses;
create trigger businesses_activity_immutable
before update of business_type_id on public.businesses
for each row
execute function public.prevent_business_activity_switch();