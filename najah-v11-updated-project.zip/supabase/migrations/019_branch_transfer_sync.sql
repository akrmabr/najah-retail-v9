create or replace function public.apply_stock_transfer_sync(
  p_operation_key text,p_operation_type text,p_payload jsonb
) returns jsonb language plpgsql security invoker set search_path=public as $$
declare
 v_business uuid:=public.app_business_id(); v_transfer jsonb:=p_payload->'transfer';
 v_transfer_id uuid; v_item jsonb; v_existing text;
begin
 if v_business is null then raise exception 'business_not_authenticated'; end if;
 if not public.app_has_feature('multi_branch') then raise exception 'feature_not_available'; end if;
 select status into v_existing from public.sync_operations where business_id=v_business and operation_key=p_operation_key;
 if v_existing='applied' then return jsonb_build_object('status','applied','result',p_payload->>'transfer_id'); end if;
 insert into public.sync_operations(business_id,operation_key,operation_type,payload,status)
 values(v_business,p_operation_key,p_operation_type,p_payload,'pending')
 on conflict(business_id,operation_key) do update set payload=excluded.payload,status='pending',error_message=null;
 if p_operation_type='stock_transfer_send' then
  v_transfer_id:=(v_transfer->>'id')::uuid;
  insert into public.stock_transfers(id,business_id,from_branch_id,to_branch_id,status,notes,created_by,sent_at)
  values(v_transfer_id,v_business,(v_transfer->>'from_branch_id')::uuid,(v_transfer->>'to_branch_id')::uuid,'sent',v_transfer->>'notes',auth.uid(),now())
  on conflict(id) do update set status='sent',sent_at=coalesce(public.stock_transfers.sent_at,now()),updated_at=now();
  for v_item in select value from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
   insert into public.stock_transfer_items(id,business_id,transfer_id,product_id,variant_id,batch_id,quantity)
   values((v_item->>'id')::uuid,v_business,v_transfer_id,(v_item->>'product_id')::uuid,nullif(v_item->>'variant_id','')::uuid,nullif(v_item->>'batch_id','')::uuid,(v_item->>'quantity')::numeric)
   on conflict(id) do nothing;
   if not exists(select 1 from public.stock_movements where business_id=v_business and source_type='stock_transfer_send' and source_id=v_transfer_id and product_id=(v_item->>'product_id')::uuid and batch_id is not distinct from nullif(v_item->>'batch_id','')::uuid) then
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,reason,created_by)
    values(v_business,(v_transfer->>'from_branch_id')::uuid,(v_item->>'product_id')::uuid,nullif(v_item->>'variant_id','')::uuid,nullif(v_item->>'batch_id','')::uuid,'transfer_out',-(v_item->>'quantity')::numeric,'stock_transfer_send',v_transfer_id,'تحويل بين الفروع',auth.uid());
   end if;
  end loop;
 elsif p_operation_type='stock_transfer_receive' then
  v_transfer_id:=(p_payload->>'transfer_id')::uuid;
  select to_jsonb(t) into v_transfer from public.stock_transfers t where t.id=v_transfer_id and t.business_id=v_business for update;
  if v_transfer is null then raise exception 'transfer_not_found'; end if;
  if (v_transfer->>'status') not in('sent','received') then raise exception 'transfer_not_receivable'; end if;
  for v_item in select to_jsonb(i) from public.stock_transfer_items i where i.transfer_id=v_transfer_id and i.business_id=v_business loop
   if not exists(select 1 from public.stock_movements where business_id=v_business and source_type='stock_transfer_receive' and source_id=v_transfer_id and product_id=(v_item->>'product_id')::uuid and batch_id is not distinct from nullif(v_item->>'batch_id','')::uuid) then
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,reason,created_by)
    values(v_business,(v_transfer->>'to_branch_id')::uuid,(v_item->>'product_id')::uuid,nullif(v_item->>'variant_id','')::uuid,nullif(v_item->>'batch_id','')::uuid,'transfer_in',(v_item->>'quantity')::numeric,'stock_transfer_receive',v_transfer_id,'استلام تحويل فرع',auth.uid());
   end if;
  end loop;
  update public.stock_transfers set status='received',received_at=coalesce(received_at,now()),updated_at=now() where id=v_transfer_id;
 else raise exception 'unsupported_transfer_operation';
 end if;
 update public.sync_operations set status='applied',applied_at=now(),payload=jsonb_set(p_payload,'{result}',to_jsonb(v_transfer_id),true),error_message=null
 where business_id=v_business and operation_key=p_operation_key;
 return jsonb_build_object('status','applied','result',v_transfer_id);
end;$$;
revoke all on function public.apply_stock_transfer_sync(text,text,jsonb) from public;
grant execute on function public.apply_stock_transfer_sync(text,text,jsonb) to authenticated;