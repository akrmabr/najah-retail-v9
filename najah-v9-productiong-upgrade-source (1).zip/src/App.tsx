import {NavLink,Route,Routes,Navigate} from 'react-router-dom';
import {useEffect,useState} from 'react';
import {currentUser,logout,usersCount,can} from './services/auth';
import type {User} from './types/models';
import Dashboard from './pages/Dashboard'; import POS from './pages/POS'; import SalesHistory from './pages/SalesHistory'; import Products from './pages/Products'; import Inventory from './pages/Inventory'; import StockCount from './pages/StockCount'; import Purchases from './pages/Purchases'; import People from './pages/People'; import SimpleTablePage from './pages/SimpleTablePage'; import Payments from './pages/Payments'; import Returns from './pages/Returns'; import Reports from './pages/Reports'; import Settings from './pages/Settings'; import License from './pages/License'; import Backup from './pages/Backup'; import Users from './pages/Users'; import Login from './pages/Login'; import Activation from './pages/Activation'; import SetupOwner from './pages/SetupOwner';
import {licenseGate} from './services/license'; import {db} from './services/db'; import {useLiveQuery} from 'dexie-react-hooks'; import ErrorBoundary from './components/ErrorBoundary'; import OfflineBadge from './components/OfflineBadge'; import {getBusinessContext,getBusinessSettings} from './services/businessContext';

type NavItem=[string,string,string,string];
const nav:NavItem[]=[['/','الرئيسية','▦','dashboard'],['/pos','نقطة البيع','🛒','pos'],['/sales','سجل المبيعات','▤','sales'],['/products','المنتجات','◇','products'],['/inventory','المخزون','▣','inventory'],['/stock-count','الجرد الدوري','◫','inventory'],['/purchases','المشتريات','◈','purchases'],['/customers','العملاء','👥','customers'],['/suppliers','الموردون','⌂','suppliers'],['/returns','المرتجعات','↩','returns'],['/expenses','المصروفات','◍','expenses'],['/payments','المدفوعات','▤','payments'],['/reports','التقارير','≋','reports'],['/users','المستخدمون','♙','users'],['/settings','الإعدادات','⚙','settings'],['/license','الترخيص','⌁','license'],['/backup','النسخ الاحتياطي','⇩','backup']];
function Protected({user,area,children}:{user:User;area:string;children:any}){return can(user,area)?children:<div className="card access-denied"><h2>لا توجد صلاحية</h2><p>هذا القسم متاح للمدير أو المستخدم الذي منحه المدير هذه الصلاحية.</p></div>}
export default function App(){
 const [user,setUser]=useState<User|null|undefined>(); const [hasUsers,setHasUsers]=useState<boolean|undefined>(); const [licenseTick,setLicenseTick]=useState(0); const settings=useLiveQuery(()=>db.settings.get('settings'),[]);
 useEffect(()=>{let alive=true; currentUser().then(u=>{if(alive&&(u||!localStorage.getItem('alshifaa_session')))setUser(u)}); usersCount().then(c=>{if(alive)setHasUsers(c>0)}); return()=>{alive=false}},[licenseTick]);
 if(user===undefined||hasUsers===undefined)return <div className="center">جاري التحميل...</div>;
 const activity=useLiveQuery(getBusinessContext,[])||{label:'نشاط تجاري',productLabel:'المنتجات',inventoryLabel:'المخزون',purchaseLabel:'المشتريات',reportLabel:'التقارير'};
 const businessSettings=useLiveQuery(getBusinessSettings,[])||{};
 const labels:Record<string,string>={pos:`نقطة بيع ${activity.label}`,products:activity.productLabel,inventory:activity.inventoryLabel,purchases:activity.purchaseLabel,reports:activity.reportLabel};
 const gate=licenseGate(); if(!gate.ok&&!hasUsers)return <Activation onActivated={()=>setLicenseTick(x=>x+1)}/>; if(gate.ok&&!hasUsers)return <SetupOwner onDone={(u)=>{setUser(u);setHasUsers(true)}} onExisting={()=>{setHasUsers(true);setUser(null)}}/>; if(!user)return <Login onLogin={setUser}/>;
 return <ErrorBoundary><div className="app"><aside><div className="brand"><img src="brand-logo.png" alt="النجاح"/><span>النجاح</span></div><div className="activity-chip"><strong>{businessSettings.business_name||businessSettings.pharmacy_name||'نشاط تجاري'}</strong><small>{activity.label}</small></div>{nav.filter(([,,,area])=>can(user,area)).map(([to,defaultLabel,icon,area])=><NavLink key={to} to={to} end={to==='/'}><span className="nav-ico">{icon}</span><span>{to==='/stock-count'?'الجرد الدوري':labels[area]||defaultLabel}</span></NavLink>)}<div className="provider-card"><b>النجاح لإدارة المحال التجارية</b><span>الدعم والمبيعات</span><a href="tel:0121164581">اتصال: 0121164581</a><a href="https://wa.me/249969696787">واتساب: 0969696787</a></div><button className="ghost" onClick={()=>{logout();setUser(null)}}>تسجيل الخروج</button></aside><main><header><div className="page-title"><div className="header-client-logo">{settings?.logo?<img src={settings.logo} alt="شعار النشاط"/>:<img src="brand-logo.png" alt="النجاح"/>}</div><div><h2>{businessSettings.business_name||businessSettings.pharmacy_name||'النجاح لإدارة المحال التجارية'}</h2><p>{activity.label} — نظام إدارة المبيعات والمخزون</p></div></div><div className="header-actions"><OfflineBadge/><span className="user-chip">{user.name} — {user.role}</span></div></header><Routes>
  <Route path="/" element={<Dashboard user={user}/>}/>
  <Route path="/pos" element={<Protected user={user} area="pos"><POS user={user}/></Protected>}/>
  <Route path="/sales" element={<Protected user={user} area="sales"><SalesHistory user={user}/></Protected>}/>
  <Route path="/products" element={<Protected user={user} area="products"><Products user={user}/></Protected>}/>
  <Route path="/inventory" element={<Protected user={user} area="inventory"><Inventory user={user}/></Protected>}/>
  <Route path="/stock-count" element={<Protected user={user} area="inventory"><StockCount user={user}/></Protected>}/>
  <Route path="/purchases" element={<Protected user={user} area="purchases"><Purchases user={user}/></Protected>}/>
  <Route path="/customers" element={<Protected user={user} area="customers"><People type="customers" user={user}/></Protected>}/>
  <Route path="/suppliers" element={<Protected user={user} area="suppliers"><People type="suppliers" user={user}/></Protected>}/>
  <Route path="/returns" element={<Protected user={user} area="returns"><Returns user={user}/></Protected>}/>
  <Route path="/expenses" element={<Protected user={user} area="expenses"><SimpleTablePage table="expenses" title="المصروفات" creatable user={user}/></Protected>}/>
  <Route path="/payments" element={<Protected user={user} area="payments"><Payments user={user}/></Protected>}/>
  <Route path="/reports" element={<Protected user={user} area="reports"><Reports/></Protected>}/>
  <Route path="/users" element={<Protected user={user} area="users"><Users user={user}/></Protected>}/>
  <Route path="/settings" element={<Protected user={user} area="settings"><Settings/></Protected>}/>
  <Route path="/license" element={<Protected user={user} area="license"><License/></Protected>}/>
  <Route path="/backup" element={<Protected user={user} area="backup"><Backup user={user}/></Protected>}/>
  <Route path="*" element={<Navigate to="/"/>}/>
 </Routes></main></div></ErrorBoundary>;
}
