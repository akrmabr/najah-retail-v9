import { useState } from 'react';
import { getCachedLicense, licenseGate, validateLicense, clearLicense } from '../services/license';
import { getBusinessSettings } from '../services/businessContext';
import { useLiveQuery } from 'dexie-react-hooks';
export default function License() {
  const settings = useLiveQuery(getBusinessSettings, []) || {};
  const [endpoint, setEndpoint] = useState(localStorage.getItem('alshifaa_license_endpoint') || ''); const [key, setKey] = useState(''); const [message, setMessage] = useState(''); const license = getCachedLicense(); const gate = licenseGate();
  async function validate() { try { localStorage.setItem('alshifaa_license_endpoint', endpoint); const result = await validateLicense(endpoint, key, String(settings.business_type || '')); setMessage(`تم التحقق بنجاح: ${result.status}`); } catch (error: any) { setMessage(error?.message || 'تعذر التحقق من الترخيص.'); } }
  return <section><h1>الترخيص</h1><div className="card"><p>{gate.message}</p><input value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="رابط خادم التراخيص" dir="ltr"/><input value={key} onChange={(e) => setKey(e.target.value)} placeholder="مفتاح الترخيص"/><button className="primary" onClick={validate}>تحقق وتفعيل</button><button className="ghost" onClick={() => { clearLicense(); location.reload(); }}>مسح الترخيص المحلي</button>{message&&<div className="alert">{message}</div>}{license&&<div className="license-summary"><p><b>حالة الترخيص:</b> {license.status}</p><p><b>نوع الترخيص:</b> {license.license_type==='LIFETIME'?'مدى الحياة':'محدد المدة'}</p><p><b>اسم النشاط:</b> {license.pharmacy_name || '—'}</p><p><b>تاريخ الانتهاء:</b> {license.license_type==='LIFETIME'?'لا ينتهي':license.expires_at?.slice(0,10)}</p></div>}</div></section>
}
