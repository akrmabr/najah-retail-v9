import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../services/db';
import {
  pullServerSnapshot, retryAllFailed, retryOperation, syncPendingOperations,
} from '../services/sync';

export default function SyncCenter() {
  const rows = useLiveQuery(
    () => db.sync_operations.orderBy('created_at').reverse().limit(200).toArray(), [],
  ) || [];
  const settings = useLiveQuery(() => db.settings.get('settings'), []);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function run(work: () => Promise<void>) {
    if (busy) return;
    setBusy(true);
    setMessage('');
    try { await work(); }
    catch (error: any) { setMessage(error?.message || 'تعذر إكمال المزامنة.'); }
    finally { setBusy(false); }
  }

  async function push() {
    const result = await syncPendingOperations();
    setMessage(`رفع العمليات: تمت المحاولة ${result.attempted} — نجح ${result.applied} — فشل ${result.failed}`);
  }

  async function pull() {
    const result = await pullServerSnapshot();
    const count = Object.values(result.downloaded).reduce((sum, value) => sum + Number(value), 0);
    setMessage(`اكتمل تنزيل تحديثات الخادم والتحقق منها: ${count} سجل.`);
  }

  async function fullSync() {
    const pushed = await syncPendingOperations();
    if (pushed.failed) {
      setMessage(`تعذر رفع ${pushed.failed} عملية. عالج العمليات الفاشلة قبل تنزيل بيانات الخادم.`);
      return;
    }
    const pulled = await pullServerSnapshot();
    const count = Object.values(pulled.downloaded).reduce((sum, value) => sum + Number(value), 0);
    setMessage(`اكتملت المزامنة الثنائية: رُفعت ${pushed.applied} عملية ونُزّل ${count} سجل.`);
  }

  return (
    <section>
      <h1>مركز المزامنة</h1>
      <div className="card">
        <p>آخر رفع/مزامنة: {settings?.last_sync_at ? new Date(settings.last_sync_at).toLocaleString('ar') : 'لم تتم بعد'}</p>
        <p>آخر تنزيل: {settings?.last_pull_at ? new Date(settings.last_pull_at).toLocaleString('ar') : 'لم يتم بعد'}</p>
        <div className="button-row">
          <button className="primary" disabled={busy} onClick={() => run(fullSync)}>
            {busy ? 'جارٍ التنفيذ…' : 'مزامنة ثنائية الآن'}
          </button>
          <button disabled={busy} onClick={() => run(push)}>رفع العمليات المحلية</button>
          <button disabled={busy} onClick={() => run(pull)}>تنزيل تحديثات الخادم</button>
          <button className="ghost" disabled={busy} onClick={() => run(async () => {
            const count = await retryAllFailed();
            setMessage(`تمت إعادة ${count} عملية إلى الطابور.`);
          })}>إعادة كل العمليات الفاشلة</button>
        </div>
        {message && <div className="alert">{message}</div>}
      </div>
      <div className="card">
        <table>
          <thead><tr><th>العملية</th><th>الحالة</th><th>المحاولات</th><th>التاريخ</th><th>الخطأ</th><th>إجراء</th></tr></thead>
          <tbody>{rows.map((row) => (
            <tr key={row.id}>
              <td>{row.operation_type}</td>
              <td><span className={`status ${row.status === 'applied' ? 'ok' : row.status === 'failed' || row.status === 'conflict' ? 'bad' : ''}`}>{row.status}</span></td>
              <td>{row.attempts}</td>
              <td>{new Date(row.created_at).toLocaleString('ar')}</td>
              <td>{row.last_error || '—'}</td>
              <td>{row.status !== 'applied' && <button disabled={busy} onClick={() => run(async () => {
                await retryOperation(row.id);
                setMessage('أُعيدت العملية إلى الطابور.');
              })}>إعادة</button>}</td>
            </tr>
          ))}</tbody>
        </table>
        {!rows.length && <p className="empty">لا توجد عمليات مزامنة.</p>}
      </div>
    </section>
  );
}