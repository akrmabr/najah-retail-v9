-- Production reporting and purchase-return primitives.
-- All views are tenant-filtered through app_business_id().

create or replace view public.business_stock_balances as
select sm.business_id, sm.branch_id, sm.product_id, sm.variant_id, sm.batch_id,
       sum(sm.quantity_delta)::numeric(14,3) as quantity,
       max(sm.created_at) as last_movement_at
from public.stock_movements sm
where sm.business_id=public.app_business_id()
group by sm.business_id,sm.branch_id,sm.product_id,sm.variant_id,sm.batch_id;

create or replace view public.business_profit_daily as
with sale_base as (
  select s.id,s.business_id,s.created_at::date as day,s.total
  from public.sales s
  where s.business_id=public.app_business_id() and s.status='completed'
), sale_costs as (
  select sb.id,sb.business_id,sb.day,
         coalesce(sum(coalesce(si.quantity,0)*coalesce(p.purchase_price,0)),0) as cost_of_goods_sold
  from sale_base sb left join public.sale_items si on si.sale_id=sb.id and si.business_id=sb.business_id
  left join public.products p on p.id=si.product_id and p.business_id=sb.business_id
  group by sb.id,sb.business_id,sb.day
), sale_totals as (
  select sb.business_id,sb.day,sum(sb.total) as revenue,sum(sc.cost_of_goods_sold) as cost_of_goods_sold
  from sale_base sb join sale_costs sc on sc.id=sb.id
  group by sb.business_id,sb.day
), expense_totals as (
  select e.business_id,e.created_at::date as day,sum(e.amount) as expenses
  from public.expenses e
  where e.business_id=public.app_business_id()
  group by e.business_id,e.created_at::date
)
select coalesce(st.business_id,et.business_id) as business_id,
       coalesce(st.day,et.day) as day,
       coalesce(st.revenue,0)::numeric(14,3) as revenue,
       coalesce(st.cost_of_goods_sold,0)::numeric(14,3) as cost_of_goods_sold,
       coalesce(et.expenses,0)::numeric(14,3) as expenses,
       (coalesce(st.revenue,0)-coalesce(st.cost_of_goods_sold,0))::numeric(14,3) as gross_profit,
       (coalesce(st.revenue,0)-coalesce(st.cost_of_goods_sold,0)-coalesce(et.expenses,0))::numeric(14,3) as net_profit
from sale_totals st full join expense_totals et using (business_id,day);

create or replace function public.get_business_report(p_from date, p_to date)
returns jsonb language sql stable security invoker set search_path=public
as $$
select jsonb_build_object(
  'sales',coalesce((select jsonb_agg(to_jsonb(x) order by x.day) from (select * from public.business_profit_daily where day between p_from and p_to) x),'[]'::jsonb),
  'stock',coalesce((select jsonb_agg(to_jsonb(x)) from (select product_id,variant_id,batch_id,quantity from public.business_stock_balances where quantity <> 0) x),'[]'::jsonb),
  'customers',coalesce((select jsonb_agg(to_jsonb(x)) from (select c.id,c.name,coalesce(c.opening_balance,0)+coalesce((select sum(s.remaining) from public.sales s where s.customer_id=c.id and s.business_id=public.app_business_id() and s.status='completed'),0)-coalesce((select sum(py.amount) from public.payments py where py.customer_id=c.id and py.business_id=public.app_business_id()),0) as balance from public.customers c where c.business_id=public.app_business_id()) x),'[]'::jsonb),
  'suppliers',coalesce((select jsonb_agg(to_jsonb(x)) from (select s.id,s.name,coalesce(s.opening_balance,0)+coalesce((select sum(pu.remaining) from public.purchases pu where pu.supplier_id=s.id and pu.business_id=public.app_business_id() and pu.status='received'),0)-coalesce((select sum(py.amount) from public.payments py where py.supplier_id=s.id and py.business_id=public.app_business_id()),0) as balance from public.suppliers s where s.business_id=public.app_business_id()) x),'[]'::jsonb)
);
$$;
revoke all on function public.get_business_report(date,date) from public;
grant execute on function public.get_business_report(date,date) to authenticated;

create or replace function public.record_purchase_return(
  p_business_id uuid,p_branch_id uuid,p_purchase_id uuid,p_supplier_id uuid,p_return_number text,p_reason text,p_items jsonb
) returns uuid language plpgsql security invoker set search_path=public as $$
declare v_id uuid:=gen_random_uuid(); v jsonb; v_product uuid; v_variant uuid; v_batch uuid; v_qty numeric; v_price numeric; v_available numeric; v_received numeric; v_returned numeric;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if exists(select 1 from public.returns where business_id=p_business_id and return_number=p_return_number) then select id into v_id from public.returns where business_id=p_business_id and return_number=p_return_number; return v_id; end if;
  if not exists(select 1 from public.purchases where id=p_purchase_id and business_id=p_business_id and status='received') then raise exception 'purchase_not_found'; end if;
  for v in select value from jsonb_array_elements(p_items) loop
    v_product:=(v->>'product_id')::uuid; v_variant:=nullif(v->>'variant_id','')::uuid; v_batch:=nullif(v->>'batch_id','')::uuid; v_qty:=(v->>'quantity')::numeric; v_price:=(v->>'unit_price')::numeric;
    if v_qty<=0 or v_price<0 then raise exception 'invalid_return_item'; end if;
    select coalesce(sum(sm.quantity_delta),0) into v_available from public.stock_movements sm where sm.business_id=p_business_id and sm.product_id=v_product and sm.variant_id is not distinct from v_variant and sm.batch_id is not distinct from v_batch;
    if v_available < v_qty then raise exception 'insufficient_stock_for_purchase_return'; end if;
    select coalesce(sum(quantity),0) into v_received from public.purchase_items where purchase_id=p_purchase_id and business_id=p_business_id and product_id=v_product and variant_id is not distinct from v_variant and batch_id is not distinct from v_batch;
    select coalesce(sum(ri.quantity),0) into v_returned from public.return_items ri join public.returns r on r.id=ri.return_id where r.purchase_id=p_purchase_id and ri.business_id=p_business_id and ri.product_id=v_product and ri.variant_id is not distinct from v_variant and ri.batch_id is not distinct from v_batch and r.status='completed';
    if v_received=0 or v_returned+v_qty>v_received then raise exception 'return_quantity_exceeds_purchase'; end if;
  end loop;
  insert into public.returns(id,business_id,branch_id,purchase_id,supplier_id,return_number,return_type,total,refund_amount,reason,created_by) values(v_id,p_business_id,p_branch_id,p_purchase_id,p_supplier_id,p_return_number,'purchase_return',0,0,p_reason,auth.uid());
  for v in select value from jsonb_array_elements(p_items) loop
    v_product:=(v->>'product_id')::uuid; v_variant:=nullif(v->>'variant_id','')::uuid; v_batch:=nullif(v->>'batch_id','')::uuid; v_qty:=(v->>'quantity')::numeric; v_price:=(v->>'unit_price')::numeric;
    update public.returns set total=total+(v_qty*v_price),refund_amount=refund_amount+(v_qty*v_price) where id=v_id;
    insert into public.return_items(return_id,business_id,product_id,variant_id,batch_id,quantity,unit_price,total) values(v_id,p_business_id,v_product,v_variant,v_batch,v_qty,v_price,v_qty*v_price);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by) values(p_business_id,p_branch_id,v_product,v_variant,v_batch,'purchase_return',-v_qty,'return',v_id,auth.uid());
  end loop;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details) values(p_business_id,p_branch_id,auth.uid(),'purchase.returned','return',v_id,jsonb_build_object('return_number',p_return_number));
  return v_id;
end; $$;
revoke all on function public.record_purchase_return(uuid,uuid,uuid,uuid,text,text,jsonb) from public;
grant execute on function public.record_purchase_return(uuid,uuid,uuid,uuid,text,text,jsonb) to authenticated;
