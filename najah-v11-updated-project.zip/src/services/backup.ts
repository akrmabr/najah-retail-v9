import { db } from './db';
import { today } from '../utils/ids';
import { saveProduct } from './inventory';
import { STORAGE_KEYS } from './storageKeys';

const tables = [
  'categories', 'brands', 'units', 'branches', 'products', 'product_variants',
  'batches', 'serial_numbers', 'stock_counts', 'stock_count_items', 'sales',
  'sale_items', 'purchases', 'purchase_items', 'customers', 'suppliers',
  'payments', 'expenses', 'returns', 'stock_movements', 'tax_rules',
  'price_lists', 'promotions', 'cash_shifts', 'cash_movements', 'accounts',
  'journal_entries', 'journal_lines', 'stock_transfers', 'stock_transfer_items',
  'warranties', 'warranty_tickets', 'loyalty_transactions', 'notifications',
  'crash_reports', 'settings', 'users', 'audit_logs', 'sync_operations',
] as const;

export async function exportBackup() {
  const payload: any = {
    version: 2, schema_version: 7, app: 'najah-retail',
    created_at: new Date().toISOString(),
    origin: typeof location !== 'undefined' ? location.origin : '',
    path: typeof location !== 'undefined' ? location.pathname : '',
    tables: {},
  };
  for (const table of tables) payload.tables[table] = await (db as any)[table].toArray();
  return new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
}

export async function downloadBackup() {
  const blob = await exportBackup();
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.href = url;
  link.download = `NAJAH_RETAIL_BACKUP_${today()}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function restoreBackup(file: File) {
  const safety = await exportBackup();
  let data: any;
  try { data = JSON.parse(await file.text()); }
  catch { throw new Error('ملف النسخة الاحتياطية تالف'); }
  if (!data || ![1, 2].includes(Number(data.version)) || !data.tables || typeof data.tables !== 'object') {
    throw new Error('ملف النسخة الاحتياطية غير صالح أو غير مدعوم');
  }
  const currentBusiness = localStorage.getItem(STORAGE_KEYS.pharmacyId);
  const backupBusiness = Array.isArray(data.tables.settings)
    ? data.tables.settings.find((row: any) => row.id === 'settings')?.pharmacy_id
    : null;
  if (backupBusiness && currentBusiness && backupBusiness !== currentBusiness) {
    throw new Error('هذه النسخة تخص نشاطاً أو جهازاً مختلفاً. لن يتم استبدال بياناتك.');
  }
  for (const table of tables) {
    if (data.tables[table] !== undefined && !Array.isArray(data.tables[table])) {
      throw new Error(`بيانات جدول ${table} غير صالحة`);
    }
  }
  await (db.transaction as any)('rw', tables.map((table) => (db as any)[table]), async () => {
    for (const table of tables) {
      await (db as any)[table].clear();
      if (Array.isArray(data.tables[table])) await (db as any)[table].bulkPut(data.tables[table]);
    }
  });
  return safety;
}

export async function exportCsv(table: string) {
  const rows = await (db as any)[table].toArray();
  if (!rows.length) return new Blob([''], { type: 'text/csv' });
  const columns = Object.keys(rows[0]);
  const escape = (value: any) => `"${String(value ?? '').replace(/"/g, '""')}"`;
  return new Blob([
    columns.join(',') + '\n' +
    rows.map((row: any) => columns.map((column) => escape(row[column])).join(',')).join('\n'),
  ], { type: 'text/csv' });
}

export async function importProductsCsv(file: File, user_id: string) {
  const text = (await file.text()).replace(/^\ufeff/, '');
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) throw new Error('ملف المنتجات فارغ.');
  const parse = (line: string) => {
    const output: string[] = []; let cell = ''; let quoted = false;
    for (let index = 0; index < line.length; index++) {
      const character = line[index];
      if (character === '"') {
        if (quoted && line[index + 1] === '"') { cell += '"'; index++; }
        else quoted = !quoted;
      } else if (character === ',' && !quoted) { output.push(cell.trim()); cell = ''; }
      else cell += character;
    }
    output.push(cell.trim());
    return output;
  };
  const headers = parse(lines[0]).map((header) => header.toLowerCase());
  const findIndex = (names: string[]) => names.map((name) => headers.indexOf(name)).find((position) => position >= 0) ?? -1;
  const nameIndex = findIndex(['arabic_name', 'name', 'اسم المنتج']);
  if (nameIndex < 0) throw new Error('يجب أن يحتوي الملف على عمود اسم المنتج.');
  let imported = 0;
  for (const line of lines.slice(1)) {
    const values = parse(line);
    const name = values[nameIndex] || '';
    if (!name) continue;
    await saveProduct(user_id, {
      arabic_name: name,
      sku: values[findIndex(['sku', 'رمز الصنف'])] || '',
      barcode: values[findIndex(['barcode', 'الباركود'])] || '',
      unit: values[findIndex(['unit', 'الوحدة'])] || 'قطعة',
      purchase_price: Number(values[findIndex(['purchase_price', 'سعر الشراء'])] || 0),
      selling_price: Number(values[findIndex(['selling_price', 'سعر البيع'])] || 0),
      reorder_level: Number(values[findIndex(['reorder_level', 'حد إعادة الطلب'])] || 0),
      active: true,
    });
    imported++;
  }
  return imported;
}