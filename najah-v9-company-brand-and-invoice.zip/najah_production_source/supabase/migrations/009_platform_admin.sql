-- Platform administration is intentionally separate from store membership.
-- Add the owner's auth user to platform_admins after applying this migration.
create table if not exists public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'owner' check (role in ('owner','administrator')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.activation_requests (
  id uuid primary key default gen_random_uuid(),
  license_id uuid references public.licenses(id) on delete cascade,
  license_key_hash text not null,
  device_fingerprint_hash text not null,
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(license_key_hash,device_fingerprint_hash)
);
alter table public.platform_admins enable row level security;
alter table public.activation_requests enable row level security;
-- No client policies: only service-role Edge Functions can read/write platform records.
create index if not exists idx_activation_requests_status on public.activation_requests(status,created_at desc);
