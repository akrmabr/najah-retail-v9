import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';

export default function TrackedInventory() {
  const serials = useLiveQuery(() => db.serial_numbers.toArray(), []) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const variants = useLiveQuery(() => db.product_variants.toArray(), []) || [];
  const [query, setQuery] = useState('');
  const search = query.trim().toLowerCase();
  const rows = serials.filter((serial) => !search ||
    [serial.serial_number, serial.imei, serial.status,
      products.find((product) => product.id === serial.product_id)?.arabic_name]
      .some((value) => String(value || '').toLowerCase().includes(search)));
  return (
    <section>
      <h1>إدارة الأرقام التسلسلية وIMEI</h1>
      <input value={query} onChange={(event) => setQuery(event.target.value)}
        placeholder="ابحث بالمنتج أو Serial أو IMEI" />
      <div className="card"><table>
        <thead><tr><th>المنتج</th><th>المتغير</th><th>Serial</th><th>IMEI</th><th>الضمان</th><th>الحالة</th></tr></thead>
        <tbody>{rows.map((serial) => <tr key={serial.id}>
          <td>{products.find((product) => product.id === serial.product_id)?.arabic_name || '—'}</td>
          <td>{variants.find((variant) => variant.id === serial.variant_id)?.name || '—'}</td>
          <td>{serial.serial_number}</td><td>{serial.imei || '—'}</td>
          <td>{serial.warranty_end || '—'}</td>
          <td><span className={`status ${serial.status === 'in_stock' ? 'ok' : serial.status === 'sold' ? '' : 'bad'}`}>
            {serial.status === 'in_stock' ? 'متاح' : serial.status === 'sold' ? 'مباع' : serial.status}
          </span></td>
        </tr>)}</tbody>
      </table>{!rows.length && <p className="empty">لا توجد أجهزة أو أرقام تسلسلية.</p>}</div>
    </section>
  );
}