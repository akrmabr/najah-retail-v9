import {
  BUSINESS_TYPES,
  LEGACY_ACTIVITY_ALIASES,
  type BusinessField,
  type BusinessTypeConfig,
  type CanonicalBusinessTypeId,
  type LegacyBusinessTypeId,
} from './businessTypes';

export type DashboardMetric =
  | 'todaySales'
  | 'todayProfit'
  | 'stockValue'
  | 'lowStock'
  | 'expired'
  | 'nearExpiry'
  | 'expenses'
  | 'customerDebts'
  | 'supplierDebts';

export type InventoryStrategy =
  | 'quantity'
  | 'variant'
  | 'batch_expiry'
  | 'serial'
  | 'imei'
  | 'unit_conversion';

export type ActivityDefinition = BusinessTypeConfig & {
  dashboardMetrics: readonly DashboardMetric[];
  inventoryStrategies: readonly InventoryStrategy[];
  searchFields: readonly string[];
  invoiceFields: readonly string[];
};

type ActivityRules = Omit<ActivityDefinition, keyof BusinessTypeConfig>;

/** One explicit runtime profile for each of the 13 approved activities. */
const ACTIVITY_RULES: Record<CanonicalBusinessTypeId, ActivityRules> = {
  pharmacy: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock', 'expired', 'nearExpiry', 'supplierDebts'],
    inventoryStrategies: ['quantity', 'batch_expiry'],
    searchFields: ['arabic_name', 'english_name', 'generic_name', 'sku', 'barcode', 'scientific_name', 'batch_number'],
    invoiceFields: ['generic_name', 'concentration', 'dosage', 'form', 'batch_number', 'expiry_date'],
  },
  auto_parts: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant', 'serial'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'part_number', 'brand', 'model', 'vehicle', 'year', 'serial_number', 'accessory_type'],
    invoiceFields: ['part_number', 'brand', 'model', 'vehicle', 'year', 'serial_number'],
  },
  grocery_supermarket: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock', 'expired', 'nearExpiry'],
    inventoryStrategies: ['quantity', 'batch_expiry', 'unit_conversion'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'batch_number', 'category', 'unit', 'weight'],
    invoiceFields: ['unit', 'weight', 'pack', 'carton', 'batch_number', 'expiry_date'],
  },
  homeware: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'material', 'product_type', 'pieces', 'set'],
    invoiceFields: ['product_type', 'material', 'pieces', 'set', 'weight'],
  },
  furniture_decor: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'model', 'material', 'wood_type', 'dimensions', 'pattern'],
    invoiceFields: ['product_type', 'brand', 'model', 'material', 'wood_type', 'dimensions', 'length', 'width', 'height'],
  },
  clothing: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'size', 'color', 'gender', 'fabric', 'season', 'style'],
    invoiceFields: ['size', 'color', 'fabric', 'style'],
  },
  perfume_cosmetics: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock', 'expired', 'nearExpiry'],
    inventoryStrategies: ['quantity', 'batch_expiry', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'manufacturer', 'shade', 'fragrance_family', 'batch_number'],
    invoiceFields: ['brand', 'fragrance_family', 'shade', 'size', 'batch_number', 'expiry_date'],
  },
  shoes: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'size', 'color', 'gender', 'material', 'model'],
    invoiceFields: ['size', 'color', 'brand', 'model', 'material'],
  },
  bookstore: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'category', 'author', 'publisher', 'isbn', 'edition', 'subject', 'grade'],
    invoiceFields: ['author', 'publisher', 'isbn', 'edition', 'subject', 'grade'],
  },
  mobile: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant', 'serial', 'imei'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'model', 'imei', 'serial_number', 'ram', 'storage', 'network'],
    invoiceFields: ['brand', 'model', 'ram', 'storage', 'imei', 'serial_number', 'warranty'],
  },
  building_materials: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'unit_conversion'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'material', 'material_type', 'unit'],
    invoiceFields: ['material', 'material_type', 'unit', 'weight', 'length', 'width', 'height'],
  },
  electronics: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'variant', 'serial'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'model', 'serial_number', 'ram', 'storage', 'color'],
    invoiceFields: ['brand', 'model', 'ram', 'storage', 'serial_number', 'warranty', 'voltage', 'power'],
  },
  electrical: {
    dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
    inventoryStrategies: ['quantity', 'serial'],
    searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'model', 'serial_number'],
    invoiceFields: ['brand', 'model', 'serial_number', 'warranty', 'voltage', 'power', 'dimensions'],
  },
};

export const ACTIVITY_REGISTRY: Readonly<Record<CanonicalBusinessTypeId, ActivityDefinition>> =
  Object.freeze(
    Object.fromEntries(
      Object.entries(BUSINESS_TYPES).map(([id, config]) => [
        id,
        Object.freeze({ ...config, ...ACTIVITY_RULES[id as CanonicalBusinessTypeId] }),
      ]),
    ) as Record<CanonicalBusinessTypeId, ActivityDefinition>,
  );

const LEGACY_GENERIC_ACTIVITY: ActivityDefinition = Object.freeze({
  id: 'general',
  label: 'نشاط قديم غير مصنّف',
  productLabel: 'المنتجات المسجلة سابقاً',
  inventoryLabel: 'المخزون المسجل سابقاً',
  purchaseLabel: 'المشتريات',
  reportLabel: 'التقارير العامة',
  fields: ['brand', 'model'] as BusinessField[],
  units: ['قطعة', 'عبوة', 'كرتون'],
  variants: [],
  dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
  inventoryStrategies: ['quantity'],
  searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'model'],
  invoiceFields: ['brand', 'model'],
} as ActivityDefinition);

const LEGACY_HARDWARE_ACTIVITY: ActivityDefinition = Object.freeze({
  id: 'hardware',
  label: 'العدد والأدوات (نشاط سابق)',
  productLabel: 'العدد والأدوات',
  inventoryLabel: 'مخزون العدد والأدوات',
  purchaseLabel: 'مشتريات العدد والأدوات',
  reportLabel: 'تقارير الأدوات والماركات',
  fields: ['tool_type', 'material', 'size', 'brand'],
  units: ['قطعة', 'طقم', 'علبة', 'كرتون'],
  variants: [],
  dashboardMetrics: ['todaySales', 'todayProfit', 'stockValue', 'lowStock'],
  inventoryStrategies: ['quantity', 'unit_conversion'],
  searchFields: ['arabic_name', 'english_name', 'sku', 'barcode', 'brand', 'tool_type', 'material'],
  invoiceFields: ['tool_type', 'material', 'size', 'unit'],
} as ActivityDefinition);

export function getActivityDefinition(id?: string | null): ActivityDefinition {
  if (!id || id === 'general' || id === 'other') return LEGACY_GENERIC_ACTIVITY;
  const canonicalId = Object.prototype.hasOwnProperty.call(BUSINESS_TYPES, id)
    ? id as CanonicalBusinessTypeId
    : LEGACY_ACTIVITY_ALIASES[id as LegacyBusinessTypeId];
  if (canonicalId === 'legacy_hardware') return LEGACY_HARDWARE_ACTIVITY;
  if (canonicalId === 'legacy_generic') return LEGACY_GENERIC_ACTIVITY;
  const activity = canonicalId && ACTIVITY_REGISTRY[canonicalId];
  if (!activity) throw new Error(`Unsupported business activity: ${id}`);
  return activity;
}

export function validateActivityProduct(
  activity: ActivityDefinition,
  product: { unit?: unknown; variants?: unknown },
): void {
  if (product.unit && !activity.units.includes(String(product.unit))) {
    throw new Error(`الوحدة غير مدعومة لنشاط ${activity.label}.`);
  }
  if (Array.isArray(product.variants) && product.variants.length > 0 && activity.variants.length === 0) {
    throw new Error(`المتغيرات غير مفعّلة لنشاط ${activity.label}.`);
  }
}