import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { login } from '../services/auth';
import { getBusinessContext, getBusinessSettings } from '../services/businessContext';
import type { User } from '../types/models';
import CompanyPromo from '../components/CompanyPromo';
export default function Login({ onLogin }: { onLogin: (u: User) => void }) {
  const settings = useLiveQuery(getBusinessSettings, []) || {};
  const activity = useLiveQuery(getBusinessContext, []) || { label: 'نشاط تجاري' };
  const [username, setU] = useState(''); const [password, setP] = useState(''); const [err, setErr] = useState('');
  async function submit(e: React.FormEvent) { e.preventDefault(); setErr(''); try { onLogin(await login(username, password)); } catch (error: any) { setErr(error?.message || 'تعذر تسجيل الدخول.'); } }
  return <div className="login"><form onSubmit={submit} className="card"><div className="login-brand"><img src={settings.logo || 'brand-logo.png'} alt="شعار النشاط"/><h1>{settings.business_name || settings.pharmacy_name || 'النجاح لإدارة المحال التجارية'}</h1><p>{activity.label} — نظام إدارة المبيعات والمخزون</p></div><input value={username} onChange={(e) => setU(e.target.value)} placeholder="اسم المستخدم أو البريد" autoComplete="username" required/><input type="password" value={password} onChange={(e) => setP(e.target.value)} placeholder="كلمة المرور" autoComplete="current-password" required/><button className="primary">تسجيل الدخول</button>{err&&<div className="alert">{err}</div>}<CompanyPromo /></form></div>
}
