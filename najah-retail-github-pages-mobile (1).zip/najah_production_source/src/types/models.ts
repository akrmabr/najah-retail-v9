export type Role = 'OWNER' | 'ADMIN' | 'PHARMACIST' | 'CASHIER' | 'INVENTORY' | 'ACCOUNTANT' | 'VIEWER';
export type PaymentMethod = 'Cash' | 'Credit' | 'Card' | 'Bank' | string;
export type StockMovementType = 'opening' | 'purchase' | 'sale' | 'return' | 'damage' | 'adjustment' | 'transfer_in' | 'transfer_out';

export type User = {
  id: string;
  pharmacy_id: string;
  created_at: string;
  updated_at: string;
  name: string;
  email: string;
  username: string;
  password_hash: string;
  role: Role;
  permissions?: string[];
  active: boolean;
  last_login?: string;
};

export type Settings = {
  id: string;
  pharmacy_id: string;
  business_type?: string;
  pharmacy_name?: string;
  business_name?: string;
  logo?: string;
  address?: string;
  phone?: string;
  email?: string;
  tax_number?: string;
  currency?: string;
  currency_symbol?: string;
  invoice_footer?: string;
  default_paper?: 'A4' | '58mm' | '80mm' | string;
  tax_rate?: number;
  offline_grace_days?: number;
  session_timeout_minutes?: number;
  created_at: string;
  updated_at: string;
  [key: string]: unknown;
};

export type Product = {
  id: string;
  pharmacy_id: string;
  created_at: string;
  updated_at: string;
  arabic_name: string;
  english_name?: string;
  generic_name?: string;
  barcode?: string;
  alternative_barcode?: string;
  sku?: string;
  category?: string;
  brand?: string;
  manufacturer?: string;
  unit?: string;
  purchase_price: number;
  selling_price: number;
  wholesale_price?: number;
  reorder_level: number;
  maximum_stock?: number;
  tax: number;
  active: boolean;
  attributes?: Record<string, unknown>;
  image?: string;
  variants?: ProductVariant[];
};

export type ProductVariant = {
  id: string;
  pharmacy_id: string;
  product_id: string;
  name: string;
  sku?: string;
  barcode?: string;
  attributes: Record<string, unknown>;
  quantity: number;
  purchase_price: number;
  selling_price: number;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type Batch = {
  id: string;
  pharmacy_id: string;
  product_id: string;
  batch_number: string;
  expiry_date?: string;
  quantity: number;
  initial_quantity: number;
  purchase_price: number;
  selling_price: number;
  manufacture_date?: string;
  supplier_id?: string;
  created_at?: string;
  updated_at?: string;
};

export type Customer = {
  id: string;
  pharmacy_id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  balance: number;
  created_at?: string;
  updated_at?: string;
};

export type Supplier = {
  id: string;
  pharmacy_id: string;
  name: string;
  company?: string;
  phone?: string;
  email?: string;
  address?: string;
  balance: number;
  created_at?: string;
  updated_at?: string;
};

export type Sale = {
  id: string;
  pharmacy_id: string;
  invoice_no: string;
  customer_id?: string;
  cashier_id: string;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paid: number;
  remaining: number;
  payment_method: PaymentMethod;
  profit: number;
  status: 'COMPLETED' | 'CANCELLED' | 'RETURNED' | 'PARTIAL_RETURN' | string;
  created_at: string;
  updated_at: string;
};

export type SaleItem = {
  id: string;
  pharmacy_id: string;
  sale_id: string;
  product_id: string;
  batch_id: string;
  quantity: number;
  unit_price: number;
  discount: number;
  tax: number;
  line_total: number;
  cost: number;
  profit: number;
  created_at: string;
  updated_at: string;
};

export type Purchase = {
  id: string;
  pharmacy_id: string;
  invoice_no: string;
  supplier_id?: string;
  date?: string;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paid: number;
  remaining: number;
  status: 'POSTED' | 'CANCELLED' | 'PARTIAL_RETURN' | string;
  created_at?: string;
  updated_at?: string;
};

export type PurchaseItem = {
  id: string;
  pharmacy_id: string;
  purchase_id: string;
  product_id: string;
  batch_id: string;
  quantity: number;
  purchase_price: number;
  selling_price: number;
  discount?: number;
  tax?: number;
  line_total?: number;
  created_at?: string;
  updated_at?: string;
};

export type Expense = { id: string; pharmacy_id: string; date: string; category: string; amount: number; description?: string; payment_method?: string; created_by?: string; created_at?: string; updated_at?: string };
export type Payment = { id: string; pharmacy_id: string; party_type: 'customer' | 'supplier'; party_id: string; amount: number; payment_method?: PaymentMethod; method?: PaymentMethod; notes?: string; date: string; created_at?: string; updated_at?: string };
export type Return = { id: string; pharmacy_id: string; type: 'SALE' | 'PURCHASE' | 'SALE_RETURN' | 'PURCHASE_RETURN'; source_id: string; product_id: string; batch_id?: string; quantity: number; amount: number; reason?: string; status: string; created_at: string; updated_at?: string };
export type StockMovement = { id: string; pharmacy_id: string; product_id: string; batch_id?: string; type: StockMovementType; quantity: number; before_qty: number; after_qty: number; reference_id?: string; user_id?: string; notes?: string; created_at: string; updated_at: string };
export type StockCount = { id: string; pharmacy_id: string; status: 'COMPLETED' | 'CANCELLED'; notes?: string; created_by: string; created_at: string; updated_at: string };
export type StockCountItem = { id: string; pharmacy_id: string; stock_count_id: string; product_id: string; batch_id: string; system_quantity: number; counted_quantity: number; difference: number; created_at: string };
export type AuditLog = { id: string; pharmacy_id: string; user_id?: string; timestamp: string; created_at?: string; updated_at?: string; action: string; entity: string; entity_id?: string; details?: unknown };
export type SyncStatus = 'pending' | 'syncing' | 'applied' | 'failed' | 'conflict';
export type SyncOperation = {
  id: string;
  pharmacy_id: string;
  operation_key: string;
  operation_type: string;
  payload: unknown;
  status: SyncStatus;
  attempts: number;
  last_error?: string;
  created_at: string;
  updated_at: string;
  acknowledged_at?: string;
  server_version?: string;
};
export type LicenseStatus = 'ACTIVE' | 'EXPIRED' | 'SUSPENDED' | 'REVOKED' | 'PENDING' | string;
export type LicenseCache = { license_key: string; device_id: string; license_type: 'ANNUAL' | 'LIFETIME'; status: LicenseStatus; expires_at: string | null; last_validation: string; last_seen?: string; grace_days: number; signature?: string; business_type_id?: string; [key: string]: unknown };