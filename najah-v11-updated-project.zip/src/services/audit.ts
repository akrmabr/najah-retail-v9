import { db, getPharmacyId } from './db';
import { now, uid } from '../utils/ids';
import { STORAGE_KEYS } from './storageKeys';

export async function audit(
  user_id: string, action: string, entity: string, entity_id?: string, details?: unknown,
) {
  const timestamp = now();
  const structured = details && typeof details === 'object' ? details as any : undefined;
  await db.audit_logs.add({
    id: uid('audit'), pharmacy_id: getPharmacyId(), created_at: timestamp,
    updated_at: timestamp, timestamp, user_id, action, entity, entity_id,
    device_id: localStorage.getItem(STORAGE_KEYS.deviceFingerprint) || undefined,
    page: typeof location !== 'undefined' ? `${location.pathname}${location.hash}` : undefined,
    old_value: structured?.old_value,
    new_value: structured?.new_value,
    details,
  });
}