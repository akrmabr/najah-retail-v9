-- Configurable modules/fields per business type.
create table if not exists public.business_feature_configs (
  id uuid primary key default gen_random_uuid(),
  business_type_id text not null references public.business_types(id) on delete cascade,
  module_key text not null,
  enabled boolean not null default true,
  config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_type_id,module_key)
);

create table if not exists public.license_events (
  id uuid primary key default gen_random_uuid(), license_id uuid not null references public.licenses(id) on delete cascade,
  event_type text not null, actor_user_id uuid references auth.users(id), details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create index if not exists idx_license_events_license on public.license_events(license_id,created_at desc);

alter table public.business_feature_configs enable row level security;
drop policy if exists feature_config_read on public.business_feature_configs;
create policy feature_config_read on public.business_feature_configs for select using (exists (select 1 from public.businesses b where b.business_type_id=public.business_feature_configs.business_type_id and (b.id=public.app_business_id() or b.created_by=auth.uid())) or public.app_is_admin());

-- Atomic sale transaction. The client submits one idempotent invoice number and item array.
create or replace function public.complete_sale(
  p_business_id uuid,
  p_branch_id uuid,
  p_customer_id uuid,
  p_invoice_number text,
  p_payment_method text,
  p_paid numeric,
  p_items jsonb
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_subtotal numeric := 0;
  v_total numeric := 0;
  v_item jsonb;
  v_product_id uuid;
  v_variant_id uuid;
  v_batch_id uuid;
  v_qty numeric;
  v_price numeric;
  v_discount numeric;
  v_item_total numeric;
  v_available numeric;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if p_invoice_number is null or length(trim(p_invoice_number))=0 then raise exception 'invoice_number_required'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'items_required'; end if;
  if p_paid < 0 then raise exception 'invalid_paid_amount'; end if;

  -- Idempotency: retrying the same invoice returns the original sale.
  select id into v_sale_id from public.sales where business_id=p_business_id and invoice_number=p_invoice_number;
  if v_sale_id is not null then return v_sale_id; end if;
  v_sale_id := gen_random_uuid();

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_batch_id := nullif(v_item->>'batch_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    v_discount := coalesce((v_item->>'discount')::numeric,0);
    if v_qty <= 0 or v_price < 0 or v_discount < 0 then raise exception 'invalid_sale_item'; end if;
    if v_variant_id is not null then
      select coalesce(sum(sm.quantity_delta),0) into v_available from public.stock_movements sm where sm.business_id=p_business_id and sm.product_id=v_product_id and sm.variant_id=v_variant_id;
    else
      select coalesce(sum(sm.quantity_delta),0) into v_available from public.stock_movements sm where sm.business_id=p_business_id and sm.product_id=v_product_id and sm.variant_id is null;
    end if;
    if v_available < v_qty then raise exception 'insufficient_stock for product %', v_product_id; end if;
    v_item_total := greatest(0, v_qty*v_price-v_discount);
    v_subtotal := v_subtotal + v_item_total;
  end loop;
  v_total := v_subtotal;
  if p_paid < 0 then raise exception 'invalid_paid_amount'; end if;

  insert into public.sales(id,business_id,branch_id,customer_id,cashier_id,invoice_number,payment_method,subtotal,total,paid,remaining)
  values(v_sale_id,p_business_id,p_branch_id,p_customer_id,auth.uid(),p_invoice_number,p_payment_method,v_subtotal,v_total,p_paid,v_total-p_paid);

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_batch_id := nullif(v_item->>'batch_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    v_discount := coalesce((v_item->>'discount')::numeric,0);
    v_item_total := greatest(0, v_qty*v_price-v_discount);
    insert into public.sale_items(sale_id,business_id,product_id,variant_id,batch_id,quantity,unit_price,discount,total)
    values(v_sale_id,p_business_id,v_product_id,v_variant_id,v_batch_id,v_qty,v_price,v_discount,v_item_total);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by)
    values(p_business_id,p_branch_id,v_product_id,v_variant_id,v_batch_id,'sale',-v_qty,'sale',v_sale_id,auth.uid());
  end loop;
  if p_paid > 0 then
    insert into public.payments(business_id,customer_id,sale_id,amount,payment_method,created_by) values(p_business_id,p_customer_id,v_sale_id,p_paid,p_payment_method,auth.uid());
  end if;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details)
  values(p_business_id,p_branch_id,auth.uid(),'sale.completed','sale',v_sale_id,jsonb_build_object('invoice_number',p_invoice_number,'total',v_total));
  return v_sale_id;
end;
$$;

-- Atomic purchase receipt transaction.
create or replace function public.receive_purchase(
  p_business_id uuid,
  p_branch_id uuid,
  p_supplier_id uuid,
  p_invoice_number text,
  p_payment_method text,
  p_paid numeric,
  p_items jsonb
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare
  v_purchase_id uuid := gen_random_uuid(); v_subtotal numeric := 0; v_item jsonb; v_product_id uuid; v_variant_id uuid; v_batch_id uuid; v_qty numeric; v_cost numeric; v_total numeric;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'items_required'; end if;
  if p_paid < 0 then raise exception 'invalid_paid_amount'; end if;
  select id into v_purchase_id from public.purchases where business_id=p_business_id and invoice_number=p_invoice_number;
  if v_purchase_id is not null then return v_purchase_id; end if;
  v_purchase_id := gen_random_uuid();
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid; v_variant_id := nullif(v_item->>'variant_id','')::uuid; v_batch_id := nullif(v_item->>'batch_id','')::uuid; v_qty := (v_item->>'quantity')::numeric; v_cost := (v_item->>'unit_cost')::numeric;
    if v_qty <= 0 or v_cost < 0 then raise exception 'invalid_purchase_item'; end if;
    v_subtotal := v_subtotal + v_qty*v_cost;
  end loop;
  v_total := v_subtotal;
  if p_paid > v_total then raise exception 'paid_exceeds_total'; end if;
  insert into public.purchases(id,business_id,branch_id,supplier_id,invoice_number,payment_method,subtotal,total,paid,remaining)
  values(v_purchase_id,p_business_id,p_branch_id,p_supplier_id,p_invoice_number,p_payment_method,v_subtotal,v_total,p_paid,v_total-p_paid);
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid; v_variant_id := nullif(v_item->>'variant_id','')::uuid; v_batch_id := nullif(v_item->>'batch_id','')::uuid; v_qty := (v_item->>'quantity')::numeric; v_cost := (v_item->>'unit_cost')::numeric;
    insert into public.purchase_items(purchase_id,business_id,product_id,variant_id,batch_id,quantity,unit_cost,total) values(v_purchase_id,p_business_id,v_product_id,v_variant_id,v_batch_id,v_qty,v_cost,v_qty*v_cost);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by) values(p_business_id,p_branch_id,v_product_id,v_variant_id,v_batch_id,'purchase',v_qty,'purchase',v_purchase_id,auth.uid());
  end loop;
  if p_paid > 0 then insert into public.payments(business_id,supplier_id,purchase_id,amount,payment_method,created_by) values(p_business_id,p_supplier_id,v_purchase_id,p_paid,p_payment_method,auth.uid()); end if;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details) values(p_business_id,p_branch_id,auth.uid(),'purchase.received','purchase',v_purchase_id,jsonb_build_object('invoice_number',p_invoice_number,'total',v_total));
  return v_purchase_id;
end;
$$;

