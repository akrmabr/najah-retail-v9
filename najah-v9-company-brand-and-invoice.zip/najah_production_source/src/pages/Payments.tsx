import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import { recordPayment } from '../services/purchases';
import type { PaymentMethod, User } from '../types/models';
import { money } from '../utils/ids';

export default function Payments({ user }: { user: User }) {
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const suppliers = useLiveQuery(() => db.suppliers.toArray(), []) || [];
  const payments = useLiveQuery(async () => {
    const rows = await db.payments.toArray();
    return rows.sort((a, b) =>
      String(b.created_at || b.date).localeCompare(String(a.created_at || a.date)),
    );
  }, []) || [];
  const [partyType, setPartyType] = useState<'customer' | 'supplier'>('customer');
  const [partyId, setPartyId] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState('');

  const parties = partyType === 'customer' ? customers : suppliers;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMessage('');
    const value = Number(amount);
    if (!partyId) return setMessage('اختر العميل أو المورد.');
    if (!Number.isFinite(value) || value <= 0) {
      return setMessage('أدخل مبلغاً صحيحاً أكبر من صفر.');
    }
    try {
      await recordPayment(user.id, partyType, partyId, value, method, notes.trim());
      setAmount('');
      setNotes('');
      setPartyId('');
      setMessage('تم تسجيل الدفعة وتحديث الرصيد.');
    } catch (error: any) {
      setMessage(error?.message || 'تعذر تسجيل الدفعة.');
    }
  }

  return (
    <section>
      <h1>المدفوعات والتحصيلات</h1>
      <form className="card formgrid" onSubmit={save}>
        <select
          value={partyType}
          onChange={(e) => {
            setPartyType(e.target.value as 'customer' | 'supplier');
            setPartyId('');
          }}
        >
          <option value="customer">دفعة من عميل</option>
          <option value="supplier">دفعة لمورد</option>
        </select>
        <select value={partyId} onChange={(e) => setPartyId(e.target.value)} required>
          <option value="">اختر {partyType === 'customer' ? 'العميل' : 'المورد'}</option>
          {parties.map((party) => (
            <option key={party.id} value={party.id}>
              {party.name}
            </option>
          ))}
        </select>
        <input
          type="number"
          min="0.01"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="المبلغ"
          required
        />
        <select value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="Cash">نقدي</option>
          <option value="Card">بطاقة</option>
          <option value="Bank">تحويل بنكي</option>
        </select>
        <input
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="ملاحظات اختيارية"
        />
        <button>تسجيل الدفعة</button>
      </form>
      {message && <div className="alert">{message}</div>}
      <div className="card">
        <table>
          <thead>
            <tr>
              <th>التاريخ</th>
              <th>الطرف</th>
              <th>المبلغ</th>
              <th>الطريقة</th>
              <th>ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((payment) => {
              const party =
                payment.party_type === 'customer'
                  ? customers.find((item) => item.id === payment.party_id)?.name
                  : suppliers.find((item) => item.id === payment.party_id)?.name;
              return (
                <tr key={payment.id}>
                  <td>{payment.date}</td>
                  <td>{party || 'غير معروف'}</td>
                  <td>{money(payment.amount)}</td>
                  <td>{payment.method}</td>
                  <td>{payment.notes || ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!payments.length && <p className="empty">لا توجد مدفوعات بعد.</p>}
      </div>
    </section>
  );
}