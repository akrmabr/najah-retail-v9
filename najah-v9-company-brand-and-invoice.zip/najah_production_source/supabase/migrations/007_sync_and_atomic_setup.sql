-- V9 production hardening: durable sync acknowledgements and whitelisted server writes.
-- Apply after 001..006. This migration is additive and does not delete business data.

create table if not exists public.stock_counts (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  status text not null default 'completed' check(status in ('draft','completed','cancelled')), notes text, created_by uuid references auth.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.stock_count_items (
  id uuid primary key default gen_random_uuid(), stock_count_id uuid not null references public.stock_counts(id) on delete cascade, business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid not null references public.products(id), variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), system_quantity numeric(14,3) not null, counted_quantity numeric(14,3) not null check(counted_quantity >= 0), difference numeric(14,3) not null, created_at timestamptz not null default now()
);
create index if not exists idx_sync_operations_key on public.sync_operations(business_id, operation_key);

-- A single business must be selected by the server, never by a client supplied business_id.
create or replace function public.app_business_id()
returns uuid
language sql stable security definer set search_path=public
as $$
  select bm.business_id
  from public.business_members bm
  where bm.user_id=auth.uid() and bm.is_active=true
  order by case when bm.role in ('owner','administrator') then 0 else 1 end, bm.created_at
  limit 1;
$$;

-- Prevent a client from changing the tenant columns of an existing row.
create or replace function public.prevent_tenant_change()
returns trigger language plpgsql security invoker set search_path=public
as $$
begin
  if tg_op='UPDATE' and old.business_id is distinct from new.business_id then
    raise exception 'business_id_is_immutable';
  end if;
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['branches','business_members','categories','brands','units','products','product_variants','product_barcodes','product_batches','product_serial_numbers','customers','suppliers','sales','sale_items','purchases','purchase_items','stock_movements','payments','expenses','audit_logs','sync_operations','stock_counts','stock_count_items','returns','return_items','invoices'] loop
    execute format('drop trigger if exists %I_tenant_guard on public.%I', t, t);
    execute format('create trigger %I_tenant_guard before update on public.%I for each row execute function public.prevent_tenant_change()', t, t);
  end loop;
end $$;

-- The local queue sends one operation_key repeatedly until this function acknowledges it.
-- Only known operation types are accepted; arbitrary table names/SQL are never accepted.
create or replace function public.apply_sync_operation(
  p_operation_key text,
  p_operation_type text,
  p_payload jsonb
) returns jsonb
language plpgsql security invoker set search_path=public
as $$
declare
  v_business_id uuid := public.app_business_id();
  v_operation_id uuid;
  v_result uuid;
  v_existing jsonb;
  v_branch_id uuid;
  v_variant_row jsonb;
begin
  if v_business_id is null then raise exception 'business_not_authenticated'; end if;
  if nullif(trim(p_operation_key),'') is null then raise exception 'operation_key_required'; end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then raise exception 'invalid_operation_payload'; end if;

  select id, jsonb_build_object('status',status,'result',payload->'result','applied_at',applied_at)
    into v_operation_id, v_existing
  from public.sync_operations
  where business_id=v_business_id and operation_key=p_operation_key;
  if v_operation_id is not null then
    if (v_existing->>'status')='applied' then return v_existing; end if;
  else
    insert into public.sync_operations(business_id,operation_key,operation_type,payload,status)
    values(v_business_id,p_operation_key,p_operation_type,p_payload,'pending')
    returning id into v_operation_id;
  end if;

  v_branch_id := nullif(p_payload->>'branch_id','')::uuid;
  if p_operation_type='sale' then
    v_result := public.complete_sale(v_business_id,v_branch_id,nullif(p_payload->>'customer_id','')::uuid,
      p_payload->>'invoice_number',coalesce(p_payload->>'payment_method','cash'),coalesce((p_payload->>'paid')::numeric,0),coalesce(p_payload->'items','[]'::jsonb));
  elsif p_operation_type='purchase' then
    v_result := public.receive_purchase(v_business_id,v_branch_id,nullif(p_payload->>'supplier_id','')::uuid,
      p_payload->>'invoice_number',coalesce(p_payload->>'payment_method','cash'),coalesce((p_payload->>'paid')::numeric,0),coalesce(p_payload->'items','[]'::jsonb));
  elsif p_operation_type='product' then
    insert into public.products(business_id,id,name,sku,base_barcode,purchase_price,sale_price,wholesale_price,minimum_stock,attributes,is_active)
    values(v_business_id,coalesce(nullif(p_payload->>'id','')::uuid,gen_random_uuid()),p_payload->>'name',p_payload->>'sku',p_payload->>'base_barcode',
      coalesce((p_payload->>'purchase_price')::numeric,0),coalesce((p_payload->>'sale_price')::numeric,0),nullif(p_payload->>'wholesale_price','')::numeric,
      coalesce((p_payload->>'minimum_stock')::numeric,0),coalesce(p_payload->'attributes','{}'::jsonb),coalesce((p_payload->>'is_active')::boolean,true))
    on conflict (id) do update set name=excluded.name,sku=excluded.sku,base_barcode=excluded.base_barcode,purchase_price=excluded.purchase_price,sale_price=excluded.sale_price,wholesale_price=excluded.wholesale_price,minimum_stock=excluded.minimum_stock,attributes=excluded.attributes,is_active=excluded.is_active,updated_at=now()
    returning id into v_result;
    for v_variant_row in select value from jsonb_array_elements(coalesce(p_payload->'attributes'->'variants','[]'::jsonb)) loop
      insert into public.product_variants(id,business_id,product_id,sku,barcode,attributes,purchase_price,sale_price,minimum_stock,is_active)
      values(coalesce(nullif(v_variant_row->>'id','')::uuid,gen_random_uuid()),v_business_id,v_result,nullif(v_variant_row->>'sku',''),nullif(v_variant_row->>'barcode',''),coalesce(v_variant_row->'attributes','{}'::jsonb),coalesce((v_variant_row->>'purchase_price')::numeric,0),coalesce((v_variant_row->>'selling_price')::numeric,0),coalesce((v_variant_row->>'quantity')::numeric,0),coalesce((v_variant_row->>'active')::boolean,true))
      on conflict (id) do update set sku=excluded.sku,barcode=excluded.barcode,attributes=excluded.attributes,purchase_price=excluded.purchase_price,sale_price=excluded.sale_price,minimum_stock=excluded.minimum_stock,is_active=excluded.is_active;
    end loop;
  elsif p_operation_type='customer' then
    insert into public.customers(business_id,id,name,phone,email,address,opening_balance,is_active)
    values(v_business_id,coalesce(nullif(p_payload->>'id','')::uuid,gen_random_uuid()),p_payload->>'name',p_payload->>'phone',p_payload->>'email',p_payload->>'address',coalesce((p_payload->>'opening_balance')::numeric,0),coalesce((p_payload->>'is_active')::boolean,true))
    on conflict (id) do update set name=excluded.name,phone=excluded.phone,email=excluded.email,address=excluded.address,is_active=excluded.is_active,updated_at=now()
    returning id into v_result;
  elsif p_operation_type='supplier' then
    insert into public.suppliers(business_id,id,name,phone,email,address,opening_balance,is_active)
    values(v_business_id,coalesce(nullif(p_payload->>'id','')::uuid,gen_random_uuid()),p_payload->>'name',p_payload->>'phone',p_payload->>'email',p_payload->>'address',coalesce((p_payload->>'opening_balance')::numeric,0),coalesce((p_payload->>'is_active')::boolean,true))
    on conflict (id) do update set name=excluded.name,phone=excluded.phone,email=excluded.email,address=excluded.address,is_active=excluded.is_active,updated_at=now()
    returning id into v_result;
  elsif p_operation_type='sale_return' then
    v_result := public.record_sale_return(v_business_id,v_branch_id,(p_payload->>'sale_id')::uuid,nullif(p_payload->>'customer_id','')::uuid,coalesce(p_payload->>'return_number',p_operation_key),p_payload->>'reason',coalesce(p_payload->'items','[]'::jsonb));
  elsif p_operation_type='purchase_return' then
    v_result := public.record_purchase_return(v_business_id,v_branch_id,(p_payload->>'purchase_id')::uuid,nullif(p_payload->>'supplier_id','')::uuid,coalesce(p_payload->>'return_number',p_operation_key),p_payload->>'reason',coalesce(p_payload->'items','[]'::jsonb));
  elsif p_operation_type='stock_opening' then
    if coalesce((p_payload->>'quantity_delta')::numeric,0) <= 0 then raise exception 'opening_quantity_required'; end if;
    insert into public.product_batches(id,business_id,product_id,batch_number,expiry_date,quantity)
    values(coalesce(nullif(p_payload->>'batch_id','')::uuid,gen_random_uuid()),v_business_id,(p_payload->>'product_id')::uuid,p_payload->>'batch_number',nullif(p_payload->>'expiry_date','')::date,0)
    returning id into v_result;
    insert into public.stock_movements(business_id,branch_id,product_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by)
    values(v_business_id,v_branch_id,(p_payload->>'product_id')::uuid,v_result,'opening',coalesce((p_payload->>'quantity_delta')::numeric,0),'opening',v_result,auth.uid());
  elsif p_operation_type='stock_adjustment' then
    if coalesce((select sum(quantity_delta) from public.stock_movements where business_id=v_business_id and product_id=(p_payload->>'product_id')::uuid),0)+coalesce((p_payload->>'quantity_delta')::numeric,0) < 0 then raise exception 'insufficient_stock'; end if;
    insert into public.stock_movements(business_id,branch_id,product_id,movement_type,quantity_delta,reason,created_by)
    values(v_business_id,v_branch_id,(p_payload->>'product_id')::uuid,'adjustment',(p_payload->>'quantity_delta')::numeric,p_payload->>'reason',auth.uid())
    returning id into v_result;
  elsif p_operation_type='payment' then
    insert into public.payments(business_id,customer_id,supplier_id,amount,payment_method,notes,created_by)
    values(v_business_id,case when p_payload->>'party_type'='customer' then (p_payload->>'party_id')::uuid end,case when p_payload->>'party_type'='supplier' then (p_payload->>'party_id')::uuid end,(p_payload->>'amount')::numeric,coalesce(p_payload->>'payment_method','cash'),p_payload->>'notes',auth.uid())
    returning id into v_result;
  elsif p_operation_type='stock_count' then
    insert into public.stock_counts(id,business_id,status,notes,created_by) values(coalesce(nullif(p_payload->>'stock_count_id','')::uuid,gen_random_uuid()),v_business_id,'completed',p_payload->>'notes',auth.uid()) returning id into v_result;
    for v_variant_row in select value from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
      insert into public.stock_count_items(stock_count_id,business_id,product_id,batch_id,system_quantity,counted_quantity,difference)
      values(v_result,v_business_id,(v_variant_row->>'product_id')::uuid,nullif(v_variant_row->>'batch_id','')::uuid,coalesce((v_variant_row->>'system_quantity')::numeric,0),coalesce((v_variant_row->>'counted_quantity')::numeric,0),coalesce((v_variant_row->>'difference')::numeric,0));
      if coalesce((v_variant_row->>'difference')::numeric,0) <> 0 then
        insert into public.stock_movements(business_id,product_id,batch_id,movement_type,quantity_delta,source_type,source_id,reason,created_by)
        values(v_business_id,(v_variant_row->>'product_id')::uuid,nullif(v_variant_row->>'batch_id','')::uuid,'adjustment',(v_variant_row->>'difference')::numeric,'stock_count',v_result,'جرد دوري',auth.uid());
      end if;
    end loop;
  elsif p_operation_type='expense' then
    insert into public.expenses(business_id,branch_id,category,amount,description,payment_method,created_by)
    values(v_business_id,v_branch_id,p_payload->>'category',(p_payload->>'amount')::numeric,p_payload->>'description',p_payload->>'payment_method',auth.uid())
    returning id into v_result;
  else
    raise exception 'unsupported_operation_type';
  end if;

  update public.sync_operations
  set status='applied', applied_at=now(), payload=jsonb_set(p_payload,'{result}',to_jsonb(v_result),true), error_message=null
  where id=v_operation_id;
  return jsonb_build_object('status','applied','operation_key',p_operation_key,'result',v_result);
exception when others then
  update public.sync_operations set status='failed',error_message=sqlerrm where id=v_operation_id;
  raise;
end;
$$;

revoke all on function public.apply_sync_operation(text,text,jsonb) from public;
grant execute on function public.apply_sync_operation(text,text,jsonb) to authenticated;

-- Server-side setup guard: frontend cannot create a second owner for the same license.
create or replace function public.claim_license_for_business(
  p_license_key_hash text,
  p_business_type_id text,
  p_name text,
  p_owner_name text,
  p_phone text,
  p_email text
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare v_license public.licenses%rowtype; v_business uuid;
begin
  if auth.uid() is null then raise exception 'authentication_required'; end if;
  select * into v_license from public.licenses where license_key_hash=p_license_key_hash for update;
  if not found then raise exception 'license_not_found'; end if;
  if v_license.status <> 'active' or (v_license.expires_at is not null and v_license.expires_at < now()) then raise exception 'license_not_active'; end if;
  if not exists(select 1 from public.business_types where id=p_business_type_id and is_enabled) then raise exception 'business_type_invalid'; end if;
  if v_license.business_id is not null then raise exception 'license_already_claimed'; end if;
  insert into public.businesses(business_type_id,name,owner_name,phone,email,created_by)
  values(p_business_type_id,p_name,p_owner_name,p_phone,p_email,auth.uid()) returning id into v_business;
  insert into public.branches(business_id,name,code) values(v_business,'الفرع الرئيسي','MAIN');
  insert into public.business_settings(business_id) values(v_business);
  insert into public.business_members(business_id,user_id,display_name,role) values(v_business,auth.uid(),p_owner_name,'owner');
  update public.licenses set business_id=v_business, business_type_id=p_business_type_id,store_name=p_name,owner_name=p_owner_name,activation_date=coalesce(activation_date,now()),updated_at=now() where id=v_license.id;
  insert into public.license_events(license_id,event_type,actor_user_id,details) values(v_license.id,'claimed',auth.uid(),jsonb_build_object('business_id',v_business));
  return v_business;
end;
$$;
revoke all on function public.claim_license_for_business(text,text,text,text,text,text) from public;
grant execute on function public.claim_license_for_business(text,text,text,text,text,text) to authenticated;
