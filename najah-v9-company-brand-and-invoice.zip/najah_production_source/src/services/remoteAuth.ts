import { db } from './db';
export async function signInRemote(email: string, password: string) {
  const endpoint = String(localStorage.getItem('alshifaa_license_endpoint') || '').replace(/\/+$/, '');
  const anonKey = String(import.meta.env.VITE_SUPABASE_ANON_KEY || '');
  if (!endpoint || !anonKey) return { configured: false, ok: false };
  const response = await fetch(`${endpoint}/auth/v1/token?grant_type=password`, { method: 'POST', headers: { 'content-type': 'application/json', apikey: anonKey }, body: JSON.stringify({ email, password }) });
  const data: any = await response.json().catch(() => null);
  if (!response.ok || !data?.access_token) throw new Error('تعذر تسجيل الدخول إلى خادم النشاط.');
  await db.settings.update('settings', { supabase_url: endpoint, supabase_anon_key: anonKey, supabase_access_token: data.access_token, supabase_refresh_token: data.refresh_token || '', last_sync_at: new Date().toISOString() });
  return { configured: true, ok: true, user_id: data.user?.id };
}
export async function clearRemoteSession() { const settings = await db.settings.get('settings'); if (settings) await db.settings.update('settings', { supabase_access_token: '', supabase_refresh_token: '' }); }
