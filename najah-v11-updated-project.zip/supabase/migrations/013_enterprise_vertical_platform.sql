-- Najah Retail Enterprise: safe additive production layers.
create extension if not exists pgcrypto;

insert into public.business_types(id,name_ar,name_en,sort_order) values
('bakery','مخبز وحلويات','Bakery & Sweets',210),('restaurant','مطعم','Restaurant',220),('cafe','مقهى','Cafe',230),('jewelry','مجوهرات','Jewelry',240),('watches','ساعات','Watches',250),('computers','حاسوب وتقنية معلومات','Computers & IT',260),('sports','أدوات رياضية','Sports Store',270),('toys','ألعاب أطفال','Toys Store',280),('agricultural_supplies','مستلزمات زراعية','Agricultural Supplies',290),('medical_supplies','معدات ومستلزمات طبية','Medical Supplies',300)
on conflict(id) do update set name_ar=excluded.name_ar,name_en=excluded.name_en,sort_order=excluded.sort_order,updated_at=now();

create table if not exists public.activity_definitions(
 id text primary key references public.business_types(id), definition jsonb not null default '{}'::jsonb,
 schema_version integer not null default 1, is_active boolean not null default true, updated_at timestamptz not null default now()
);
create table if not exists public.subscription_plans(
 code text primary key, name text not null, max_branches integer not null, max_users integer not null,
 max_devices integer not null, features jsonb not null default '[]'::jsonb, is_active boolean not null default true
);
insert into public.subscription_plans(code,name,max_branches,max_users,max_devices,features) values
('basic','Basic',1,3,1,'["pos","inventory","reports","backup"]'),
('professional','Professional',2,10,3,'["pos","inventory","reports","backup","sync","promotions","loyalty"]'),
('business','Business',10,50,20,'["pos","inventory","reports","backup","sync","promotions","loyalty","accounting","multi_branch","warranty"]'),
('enterprise','Enterprise',999,999,999,'["*"]') on conflict(code) do update set name=excluded.name,max_branches=excluded.max_branches,max_users=excluded.max_users,max_devices=excluded.max_devices,features=excluded.features;
create table if not exists public.subscriptions(
 id uuid primary key default gen_random_uuid(), business_id uuid not null unique references public.businesses(id) on delete cascade,
 plan_code text not null references public.subscription_plans(code), status text not null default 'active' check(status in('active','past_due','suspended','cancelled')),
 starts_at timestamptz not null default now(), ends_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.licenses add column if not exists plan_code text references public.subscription_plans(code) default 'basic';
alter table public.licenses add column if not exists branch_limit integer;

alter table public.products add column if not exists tax_exempt boolean not null default false;
alter table public.products add column if not exists tax_rate numeric(7,3);
alter table public.products add column if not exists maximum_stock numeric(14,3);
alter table public.product_batches add column if not exists purchase_price numeric(14,3) not null default 0;
alter table public.sale_items add column if not exists activity_data jsonb not null default '{}'::jsonb;
alter table public.purchase_items add column if not exists activity_data jsonb not null default '{}'::jsonb;

create table if not exists public.tax_rules(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 name text not null, rate numeric(7,3) not null check(rate between 0 and 100), scope text not null check(scope in('business','category','product')),
 scope_id uuid, tax_exempt boolean not null default false, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.price_lists(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 name text not null, code text not null, is_active boolean not null default true, created_at timestamptz not null default now(), unique(business_id,code)
);
create table if not exists public.price_list_items(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 price_list_id uuid not null references public.price_lists(id) on delete cascade, product_id uuid not null references public.products(id) on delete cascade,
 variant_id uuid references public.product_variants(id) on delete cascade, price numeric(14,3) not null check(price>=0), unique(price_list_id,product_id,variant_id)
);
create table if not exists public.promotions(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 name text not null, promotion_type text not null check(promotion_type in('percentage','fixed','buy_x_get_y','quantity')),
 value numeric(14,3) not null default 0, minimum_quantity numeric(14,3), product_id uuid references public.products(id), category_id uuid references public.categories(id),
 starts_at timestamptz not null, ends_at timestamptz not null, is_active boolean not null default true, rules jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create table if not exists public.cash_registers(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id),
 name text not null, is_active boolean not null default true, unique(business_id,branch_id,name)
);
create table if not exists public.cash_shifts(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id),
 register_id uuid references public.cash_registers(id), user_id uuid not null references auth.users(id), opening_balance numeric(14,3) not null default 0,
 expected_cash numeric(14,3) not null default 0, actual_cash numeric(14,3), difference numeric(14,3), status text not null default 'open' check(status in('open','closed')),
 opened_at timestamptz not null default now(), closed_at timestamptz
);
create table if not exists public.cash_movements(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 shift_id uuid not null references public.cash_shifts(id) on delete cascade, movement_type text not null check(movement_type in('sale','return','expense','cash_in','cash_out','transfer')),
 amount numeric(14,3) not null check(amount>0), reference_type text, reference_id uuid, notes text, created_at timestamptz not null default now()
);

create table if not exists public.accounts(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 code text not null, name text not null, account_type text not null check(account_type in('asset','liability','equity','revenue','cogs','expense')),
 parent_id uuid references public.accounts(id), is_active boolean not null default true, unique(business_id,code)
);
create table if not exists public.journal_entries(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id),
 reference_type text not null, reference_id uuid, description text not null, entry_date date not null default current_date, posted boolean not null default true,
 created_by uuid references auth.users(id), created_at timestamptz not null default now(), unique(business_id,reference_type,reference_id)
);
create table if not exists public.journal_lines(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 entry_id uuid not null references public.journal_entries(id) on delete cascade, account_id uuid not null references public.accounts(id),
 debit numeric(14,3) not null default 0 check(debit>=0), credit numeric(14,3) not null default 0 check(credit>=0), check((debit=0)<>(credit=0))
);

create table if not exists public.stock_transfers(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 from_branch_id uuid not null references public.branches(id), to_branch_id uuid not null references public.branches(id),
 status text not null default 'draft' check(status in('draft','sent','received','cancelled')), notes text, created_by uuid references auth.users(id),
 sent_at timestamptz, received_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(from_branch_id<>to_branch_id)
);
create table if not exists public.stock_transfer_items(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 transfer_id uuid not null references public.stock_transfers(id) on delete cascade, product_id uuid not null references public.products(id),
 variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), quantity numeric(14,3) not null check(quantity>0)
);

create table if not exists public.warranties(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 product_id uuid not null references public.products(id), serial_id uuid references public.product_serial_numbers(id), customer_id uuid not null references public.customers(id),
 sale_id uuid not null references public.sales(id), start_date date not null, end_date date not null, status text not null default 'active' check(status in('active','expired','void')),
 created_at timestamptz not null default now()
);
create table if not exists public.warranty_tickets(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 warranty_id uuid references public.warranties(id), customer_id uuid not null references public.customers(id), product_id uuid not null references public.products(id),
 serial_id uuid references public.product_serial_numbers(id), status text not null default 'new' check(status in('new','received','diagnosis','repair','waiting','ready','delivered','rejected')),
 notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.loyalty_transactions(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 customer_id uuid not null references public.customers(id), transaction_type text not null check(transaction_type in('earn','redeem','expire')),
 points numeric(14,3) not null check(points>0), reference_id uuid, created_at timestamptz not null default now()
);
create table if not exists public.notifications(
 id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
 user_id uuid references auth.users(id), notification_type text not null, title text not null, message text not null,
 severity text not null default 'info' check(severity in('info','warning','critical')), is_read boolean not null default false, entity_id uuid, created_at timestamptz not null default now()
);
create table if not exists public.app_versions(
 version text primary key, release_notes text not null, minimum_supported_version text, published_at timestamptz not null default now(), is_active boolean not null default true
);
create table if not exists public.crash_reports(
 id uuid primary key default gen_random_uuid(), business_id uuid references public.businesses(id) on delete set null, user_id uuid references auth.users(id),
 device text, os text, app_version text, activity_type text, page text, action text, error_code text, message text not null,
 sanitized_stack text, created_at timestamptz not null default now()
);

alter table public.audit_logs add column if not exists device_id text;
alter table public.audit_logs add column if not exists old_value jsonb;
alter table public.audit_logs add column if not exists new_value jsonb;
alter table public.audit_logs add column if not exists page text;

create or replace function public.app_has_feature(p_feature text) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.subscriptions s join public.subscription_plans p on p.code=s.plan_code where s.business_id=public.app_business_id() and s.status='active' and (p.features ? p_feature or p.features ? '*') and (s.ends_at is null or s.ends_at>now()))
 or not exists(select 1 from public.subscriptions s where s.business_id=public.app_business_id());
$$;

create or replace function public.validate_activity_payload(p_business_id uuid,p_payload jsonb) returns boolean language plpgsql stable security definer set search_path=public as $$
declare v_activity text; v_definition jsonb; v_required text;
begin
 if p_business_id<>public.app_business_id() then raise exception 'business_forbidden'; end if;
 select business_type_id into v_activity from public.businesses where id=p_business_id;
 select definition into v_definition from public.activity_definitions where id=v_activity and is_active;
 if v_definition is null then return true; end if;
 for v_required in select jsonb_array_elements_text(coalesce(v_definition#>'{validationRules,requiredFields}','[]'::jsonb)) loop
   if v_required not in('name','sale_price') and coalesce(p_payload#>>array['attributes',v_required],'')='' then raise exception 'required_activity_field:%',v_required; end if;
 end loop;
 return true;
end $$;

alter table public.activity_definitions enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.app_versions enable row level security;
drop policy if exists public_read_activity_definitions on public.activity_definitions; create policy public_read_activity_definitions on public.activity_definitions for select using(is_active);
drop policy if exists public_read_subscription_plans on public.subscription_plans; create policy public_read_subscription_plans on public.subscription_plans for select using(is_active);
drop policy if exists public_read_app_versions on public.app_versions; create policy public_read_app_versions on public.app_versions for select using(is_active);

do $$ declare t text; begin
 foreach t in array array['subscriptions','tax_rules','price_lists','price_list_items','promotions','cash_registers','cash_shifts','cash_movements','accounts','journal_entries','journal_lines','stock_transfers','stock_transfer_items','warranties','warranty_tickets','loyalty_transactions','notifications'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('drop policy if exists tenant_select on public.%I',t);
  execute format('drop policy if exists tenant_insert on public.%I',t);
  execute format('drop policy if exists tenant_update on public.%I',t);
  execute format('drop policy if exists tenant_delete on public.%I',t);
  execute format('create policy tenant_select on public.%I for select using(business_id=public.app_business_id())',t);
  execute format('create policy tenant_insert on public.%I for insert with check(business_id=public.app_business_id())',t);
  execute format('create policy tenant_update on public.%I for update using(business_id=public.app_business_id() and public.app_is_admin()) with check(business_id=public.app_business_id() and public.app_is_admin())',t);
  execute format('create policy tenant_delete on public.%I for delete using(business_id=public.app_business_id() and public.app_is_admin())',t);
 end loop;
end $$;

alter table public.crash_reports enable row level security;
drop policy if exists crash_insert on public.crash_reports;create policy crash_insert on public.crash_reports for insert with check(business_id is null or business_id=public.app_business_id());
create index if not exists idx_notifications_business_unread on public.notifications(business_id,is_read,created_at desc);
create index if not exists idx_serial_business_imei on public.product_serial_numbers(business_id,imei);
create index if not exists idx_journal_business_date on public.journal_entries(business_id,entry_date);
create index if not exists idx_transfer_business_status on public.stock_transfers(business_id,status,created_at desc);
