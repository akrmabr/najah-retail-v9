import { Link } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import MiniChart from '../components/MiniChart';
import { getBusinessContext } from '../services/businessContext';
import { db } from '../services/db';
import { dashboardStats } from '../services/reports';
import { can } from '../services/auth';
import { expiryBuckets, lowStock } from '../services/inventory';
import type { User } from '../types/models';
import { money } from '../utils/ids';

const metricLabels: Record<string, string> = {
  todaySales: 'مبيعات اليوم',
  todayProfit: 'صافي ربح اليوم',
  stockValue: 'قيمة المخزون',
  lowStock: 'أصناف منخفضة المخزون',
  expired: 'دفعات منتهية',
  nearExpiry: 'دفعات تنتهي خلال 30 يوماً',
  expenses: 'مصروفات اليوم',
  customerDebts: 'ديون العملاء',
  supplierDebts: 'ديون الموردين',
};
const moneyMetrics = new Set([
  'todaySales',
  'todayProfit',
  'stockValue',
  'expenses',
  'customerDebts',
  'supplierDebts',
]);

export default function Dashboard({ user }: { user: User }) {
  const stats = useLiveQuery(dashboardStats, []);
  const low = useLiveQuery(lowStock, []);
  const expiry = useLiveQuery(expiryBuckets, []);
  const userCount = useLiveQuery(() => db.users.count(), []) || 0;
  const activity = useLiveQuery(getBusinessContext, []);

  const valueFor = (metric: string): number | undefined => {
    switch (metric) {
      case 'lowStock': return low?.length;
      case 'expired': return expiry?.expired.length;
      case 'nearExpiry': return expiry ? expiry.d7.length + expiry.d30.length : undefined;
      default: return stats?.[metric as keyof typeof stats];
    }
  };

  return (
    <section>
      <h1>لوحة التحكم — {activity?.label || 'جاري تحميل النشاط'}</h1>
      {can(user, 'users') && userCount <= 1 && (
        <div className="callout">
          <b>ابدأ بإضافة فريق العمل</b>
          <span>أنشئ حساباً للمدير أو الكاشير أو مسؤول المخزون وحدد صلاحياته.</span>
          <Link className="primary" to="/users">إضافة مستخدم وصلاحياته</Link>
        </div>
      )}
      <div className="grid cards">
        {(activity?.dashboardMetrics || ['todaySales', 'todayProfit', 'stockValue', 'lowStock']).map((metric) => {
          const value = valueFor(metric);
          return (
            <div className="card stat" key={metric}>
              <span>{metricLabels[metric] || metric}</span>
              <b>{value === undefined ? '—' : moneyMetrics.has(metric) ? money(value) : value}</b>
            </div>
          );
        })}
      </div>
      <div className="grid two">
        <div className="card">
          <h3>{activity?.inventoryLabel || 'تنبيهات المخزون'}</h3>
          <p>منتجات منخفضة: {low?.length ?? '—'}</p>
          {activity?.supportsExpiry && (
            <>
              <p>دفعات منتهية: {expiry?.expired.length ?? '—'}</p>
              <p>تنتهي خلال 30 يوماً: {expiry ? expiry.d7.length + expiry.d30.length : '—'}</p>
            </>
          )}
        </div>
        <div className="card"><h3>مؤشر آخر 30 يوماً</h3><MiniChart /></div>
      </div>
    </section>
  );
}