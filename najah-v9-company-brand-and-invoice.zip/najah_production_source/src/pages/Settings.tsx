import {useLiveQuery} from 'dexie-react-hooks';
import {db} from '../services/db';
import {useState,useEffect} from 'react';
import {now} from '../utils/ids'; import {BUSINESS_TYPE_OPTIONS} from '../config/businessTypes';

const labels:any={
  pharmacy_name:'اسم المتجر / النشاط',
  address:'العنوان',
  phone:'الهاتف',
  email:'البريد الإلكتروني',
  tax_number:'الرقم الضريبي',
  currency_symbol:'رمز العملة',
  invoice_footer:'نص أسفل الفاتورة',
  default_paper:'حجم ورق الطباعة',
  tax_rate:'نسبة الضريبة',
  offline_grace_days:'أيام السماح بدون إنترنت'
};

export default function Settings(){
  const settings=useLiveQuery(()=>db.settings.get('settings'),[]);
  const [f,setF]=useState<any>({});
  const [msg,setMsg]=useState('');
  useEffect(()=>{if(settings)setF(settings)},[settings]);

  function setLogo(file?:File){
    if(!file) return;
    if(!file.type.startsWith('image/')){setMsg('اختر ملف صورة صالح للشعار.');return;}
    const reader=new FileReader();
    reader.onload=()=>{setF((x:any)=>({...x,logo:String(reader.result)})); setMsg('تم اختيار شعار المتجر. اضغط حفظ الإعدادات لتثبيته.');};
    reader.onerror=()=>setMsg('تعذر قراءة ملف الشعار.');
    reader.readAsDataURL(file);
  }

  async function save(){
    setMsg('');
    await db.settings.put({
      ...settings,
      ...f,
      tax_rate:Number(f.tax_rate||0),
      offline_grace_days:Number(f.offline_grace_days||7),
      updated_at:now()
    });
    setMsg('تم حفظ إعدادات المتجر بنجاح. سيظهر الشعار في الفواتير.');
  }

  return <section><h1>الإعدادات</h1>
    <div className="card settings-logo-card">
      <div>
        <h3>شعار المتجر</h3>
        <p>هذا شعار العميل/المتجر ويظهر في الفاتورة فقط. شعار النجاح يبقى شعار النظام ولا يتغير.</p>
      </div>
      <div className="client-logo-preview">{f.logo?<img src={f.logo} alt="شعار النشاط"/>:<span>لا يوجد شعار محفوظ</span>}</div>
      <label className="upload">اختيار شعار المتجر<input hidden type="file" accept="image/*" onChange={e=>setLogo(e.target.files?.[0])}/></label>
      {f.logo&&<button className="ghost" onClick={()=>setF({...f,logo:''})}>حذف شعار المتجر</button>}
    </div>
    <div className="card formgrid">
      <select value={f.business_type||'general'} onChange={e=>setF({...f,business_type:e.target.value})}>{BUSINESS_TYPE_OPTIONS.map(activity=><option key={activity.id} value={activity.id}>{activity.label}</option>)}</select>
      {['pharmacy_name','address','phone','email','tax_number','currency_symbol','invoice_footer','default_paper','tax_rate','offline_grace_days'].map(k=><input key={k} value={f[k]||''} onChange={e=>setF({...f,[k]:e.target.value})} placeholder={labels[k]||k}/>) }
      <button onClick={save}>حفظ الإعدادات</button>
    </div>
    {msg&&<div className="alert">{msg}</div>}
  </section>
}
