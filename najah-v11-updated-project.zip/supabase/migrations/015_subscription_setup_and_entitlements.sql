-- Bind the selected plan and activity to the first business atomically.
create or replace function public.setup_business_for_user(
  p_user_id uuid,p_license_key_hash text,p_business_type_id text,p_name text,p_owner_name text,p_phone text,p_email text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_license public.licenses%rowtype;v_business uuid;v_branch uuid;v_plan text;
begin
 if p_user_id is null or nullif(trim(p_license_key_hash),'') is null then raise exception 'setup_parameters_required';end if;
 select * into v_license from public.licenses where license_key_hash=p_license_key_hash for update;
 if not found then raise exception 'license_not_found';end if;
 if v_license.status<>'active' or (v_license.expires_at is not null and v_license.expires_at<now()) then raise exception 'license_not_active';end if;
 if v_license.business_id is not null then raise exception 'license_already_claimed';end if;
 if v_license.business_type_id is not null and v_license.business_type_id<>p_business_type_id then raise exception 'activity_not_entitled';end if;
 if not exists(select 1 from public.business_types where id=p_business_type_id and is_enabled) then raise exception 'business_type_invalid';end if;
 v_plan:=coalesce(v_license.plan_code,'basic');
 insert into public.businesses(business_type_id,name,owner_name,phone,email,created_by,settings)
 values(p_business_type_id,trim(p_name),trim(p_owner_name),nullif(trim(p_phone),''),lower(trim(p_email)),p_user_id,jsonb_build_object('plan_code',v_plan)) returning id into v_business;
 insert into public.branches(business_id,name,code) values(v_business,'الفرع الرئيسي','MAIN') returning id into v_branch;
 insert into public.business_settings(business_id) values(v_business);
 insert into public.business_members(business_id,branch_id,user_id,display_name,username,role,permissions)
 values(v_business,v_branch,p_user_id,trim(p_owner_name),lower(trim(p_email)),'owner','["*"]'::jsonb);
 insert into public.subscriptions(business_id,plan_code,status,starts_at,ends_at) values(v_business,v_plan,'active',now(),v_license.expires_at);
 update public.licenses set business_id=v_business,business_type_id=p_business_type_id,store_name=trim(p_name),owner_name=trim(p_owner_name),activation_date=coalesce(activation_date,now()),updated_at=now() where id=v_license.id;
 insert into public.license_events(license_id,event_type,actor_user_id,details) values(v_license.id,'business_setup',p_user_id,jsonb_build_object('business_id',v_business,'business_type_id',p_business_type_id,'plan_code',v_plan));
 return v_business;
end $$;
revoke all on function public.setup_business_for_user(uuid,text,text,text,text,text,text) from public;
grant execute on function public.setup_business_for_user(uuid,text,text,text,text,text,text) to service_role;
