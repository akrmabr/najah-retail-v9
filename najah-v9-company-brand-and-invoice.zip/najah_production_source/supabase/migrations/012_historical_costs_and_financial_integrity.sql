-- V9 production hardening: historical purchase cost, auditable stock counts,
-- and return-aware customer/supplier balances. Additive and safe for existing data.

alter table public.product_batches
  add column if not exists purchase_price numeric(14,3) not null default 0;
alter table public.sale_items
  add column if not exists cost_total numeric(14,3) not null default 0;

create index if not exists idx_sale_items_business_sale on public.sale_items(business_id,sale_id);
create index if not exists idx_purchase_items_business_purchase on public.purchase_items(business_id,purchase_id);
create index if not exists idx_returns_business_customer on public.returns(business_id,customer_id,return_type,status);
create index if not exists idx_returns_business_supplier on public.returns(business_id,supplier_id,return_type,status);

-- Keep the historical purchase cost on each received batch.
create or replace function public.receive_purchase(
  p_business_id uuid,
  p_branch_id uuid,
  p_supplier_id uuid,
  p_invoice_number text,
  p_payment_method text,
  p_paid numeric,
  p_items jsonb
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare
  v_purchase_id uuid := gen_random_uuid();
  v_subtotal numeric := 0;
  v_item jsonb;
  v_product_id uuid;
  v_variant_id uuid;
  v_batch_id uuid;
  v_qty numeric;
  v_cost numeric;
  v_total numeric;
  v_batch uuid;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'items_required'; end if;
  if p_paid < 0 then raise exception 'invalid_paid_amount'; end if;
  select id into v_purchase_id from public.purchases where business_id=p_business_id and invoice_number=p_invoice_number;
  if v_purchase_id is not null then return v_purchase_id; end if;
  v_purchase_id := gen_random_uuid();

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_cost := (v_item->>'unit_cost')::numeric;
    if v_qty <= 0 or v_cost < 0 then raise exception 'invalid_purchase_item'; end if;
    v_subtotal := v_subtotal + v_qty*v_cost;
  end loop;
  v_total := v_subtotal;
  if p_paid > v_total then raise exception 'paid_exceeds_total'; end if;

  insert into public.purchases(id,business_id,branch_id,supplier_id,invoice_number,payment_method,subtotal,total,paid,remaining)
  values(v_purchase_id,p_business_id,p_branch_id,p_supplier_id,p_invoice_number,p_payment_method,v_subtotal,v_total,p_paid,v_total-p_paid);

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_batch_id := nullif(v_item->>'batch_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_cost := (v_item->>'unit_cost')::numeric;
    insert into public.product_batches(id,business_id,product_id,variant_id,batch_number,expiry_date,purchase_price,quantity)
    values(coalesce(v_batch_id,gen_random_uuid()),p_business_id,v_product_id,v_variant_id,nullif(v_item->>'batch_number',''),nullif(v_item->>'expiry_date','')::date,v_cost,0)
    returning id into v_batch;
    insert into public.purchase_items(purchase_id,business_id,product_id,variant_id,batch_id,quantity,unit_cost,total)
    values(v_purchase_id,p_business_id,v_product_id,v_variant_id,v_batch,v_qty,v_cost,v_qty*v_cost);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by)
    values(p_business_id,p_branch_id,v_product_id,v_variant_id,v_batch,'purchase',v_qty,'purchase',v_purchase_id,auth.uid());
  end loop;
  if p_paid > 0 then
    insert into public.payments(business_id,supplier_id,purchase_id,amount,payment_method,created_by)
    values(p_business_id,p_supplier_id,v_purchase_id,p_paid,p_payment_method,auth.uid());
  end if;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details)
  values(p_business_id,p_branch_id,auth.uid(),'purchase.received','purchase',v_purchase_id,jsonb_build_object('invoice_number',p_invoice_number,'total',v_total));
  return v_purchase_id;
end;
$$;

-- Replace the sale procedure so every sale item keeps its cost at sale time.
create or replace function public.complete_sale(
  p_business_id uuid,
  p_branch_id uuid,
  p_customer_id uuid,
  p_invoice_number text,
  p_payment_method text,
  p_paid numeric,
  p_items jsonb
) returns uuid
language plpgsql security invoker set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_subtotal numeric := 0;
  v_total numeric := 0;
  v_item jsonb;
  v_product_id uuid;
  v_variant_id uuid;
  v_batch_id uuid;
  v_qty numeric;
  v_price numeric;
  v_cost numeric;
  v_discount numeric;
  v_item_total numeric;
  v_cost_total numeric;
  v_available numeric;
  v_variant_cost numeric;
  v_product_cost numeric;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if p_invoice_number is null or length(trim(p_invoice_number))=0 then raise exception 'invoice_number_required'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'items_required'; end if;
  if p_paid < 0 then raise exception 'invalid_paid_amount'; end if;
  select id into v_sale_id from public.sales where business_id=p_business_id and invoice_number=p_invoice_number;
  if v_sale_id is not null then return v_sale_id; end if;
  v_sale_id := gen_random_uuid();

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_batch_id := nullif(v_item->>'batch_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    v_discount := coalesce((v_item->>'discount')::numeric,0);
    if v_qty <= 0 or v_price < 0 or v_discount < 0 or v_discount > v_qty*v_price then raise exception 'invalid_sale_item'; end if;
    select coalesce(sum(sm.quantity_delta),0) into v_available
      from public.stock_movements sm
      where sm.business_id=p_business_id and sm.product_id=v_product_id
        and sm.variant_id is not distinct from v_variant_id
        and sm.batch_id is not distinct from v_batch_id;
    if v_available < v_qty then raise exception 'insufficient_stock for product %', v_product_id; end if;
    select pb.purchase_price into v_cost from public.product_batches pb
      where pb.id=v_batch_id and pb.business_id=p_business_id;
    if v_cost is null then
      select pv.purchase_price into v_variant_cost from public.product_variants pv
        where pv.id=v_variant_id and pv.business_id=p_business_id;
      select pr.purchase_price into v_product_cost from public.products pr
        where pr.id=v_product_id and pr.business_id=p_business_id;
      v_cost := coalesce(v_variant_cost,v_product_cost,0);
    end if;
    v_item_total := greatest(0, v_qty*v_price-v_discount);
    v_subtotal := v_subtotal + v_item_total;
  end loop;
  v_total := v_subtotal;
  if p_paid > v_total then raise exception 'paid_exceeds_total'; end if;

  insert into public.sales(id,business_id,branch_id,customer_id,cashier_id,invoice_number,payment_method,subtotal,total,paid,remaining)
  values(v_sale_id,p_business_id,p_branch_id,p_customer_id,auth.uid(),p_invoice_number,p_payment_method,v_subtotal,v_total,p_paid,v_total-p_paid);

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_product_id := (v_item->>'product_id')::uuid;
    v_variant_id := nullif(v_item->>'variant_id','')::uuid;
    v_batch_id := nullif(v_item->>'batch_id','')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    v_discount := coalesce((v_item->>'discount')::numeric,0);
    select pb.purchase_price into v_cost from public.product_batches pb where pb.id=v_batch_id and pb.business_id=p_business_id;
    if v_cost is null then
      select pv.purchase_price into v_variant_cost from public.product_variants pv where pv.id=v_variant_id and pv.business_id=p_business_id;
      select pr.purchase_price into v_product_cost from public.products pr where pr.id=v_product_id and pr.business_id=p_business_id;
      v_cost := coalesce(v_variant_cost,v_product_cost,0);
    end if;
    v_item_total := greatest(0, v_qty*v_price-v_discount);
    v_cost_total := v_qty*coalesce(v_cost,0);
    insert into public.sale_items(sale_id,business_id,product_id,variant_id,batch_id,quantity,unit_price,discount,total,cost_total)
    values(v_sale_id,p_business_id,v_product_id,v_variant_id,v_batch_id,v_qty,v_price,v_discount,v_item_total,v_cost_total);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by)
    values(p_business_id,p_branch_id,v_product_id,v_variant_id,v_batch_id,'sale',-v_qty,'sale',v_sale_id,auth.uid());
  end loop;
  if p_paid > 0 then
    insert into public.payments(business_id,customer_id,sale_id,amount,payment_method,created_by)
    values(p_business_id,p_customer_id,v_sale_id,p_paid,p_payment_method,auth.uid());
  end if;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details)
  values(p_business_id,p_branch_id,auth.uid(),'sale.completed','sale',v_sale_id,jsonb_build_object('invoice_number',p_invoice_number,'total',v_total));
  return v_sale_id;
end;
$$;

create or replace view public.business_profit_daily as
with sale_base as (
  select s.id,s.business_id,s.created_at::date as day,s.total
  from public.sales s
  where s.business_id=public.app_business_id() and s.status='completed'
), sale_costs as (
  select sb.id,sb.business_id,sb.day,
         coalesce(sum(coalesce(nullif(si.cost_total,0),coalesce(si.quantity,0)*coalesce(pb.purchase_price,pv.purchase_price,p.purchase_price,0))),0) as cost_of_goods_sold
  from sale_base sb
  left join public.sale_items si on si.sale_id=sb.id and si.business_id=sb.business_id
  left join public.product_batches pb on pb.id=si.batch_id and pb.business_id=sb.business_id
  left join public.product_variants pv on pv.id=si.variant_id and pv.business_id=sb.business_id
  left join public.products p on p.id=si.product_id and p.business_id=sb.business_id
  group by sb.id,sb.business_id,sb.day
), sale_totals as (
  select sb.business_id,sb.day,sum(sb.total) as revenue,sum(sc.cost_of_goods_sold) as cost_of_goods_sold
  from sale_base sb join sale_costs sc on sc.id=sb.id group by sb.business_id,sb.day
), expense_totals as (
  select e.business_id,e.created_at::date as day,sum(e.amount) as expenses
  from public.expenses e where e.business_id=public.app_business_id() group by e.business_id,e.created_at::date
), return_totals as (
  select r.business_id,r.created_at::date as day,sum(r.refund_amount) as sales_returns
  from public.returns r
  where r.business_id=public.app_business_id() and r.return_type='sale_return' and r.status='completed'
  group by r.business_id,r.created_at::date
)
select coalesce(st.business_id,et.business_id,rt.business_id) as business_id,
       coalesce(st.day,et.day,rt.day) as day,
       (coalesce(st.revenue,0)-coalesce(rt.sales_returns,0))::numeric(14,3) as revenue,
       coalesce(st.cost_of_goods_sold,0)::numeric(14,3) as cost_of_goods_sold,
       coalesce(et.expenses,0)::numeric(14,3) as expenses,
       (coalesce(st.revenue,0)-coalesce(rt.sales_returns,0)-coalesce(st.cost_of_goods_sold,0))::numeric(14,3) as gross_profit,
       (coalesce(st.revenue,0)-coalesce(rt.sales_returns,0)-coalesce(st.cost_of_goods_sold,0)-coalesce(et.expenses,0))::numeric(14,3) as net_profit
from sale_totals st
full join expense_totals et using (business_id,day)
full join return_totals rt on rt.business_id=coalesce(st.business_id,et.business_id) and rt.day=coalesce(st.day,et.day);

create or replace function public.get_business_report(p_from date, p_to date)
returns jsonb language sql stable security invoker set search_path=public
as $$
select jsonb_build_object(
  'sales',coalesce((select jsonb_agg(to_jsonb(x) order by x.day) from (select * from public.business_profit_daily where day between p_from and p_to) x),'[]'::jsonb),
  'stock',coalesce((select jsonb_agg(to_jsonb(x)) from (select product_id,variant_id,batch_id,quantity from public.business_stock_balances where quantity <> 0) x),'[]'::jsonb),
  'customers',coalesce((select jsonb_agg(to_jsonb(x)) from (select c.id,c.name,
    coalesce(c.opening_balance,0)
    +coalesce((select sum(s.remaining) from public.sales s where s.customer_id=c.id and s.business_id=public.app_business_id() and s.status='completed'),0)
    -coalesce((select sum(py.amount) from public.payments py where py.customer_id=c.id and py.business_id=public.app_business_id()),0)
    -coalesce((select sum(r.refund_amount) from public.returns r where r.customer_id=c.id and r.business_id=public.app_business_id() and r.return_type='sale_return' and r.status='completed'),0) as balance
    from public.customers c where c.business_id=public.app_business_id()) x),'[]'::jsonb),
  'suppliers',coalesce((select jsonb_agg(to_jsonb(x)) from (select s.id,s.name,
    coalesce(s.opening_balance,0)
    +coalesce((select sum(pu.remaining) from public.purchases pu where pu.supplier_id=s.id and pu.business_id=public.app_business_id() and pu.status='received'),0)
    -coalesce((select sum(py.amount) from public.payments py where py.supplier_id=s.id and py.business_id=public.app_business_id()),0)
    -coalesce((select sum(r.refund_amount) from public.returns r where r.supplier_id=s.id and r.business_id=public.app_business_id() and r.return_type='purchase_return' and r.status='completed'),0) as balance
    from public.suppliers s where s.business_id=public.app_business_id()) x),'[]'::jsonb)
);
$$;

-- Keep the denormalized batch quantity in step with every auditable movement.
-- The movement ledger remains the source for balances; this column is an operational cache.
create or replace function public.apply_stock_movement_to_batch()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_after numeric;
begin
  if new.batch_id is null then return new; end if;
  update public.product_batches
  set quantity=quantity+new.quantity_delta
  where id=new.batch_id and business_id=new.business_id
  returning quantity into v_after;
  if not found then raise exception 'stock_batch_not_found'; end if;
  if v_after < 0 then raise exception 'negative_batch_quantity'; end if;
  return new;
end;
$$;
revoke all on function public.apply_stock_movement_to_batch() from public;
drop trigger if exists stock_movement_batch_quantity on public.stock_movements;
create trigger stock_movement_batch_quantity
after insert on public.stock_movements
for each row execute function public.apply_stock_movement_to_batch();

-- A completed sale/purchase/return legitimately creates a stock movement.
-- Keep the table protected, but allow the permission that owns the transaction
-- to create its own auditable movement; never allow arbitrary cross-tenant rows.
drop policy if exists tenant_insert on public.stock_movements;
create policy tenant_insert on public.stock_movements
for insert with check (
  business_id=public.app_business_id()
  and (
    public.app_has_permission('inventory')
    or public.app_has_permission('pos')
    or public.app_has_permission('purchases')
    or public.app_has_permission('returns')
  )
);
