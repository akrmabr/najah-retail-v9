import { db, getPharmacyId } from './db';
import type { SyncOperation, SyncStatus } from '../types/models';
import { now, uid } from '../utils/ids';

/**
 * Offline-first queue.
 *
 * The queue is deliberately independent from the UI: every write can be
 * recorded before the network request is attempted. The server must accept
 * operation_key as an idempotency key and acknowledge it only after the
 * transaction commits.
 */
export async function enqueueOperation(operation_type: string, payload: unknown, operation_key: string = uid('op')) {
  const pharmacy_id = getPharmacyId();
  const existing = await db.sync_operations.where('operation_key').equals(operation_key).first();
  if (existing) return existing;
  const operation: SyncOperation = {
    id: uid('sync'),
    pharmacy_id,
    operation_key,
    operation_type,
    payload,
    status: 'pending',
    attempts: 0,
    created_at: now(),
    updated_at: now(),
  };
  await db.sync_operations.add(operation);
  return operation;
}

export async function updateOperation(id: string, patch: Partial<SyncOperation>) {
  await db.sync_operations.update(id, { ...patch, updated_at: now() });
}

export async function listSyncOperations(status?: SyncStatus) {
  const rows: SyncOperation[] = await db.sync_operations.toArray();
  return rows
    .filter((row: SyncOperation) => !status || row.status === status)
    .sort((a: SyncOperation, b: SyncOperation) => a.created_at.localeCompare(b.created_at));
}

export async function markOperationApplied(id: string, server_version?: string) {
  await updateOperation(id, { status: 'applied', acknowledged_at: now(), server_version, last_error: undefined });
}

export async function markOperationFailed(id: string, error: unknown, conflict = false) {
  const row = await db.sync_operations.get(id);
  await updateOperation(id, {
    status: conflict ? 'conflict' : 'failed',
    attempts: (row?.attempts || 0) + 1,
    last_error: error instanceof Error ? error.message : String(error),
  });
}

export async function pendingSyncCount() {
  const rows = await listSyncOperations();
  return rows.filter((row: SyncOperation) => row.status === 'pending' || row.status === 'failed').length;
}
export async function syncPendingOperations() {
  if (!navigator.onLine) return { attempted: 0, applied: 0, failed: 0 };
  const settings: any = await db.settings.get('settings');
  const endpoint = String(settings?.supabase_url || localStorage.getItem('alshifaa_license_endpoint') || '').replace(/\/+$/, '');
  const anonKey = String(settings?.supabase_anon_key || import.meta.env.VITE_SUPABASE_ANON_KEY || '');
  const accessToken = String(settings?.supabase_access_token || '');
  if (!endpoint || !anonKey || !accessToken) return { attempted: 0, applied: 0, failed: 0 };
  const rows = (await listSyncOperations()).filter((row) => row.status === 'pending' || row.status === 'failed').slice(0, 25);
  let applied = 0, failed = 0;
  for (const row of rows) {
    if (row.status === 'failed' && row.updated_at && Date.now() - Date.parse(row.updated_at) < Math.min(30000, Math.max(2000, row.attempts * 5000))) continue;
    await updateOperation(row.id, { status: 'syncing' });
    try {
      const response = await fetch(`${endpoint}/rest/v1/rpc/apply_sync_operation`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', apikey: anonKey, authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ p_operation_key: row.operation_key, p_operation_type: row.operation_type, p_payload: row.payload }),
      });
      const data: any = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.message || data?.hint || data?.error || `sync_${response.status}`);
      await markOperationApplied(row.id, String(data?.result || ''));
      applied += 1;
    } catch (error) {
      await markOperationFailed(row.id, error, false);
      failed += 1;
    }
  }
  if (settings) await db.settings.update('settings', { last_sync_at: new Date().toISOString() });
  return { attempted: applied + failed, applied, failed };
}
