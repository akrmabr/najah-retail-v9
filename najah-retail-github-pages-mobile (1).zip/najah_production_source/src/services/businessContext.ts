import { db } from './db';
import { getActivityDefinition, type ActivityDefinition } from '../config/activityEngine';
import type { CanonicalBusinessTypeId } from '../config/businessTypes';

type BusinessSettingsRecord = {
  business_type?: string;
  business_name?: string;
  pharmacy_name?: string;
  logo?: string;
  [key: string]: unknown;
};

export async function getBusinessContext(): Promise<ActivityDefinition> {
  const settings = await db.settings.get('settings') as BusinessSettingsRecord | undefined;
  return getActivityDefinition(settings?.business_type);
}

export async function getBusinessSettings(): Promise<BusinessSettingsRecord> {
  return (await db.settings.get('settings') as BusinessSettingsRecord | undefined) || {};
}

export async function saveBusinessType(businessType: CanonicalBusinessTypeId): Promise<void> {
  const current = await getBusinessSettings();
  if (current.business_type && current.business_type !== businessType) {
    throw new Error('تغيير النشاط يتطلب فحص توافق وترحيلاً آمناً للبيانات. لا يمكن تغييره من الإعدادات.');
  }
  await db.settings.put({
    ...current,
    id: 'settings',
    business_type: businessType,
    updated_at: new Date().toISOString(),
  } as never);
}