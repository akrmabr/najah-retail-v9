import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import { cancelSale } from '../services/sales';
import { returnSale } from '../services/returns';
import { printInvoice } from '../services/invoice';
import type { User } from '../types/models';
import { money } from '../utils/ids';

export default function SalesHistory({ user }: { user: User }) {
  const sales = useLiveQuery(() => db.sales.orderBy('created_at').reverse().toArray(), []) || [];
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const [message, setMessage] = useState('');
  async function cancel(id: string) {
    const reason = prompt('اكتب سبب إلغاء الفاتورة');
    if (!reason) return;
    try { await cancelSale(user.id, id, reason); setMessage('تم إلغاء الفاتورة وعكس أثرها على المخزون والحسابات.'); }
    catch (e: any) { setMessage(e.message); }
  }
  async function returnInvoice(id: string) {
    const reason = prompt('اكتب سبب ترجيع الفاتورة');
    if (!reason) return;
    try {
      await returnSale(user.id, id, reason);
      setMessage('تم ترجيع الفاتورة وإعادة الكميات للمخزون.');
    } catch (e: any) {
      setMessage(e.message);
    }
  }
  async function viewInvoice(id: string) {
    const popup = window.open('', '_blank');
    try { await printInvoice(id, popup); setMessage('تم فتح الفاتورة للطباعة.'); }
    catch (e: any) { popup?.close(); setMessage(e?.message || 'تعذر فتح الفاتورة للطباعة.'); }
  }
  return <section><h1>سجل المبيعات</h1>{message&&<div className="alert">{message}</div>}<div className="card"><table><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العميل</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th><th>إجراءات</th></tr></thead><tbody>{sales.map(s=><tr key={s.id}><td>{s.invoice_no}</td><td>{new Date(s.created_at).toLocaleDateString('ar')}</td><td>{customers.find(c=>c.id===s.customer_id)?.name||'نقدي'}</td><td>{money(s.total)}</td><td>{money(s.paid)}</td><td>{money(s.remaining)}</td><td><span className={`status ${s.status==='COMPLETED'?'ok':'bad'}`}>{s.status==='COMPLETED'?'مكتملة':s.status==='CANCELLED'?'ملغاة':'مرتجعة'}</span></td><td><button onClick={()=>viewInvoice(s.id)}>عرض/طباعة</button>{s.status==='COMPLETED'&&<><button className="danger" onClick={()=>cancel(s.id)}>إلغاء</button><button className="danger" onClick={()=>returnInvoice(s.id)}>مرتجع</button></>}</td></tr>)}</tbody></table>{!sales.length&&<p className="empty">لا توجد مبيعات بعد.</p>}</div></section>;
}
