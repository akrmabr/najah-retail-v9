import { db, getPharmacyId } from './db';
import type { StockCount, StockCountItem } from '../types/models';
import { audit } from './audit';
import { enqueueOperation } from './sync';
import { now, uid } from '../utils/ids';
export type CountLine = { product_id: string; batch_id: string; counted_quantity: number };
export async function completeStockCount(user_id: string, lines: CountLine[], notes = '') {
  if (!lines.length) throw new Error('أدخل كمية جرد لصنف واحد على الأقل.'); const pharmacy_id = getPharmacyId(); const count: StockCount = { id: uid('count'), pharmacy_id, status: 'COMPLETED', notes, created_by: user_id, created_at: now(), updated_at: now() }; const items: StockCountItem[] = [];
  await (db.transaction as any)('rw', [db.stock_counts, db.stock_count_items, db.batches, db.stock_movements, db.audit_logs, db.sync_operations], async () => {
    await db.stock_counts.add(count);
    for (const line of lines) { const batch = await db.batches.get(line.batch_id); if (!batch || batch.product_id !== line.product_id) throw new Error('دفعة الجرد غير صحيحة.'); if (!Number.isFinite(line.counted_quantity) || line.counted_quantity < 0) throw new Error('الكمية المعدودة غير صالحة.'); const difference = line.counted_quantity - batch.quantity; await db.batches.update(batch.id, { quantity: line.counted_quantity, updated_at: count.updated_at }); const item: StockCountItem = { id: uid('count_item'), pharmacy_id, stock_count_id: count.id, product_id: line.product_id, batch_id: line.batch_id, system_quantity: batch.quantity, counted_quantity: line.counted_quantity, difference, created_at: count.created_at }; items.push(item); if (difference !== 0) await db.stock_movements.add({ id: uid('move'), pharmacy_id, created_at: count.created_at, updated_at: count.updated_at, product_id: line.product_id, batch_id: line.batch_id, type: 'adjustment', quantity: difference, before_qty: batch.quantity, after_qty: line.counted_quantity, user_id, reference_id: count.id, notes: `جرد دوري${notes ? ` — ${notes}` : ''}` }); }
    await db.stock_count_items.bulkAdd(items); await audit(user_id, 'stock_count_completed', 'stock_counts', count.id, { notes, item_count: items.length }); await enqueueOperation('stock_count', { stock_count_id: count.id, notes, items: items.map((item) => ({ product_id: item.product_id, batch_id: item.batch_id, system_quantity: item.system_quantity, counted_quantity: item.counted_quantity, difference: item.difference })) }, `stock-count:${count.id}`);
  }); return { count, items };
}
