export type TrackingMode='quantity'|'batch_expiry'|'variant'|'serial'|'imei'|'dimension'|'weight';
export type FieldKind='text'|'number'|'date'|'boolean'|'select';
export type ActivityField={id:string;label:string;kind:FieldKind;required?:boolean;options?:string[];searchable?:boolean;printable?:boolean;validation?:{min?:number;max?:number;pattern?:string}};
export type ActivityDefinition={
 id:string;label:string;description:string;
 metadata:{sector:string;icon:string;version:number};
 modules:string[];
 productSchema:{productLabel:string;fields:ActivityField[];units:string[];variantFields:string[];tracking:TrackingMode[]};
 inventoryRules:{rotation:'FIFO'|'FEFO'|'SERIAL';allowFractional:boolean;requireBatch:boolean;requireExpiry:boolean;requireSerial:boolean;requireImei:boolean;unitConversions:boolean};
 posRules:{flow:string[];requireCustomer:boolean;requireSerialSelection:boolean;allowCredit:boolean;allowPartialPayment:boolean};
 pricingRules:{priceLevels:string[];allowPromotions:boolean;allowLineDiscount:boolean};
 workflowRules:{warranty:boolean;prescription:boolean;serviceTickets:boolean};
 reportDefinitions:string[];notificationRules:string[];dashboardWidgets:string[];
 terminology:{product:string;products:string;inventory:string;purchases:string;reports:string};
 permissions:string[];searchRules:string[];printingRules:string[];
 validationRules:{uniqueFields:string[];requiredFields:string[]};
};
