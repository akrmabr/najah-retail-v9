-- Backend permission enforcement. Hiding a button is not a security control.
create or replace function public.app_has_permission(p_permission text)
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(
    select 1 from public.business_members bm
    where bm.user_id=auth.uid() and bm.is_active=true
      and (bm.role in ('owner','administrator') or bm.permissions @> jsonb_build_array('*') or bm.permissions @> jsonb_build_array(p_permission))
  );
$$;
revoke all on function public.app_has_permission(text) from public;
grant execute on function public.app_has_permission(text) to authenticated;

do $$
declare item record;
begin
  for item in select * from (values
    ('products','products'),('product_variants','products'),('product_barcodes','products'),('product_batches','inventory'),('product_serial_numbers','inventory'),
    ('stock_movements','inventory'),('stock_counts','inventory'),('stock_count_items','inventory'),('purchases','purchases'),('purchase_items','purchases'),
    ('sales','pos'),('sale_items','pos'),('returns','returns'),('return_items','returns'),('payments','payments'),('expenses','expenses'),
    ('customers','customers'),('suppliers','suppliers'),('categories','products'),('brands','products'),('units','products')
  ) as x(table_name,permission) loop
    execute format('drop policy if exists tenant_insert on public.%I',item.table_name);
    execute format('drop policy if exists tenant_update on public.%I',item.table_name);
    execute format('drop policy if exists tenant_delete on public.%I',item.table_name);
    execute format('create policy tenant_insert on public.%I for insert with check (business_id=public.app_business_id() and public.app_has_permission(%L))',item.table_name,item.permission);
    execute format('create policy tenant_update on public.%I for update using (business_id=public.app_business_id() and public.app_has_permission(%L)) with check (business_id=public.app_business_id() and public.app_has_permission(%L))',item.table_name,item.permission,item.permission);
    execute format('create policy tenant_delete on public.%I for delete using (business_id=public.app_business_id() and public.app_is_admin())',item.table_name);
  end loop;
end $$;
