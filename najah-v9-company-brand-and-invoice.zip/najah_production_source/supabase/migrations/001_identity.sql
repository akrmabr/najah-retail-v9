-- النجاح لإدارة المحال التجارية
-- Non-destructive foundation migration. Review existing tables before applying.
-- Never place service_role keys in the frontend.

create extension if not exists pgcrypto;

create table if not exists public.business_types (
  id text primary key,
  name_ar text not null,
  name_en text not null,
  is_enabled boolean not null default true,
  module_config jsonb not null default '{}'::jsonb,
  field_config jsonb not null default '{}'::jsonb,
  sort_order integer not null default 100,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.business_types (id, name_ar, name_en, sort_order) values
('clothing','محل ملابس','Clothing Store',10),
('shoes','محل أحذية','Shoes Store',20),
('homeware','محل أواني منزلية','Homeware / Household Utensils',30),
('cosmetics','مستحضرات تجميل','Cosmetics & Beauty Products',40),
('grocery','بقالة / مواد غذائية','Grocery / Food Store',50),
('supermarket','سوبر ماركت','Supermarket',60),
('building_materials','مواد بناء','Building Materials',70),
('electrical','أجهزة كهربائية','Electrical Appliances',80),
('electronics','محل إلكترونيات','Electronics Store',90),
('mobile','هواتف وإكسسوارات','Mobile Phones & Accessories',100),
('furniture','محل أثاث','Furniture Store',110),
('home_furnishings','مفروشات منزلية','Home Furnishings',120),
('hardware','العدد والأدوات','Hardware / Tools Store',130),
('stationery','مكتبة وقرطاسية','Stationery & Book Store',140),
('perfume','محل عطور','Perfume Store',150),
('pharmacy','صيدلية / مستلزمات طبية','Pharmacy / Medical Supplies',160),
('spare_parts','قطع غيار','Spare Parts Store',170),
('car_accessories','إكسسوارات سيارات','Car Accessories',180),
('general','تجارة عامة','General Trading',190),
('other','نشاط آخر','Other',200)
on conflict (id) do update set name_ar=excluded.name_ar,name_en=excluded.name_en;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  business_type_id text references public.business_types(id),
  name text not null,
  owner_name text,
  phone text,
  whatsapp text,
  email text,
  address text,
  city text,
  country text,
  logo_url text,
  currency text not null default 'SDG',
  tax_enabled boolean not null default false,
  tax_rate numeric(7,3) not null default 0 check (tax_rate >= 0),
  invoice_prefix text not null default 'INV',
  settings jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.businesses add column if not exists business_type_id text references public.business_types(id);
alter table public.businesses add column if not exists created_by uuid references auth.users(id);
alter table public.businesses add column if not exists description text;
alter table public.businesses add column if not exists receipt_footer text;
alter table public.businesses add column if not exists social_links jsonb not null default '{}'::jsonb;

create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  code text,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, code)
);

create table if not exists public.business_members (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete set null,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  username text,
  role text not null default 'cashier' check (role in ('owner','administrator','cashier','inventory_manager','sales_employee','accountant')),
  permissions jsonb not null default '[]'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, user_id),
  unique (business_id, username)
);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key_hash text not null unique,
  business_id uuid references public.businesses(id) on delete set null,
  business_type_id text references public.business_types(id),
  store_name text,
  owner_name text,
  status text not null default 'pending' check (status in ('active','expired','suspended','revoked','pending','invalid')),
  activation_date timestamptz,
  expires_at timestamptz,
  device_limit integer not null default 1 check (device_limit > 0),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.license_devices (
  id uuid primary key default gen_random_uuid(),
  license_id uuid not null references public.licenses(id) on delete cascade,
  device_fingerprint_hash text not null,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  unique (license_id, device_fingerprint_hash)
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique (business_id,name)
);
create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null, is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique (business_id,name)
);
create table if not exists public.units (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null, symbol text, allows_fraction boolean not null default false, is_active boolean not null default true, unique (business_id,name)
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null, brand_id uuid references public.brands(id) on delete set null, unit_id uuid references public.units(id) on delete set null,
  name text not null, sku text, base_barcode text, description text, image_url text,
  purchase_price numeric(14,3) not null default 0 check (purchase_price >= 0), sale_price numeric(14,3) not null default 0 check (sale_price >= 0), wholesale_price numeric(14,3) check (wholesale_price is null or wholesale_price >= 0),
  minimum_stock numeric(14,3) not null default 0 check (minimum_stock >= 0), attributes jsonb not null default '{}'::jsonb,
  is_active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (business_id, sku)
);
create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id) on delete cascade,
  sku text, barcode text, attributes jsonb not null default '{}'::jsonb, purchase_price numeric(14,3), sale_price numeric(14,3), minimum_stock numeric(14,3) not null default 0, is_active boolean not null default true, unique (business_id,sku)
);
create table if not exists public.product_barcodes (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id) on delete cascade, variant_id uuid references public.product_variants(id) on delete cascade, barcode text not null, is_primary boolean not null default false, unique (business_id,barcode)
);
create table if not exists public.product_batches (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id) on delete cascade, variant_id uuid references public.product_variants(id) on delete set null,
  batch_number text, expiry_date date, quantity numeric(14,3) not null default 0 check (quantity >= 0), created_at timestamptz not null default now(), unique (business_id,product_id,batch_number)
);
create table if not exists public.product_serial_numbers (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, product_id uuid not null references public.products(id) on delete cascade, variant_id uuid references public.product_variants(id) on delete set null,
  serial_number text not null, imei text, warranty_start date, warranty_end date, status text not null default 'in_stock', unique (business_id,serial_number), unique (business_id,imei)
);

