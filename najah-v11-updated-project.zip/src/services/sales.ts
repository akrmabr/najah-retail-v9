import { db, getPharmacyId } from './db';
import { availableBatches } from './inventory';
import type { CashMovement, PaymentMethod, Sale, SaleItem, Warranty } from '../types/models';
import { now, uid } from '../utils/ids';
import { audit } from './audit';
import { enqueueOperation } from './sync';
import { licenseGate } from './license';
import { getActivityDefinition } from '../activity/registry';
import { ensureChartOfAccounts, postJournalInCurrentTransaction } from './accounting';
import { roundMoney } from '../domain/calculations';

export interface CartLine {
  product_id: string;
  variant_id?: string;
  serial_id?: string;
  quantity: number;
  unit_price: number;
  discount: number;
  tax: number;
  activity_data?: Record<string, unknown>;
}

function accountForPayment(method: PaymentMethod) {
  return method === 'Cash' ? '1000' : '1100';
}

function warrantyMonths(value: unknown) {
  const parsed = Number(String(value ?? '').match(/\d+/)?.[0] || 0);
  return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, 120) : 0;
}

export async function completeSale(
  user_id: string, lines: CartLine[], paid: number, method: PaymentMethod, customer_id?: string,
) {
  const gate = licenseGate();
  if (!gate.ok) throw new Error(gate.message);
  if (!lines.length) throw new Error('السلة فارغة');
  if (!Number.isFinite(paid) || paid < 0) throw new Error('قيمة المدفوع غير صالحة');
  for (const line of lines) {
    if (!line.product_id || !Number.isFinite(line.quantity) || line.quantity <= 0 ||
        !Number.isFinite(line.unit_price) || line.unit_price < 0 ||
        !Number.isFinite(line.discount) || line.discount < 0 ||
        line.discount > line.unit_price || !Number.isFinite(line.tax) ||
        line.tax < 0 || line.tax > 100) {
      throw new Error('بيانات أحد أصناف الفاتورة غير صالحة');
    }
  }
  const settings = await db.settings.get('settings');
  const activity = getActivityDefinition(String(settings?.business_type || 'general'));
  if (activity.posRules.requireCustomer && !customer_id) {
    throw new Error(`اختيار العميل مطلوب في نقطة بيع ${activity.label}.`);
  }
  if (activity.posRules.requireSerialSelection && lines.some((line) => !line.serial_id)) {
    throw new Error('اختر الرقم التسلسلي/IMEI لكل جهاز قبل إكمال البيع.');
  }
  if (method === 'Credit' && !activity.posRules.allowCredit) {
    throw new Error('البيع الآجل غير مسموح لهذا النشاط.');
  }

  await ensureChartOfAccounts();
  const pharmacy_id = getPharmacyId();
  const invoice_no = `S-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const timestamp = now();
  let sale!: Sale;
  const transactionTables = [
    db.sales, db.sale_items, db.batches, db.serial_numbers, db.warranties,
    db.stock_movements, db.customers, db.audit_logs, db.sync_operations,
    db.accounts, db.journal_entries, db.journal_lines, db.cash_shifts,
    db.cash_movements, db.settings,
  ];

  await (db.transaction as any)('rw', transactionTables, async () => {
    let subtotal = 0, tax = 0, discount = 0, profit = 0, totalCost = 0;
    const items: SaleItem[] = [];
    const usedSerials = new Set<string>();

    for (const line of lines) {
      if (line.serial_id) {
        if (usedSerials.has(line.serial_id)) throw new Error('لا يمكن بيع الرقم التسلسلي نفسه مرتين.');
        const serial = await db.serial_numbers.get(line.serial_id);
        if (!serial || serial.status !== 'in_stock' || serial.product_id !== line.product_id ||
            (line.variant_id && serial.variant_id !== line.variant_id) || line.quantity !== 1) {
          throw new Error('الرقم التسلسلي/IMEI المحدد غير متاح للبيع.');
        }
        usedSerials.add(line.serial_id);
      }
      let remainingQuantity = line.quantity;
      const batches = await availableBatches(line.product_id, line.variant_id);
      for (const batch of batches) {
        if (remainingQuantity <= 0) break;
        const quantity = Math.min(remainingQuantity, batch.quantity);
        const lineSubtotal = roundMoney(quantity * line.unit_price);
        const lineDiscount = roundMoney(quantity * line.discount);
        const lineTax = roundMoney((lineSubtotal - lineDiscount) * (line.tax / 100));
        const cost = roundMoney(quantity * batch.purchase_price);
        const lineTotal = roundMoney(lineSubtotal - lineDiscount + lineTax);
        const before = batch.quantity, after = before - quantity;
        await db.batches.update(batch.id, { quantity: after, updated_at: timestamp });
        const item: SaleItem = {
          id: uid('saleitem'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
          sale_id: 'pending', product_id: line.product_id, variant_id: line.variant_id,
          serial_id: line.serial_id, batch_id: batch.id, quantity,
          unit_price: line.unit_price, discount: lineDiscount, tax: lineTax,
          line_total: lineTotal, cost, profit: roundMoney(lineTotal - cost),
          activity_data: line.activity_data,
        };
        items.push(item);
        subtotal = roundMoney(subtotal + lineSubtotal);
        discount = roundMoney(discount + lineDiscount);
        tax = roundMoney(tax + lineTax);
        profit = roundMoney(profit + item.profit);
        totalCost = roundMoney(totalCost + cost);
        await db.stock_movements.add({
          id: uid('move'), pharmacy_id, branch_id:settings?.branch_id, created_at: timestamp, updated_at: timestamp,
          product_id: line.product_id, batch_id: batch.id, type: 'sale',
          quantity: -quantity, before_qty: before, after_qty: after,
          reference_id: invoice_no, user_id,
        });
        remainingQuantity -= quantity;
      }
      if (remainingQuantity > 0) {
        throw new Error(`المخزون المتاح غير كافٍ للصنف المحدد. أضف كمية شراء أو تشغيلة صالحة أولاً.`);
      }
    }

    const total = roundMoney(subtotal - discount + tax);
    if (method !== 'Credit' && paid < total) {
      throw new Error('المبلغ المدفوع أقل من إجمالي الفاتورة. اختر البيع الآجل إذا كان للعميل رصيد متبقٍ.');
    }
    const appliedPayment = roundMoney(Math.min(paid, total));
    const remaining = roundMoney(Math.max(0, total - appliedPayment));
    sale = {
      id: uid('sale'), pharmacy_id, branch_id:settings?.branch_id, created_at: timestamp, updated_at: timestamp,
      invoice_no, customer_id, subtotal, discount, tax, total, paid,
      remaining, payment_method: method, cashier_id: user_id, profit,
      status: 'COMPLETED',
    };
    await db.sales.add(sale);
    for (const item of items) {
      item.sale_id = sale.id;
      await db.sale_items.add(item);
      if (item.serial_id) {
        await db.serial_numbers.update(item.serial_id, {
          status: 'sold', sale_id: sale.id, customer_id, updated_at: timestamp,
        });
        const product = await db.products.get(item.product_id);
        const months = warrantyMonths(product?.attributes?.warranty_months ?? product?.attributes?.warranty);
        if (months && customer_id) {
          const end = new Date(timestamp);
          end.setMonth(end.getMonth() + months);
          const warranty: Warranty = {
            id: uid('warranty'), pharmacy_id, product_id: item.product_id,
            serial_id: item.serial_id, customer_id, sale_id: sale.id,
            start_date: timestamp.slice(0, 10), end_date: end.toISOString().slice(0, 10),
            status: 'ACTIVE', created_at: timestamp, updated_at: timestamp,
          };
          await db.warranties.add(warranty);
        }
      }
    }
    if (customer_id && remaining > 0) {
      const customer = await db.customers.get(customer_id);
      if (customer) await db.customers.update(customer_id, {
        balance: roundMoney(customer.balance + remaining), updated_at: timestamp,
      });
    }

    const revenue = roundMoney(subtotal - discount);
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'sale', reference_id: sale.id,
      description: `فاتورة بيع ${sale.invoice_no}`,
      lines: [
        { accountCode: accountForPayment(method), debit: appliedPayment, credit: 0 },
        { accountCode: '1200', debit: remaining, credit: 0 },
        { accountCode: '4000', debit: 0, credit: revenue },
        { accountCode: '2100', debit: 0, credit: tax },
        { accountCode: '5000', debit: totalCost, credit: 0 },
        { accountCode: '1300', debit: 0, credit: totalCost },
      ],
    });
    if (method === 'Cash' && appliedPayment > 0) {
      const shift = await db.cash_shifts.where('user_id').equals(user_id).filter((row) => row.status === 'OPEN').first();
      if (shift) {
        const movement: CashMovement = {
          id: uid('cash'), pharmacy_id, shift_id: shift.id, type: 'sale',
          amount: appliedPayment, reference_id: sale.id, created_at: timestamp,
        };
        await db.cash_movements.add(movement);
        await db.cash_shifts.update(shift.id, {
          expected_cash: roundMoney(shift.expected_cash + appliedPayment), updated_at: timestamp,
        });
      }
    }
    await audit(user_id, 'sale', 'sales', sale.id, sale);
    await enqueueOperation('sale', {
      invoice_number: sale.invoice_no, customer_id: customer_id || null,
      branch_id:sale.branch_id||null,
      payment_method: method.toLowerCase(), paid: appliedPayment,
      subtotal: sale.subtotal, discount: sale.discount, tax: sale.tax, total: sale.total,
      items: items.map((item) => ({
        product_id: item.product_id, variant_id: item.variant_id || null,
        serial_id: item.serial_id || null, batch_id: item.batch_id,
        quantity: item.quantity, unit_price: item.unit_price,
        discount: item.discount, tax: item.tax, activity_data: item.activity_data || {},
      })),
    }, `sale:${sale.invoice_no}`);
  });
  return sale;
}

export async function cancelSale(user_id: string, sale_id: string, reason: string) {
  const sale = await db.sales.get(sale_id);
  if (!sale || sale.status !== 'COMPLETED') throw new Error('الفاتورة غير قابلة للإلغاء');
  if (!reason.trim()) throw new Error('سبب الإلغاء مطلوب.');
  await ensureChartOfAccounts();
  await (db.transaction as any)('rw', [
    db.sales, db.sale_items, db.batches, db.serial_numbers, db.warranties,
    db.stock_movements, db.customers, db.audit_logs, db.sync_operations,
    db.accounts, db.journal_entries, db.journal_lines, db.cash_shifts,
    db.cash_movements,
  ], async () => {
    const timestamp = now();
    const items = await db.sale_items.where('sale_id').equals(sale_id).toArray();
    for (const item of items) {
      const batch = await db.batches.get(item.batch_id);
      if (batch) {
        await db.batches.update(batch.id, { quantity: batch.quantity + item.quantity, updated_at: timestamp });
        await db.stock_movements.add({
          id: uid('move'), pharmacy_id: sale.pharmacy_id, created_at: timestamp,
          updated_at: timestamp, product_id: item.product_id, batch_id: batch.id,
          type: 'return', quantity: item.quantity, before_qty: batch.quantity,
          after_qty: batch.quantity + item.quantity, reference_id: sale_id,
          user_id, notes: reason.trim(),
        });
      }
      if (item.serial_id) {
        await db.serial_numbers.update(item.serial_id, {
          status: 'in_stock', sale_id: undefined, customer_id: undefined, updated_at: timestamp,
        });
        const warranty = await db.warranties.where('serial_id').equals(item.serial_id).first();
        if (warranty) await db.warranties.update(warranty.id, { status: 'VOID', updated_at: timestamp });
      }
    }
    await db.sales.update(sale_id, { status: 'CANCELLED', updated_at: timestamp });
    if (sale.customer_id && sale.remaining > 0) {
      const customer = await db.customers.get(sale.customer_id);
      if (customer) await db.customers.update(customer.id, {
        balance: Math.max(0, roundMoney(customer.balance - sale.remaining)), updated_at: timestamp,
      });
    }
    const appliedPayment = roundMoney(Math.min(sale.paid, sale.total));
    const revenue = roundMoney(sale.subtotal - sale.discount);
    const itemsCost = roundMoney(items.reduce((sum, item) => sum + item.cost, 0));
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'sale_cancel', reference_id: sale.id,
      description: `إلغاء فاتورة بيع ${sale.invoice_no}`,
      lines: [
        { accountCode: accountForPayment(sale.payment_method), debit: 0, credit: appliedPayment },
        { accountCode: '1200', debit: 0, credit: sale.remaining },
        { accountCode: '4000', debit: revenue, credit: 0 },
        { accountCode: '2100', debit: sale.tax, credit: 0 },
        { accountCode: '5000', debit: 0, credit: itemsCost },
        { accountCode: '1300', debit: itemsCost, credit: 0 },
      ],
    });
    if (sale.payment_method === 'Cash' && appliedPayment > 0) {
      const shift = await db.cash_shifts.where('user_id').equals(user_id).filter((row) => row.status === 'OPEN').first();
      if (shift) {
        await db.cash_movements.add({
          id: uid('cash'), pharmacy_id: sale.pharmacy_id, shift_id: shift.id,
          type: 'return', amount: appliedPayment, reference_id: sale.id,
          notes: reason.trim(), created_at: timestamp,
        });
        await db.cash_shifts.update(shift.id, {
          expected_cash: roundMoney(shift.expected_cash - appliedPayment), updated_at: timestamp,
        });
      }
    }
    await audit(user_id, 'sale_cancellation', 'sales', sale_id, { reason: reason.trim(), sale });
    await enqueueOperation('sale_cancel', { sale_id, reason: reason.trim() }, `sale-cancel:${sale_id}`);
  });
}