export default function CompanyPromo() {
  return (
    <div className="company-promo" aria-label="بيانات الشركة">
      <strong>النجاح لإدارة المحال التجارية</strong>
      <span>الموقع: تمبول</span>
      <a href="tel:0121164581">0121164581</a>
      <a href="tel:0969696787">0969696787</a>
    </div>
  );
}