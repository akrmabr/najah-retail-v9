import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import type { PaymentMethod, User } from '../types/models';
import { money } from '../utils/ids';
import { recordExpense } from '../services/expenses';

export default function SimpleTablePage({
  table, title, creatable, user,
}: { table: string; title: string; creatable?: boolean; user?: User }) {
  const rows = useLiveQuery(() => (db as any)[table].toArray(), [table]) || [];
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('أخرى');
  const [description, setDescription] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [message, setMessage] = useState('');

  async function add() {
    if (table !== 'expenses' || !user) return;
    try {
      await recordExpense(user.id, Number(amount), category, description, method);
      setAmount(''); setDescription('');
      setMessage('تمت إضافة المصروف وترحيله للصندوق والمحاسبة.');
    } catch (error: any) {
      setMessage(error?.message || 'تعذر حفظ المصروف.');
    }
  }

  return (
    <section>
      <h1>{title}</h1>
      {creatable && <div className="card formgrid">
        <input type="number" min="0.01" step="0.01" value={amount}
          onChange={(event) => { setAmount(event.target.value); setMessage(''); }} placeholder="المبلغ" />
        <input value={category} onChange={(event) => setCategory(event.target.value)} placeholder="الفئة" />
        <input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="الوصف" />
        <select value={method} onChange={(event) => setMethod(event.target.value)}>
          <option value="Cash">نقدي</option><option value="Card">بطاقة</option><option value="Bank">تحويل بنكي</option>
        </select>
        <button onClick={add}>إضافة مصروف</button>
        {message && <div className="alert">{message}</div>}
      </div>}
      <div className="card">
        <table><thead><tr><th>التاريخ</th><th>الفئة</th><th>الوصف</th><th>المبلغ</th></tr></thead>
          <tbody>{rows.map((row: any) => <tr key={row.id}>
            <td>{row.date || row.created_at}</td><td>{row.category || ''}</td>
            <td>{row.description || ''}</td><td>{money(row.amount)}</td>
          </tr>)}</tbody></table>
        {!rows.length && <p className="empty">لا توجد بيانات.</p>}
      </div>
    </section>
  );
}