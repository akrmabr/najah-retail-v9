import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles/app.css';

const OWNER_EMAIL = 'akrmabrahymk@gmail.com';
const ACTIVITY_IDS = 'pharmacy, auto_parts, grocery_supermarket, homeware, furniture_decor, clothing, perfume_cosmetics, shoes, bookstore, mobile, building_materials, electronics, electrical';

function Owner() {
  const endpoint = String(
    import.meta.env.VITE_LICENSE_SERVER ||
    localStorage.getItem('alshifaa_license_endpoint') ||
    '',
  ).trim().replace(/\/+$/, '');
  const anonKey = String(import.meta.env.VITE_SUPABASE_ANON_KEY || '');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState('');
  const [data, setData] = useState<any>();
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function call(action: string, payload: Record<string, unknown> = {}, accessToken = token) {
    if (!endpoint) throw new Error('رابط مشروع Supabase غير مضبوط في إعداد النشر.');
    if (!accessToken) throw new Error('سجّل الدخول أولاً.');

    let response: Response;
    try {
      response = await fetch(`${endpoint}/functions/v1/${action}`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(payload),
      });
    } catch {
      throw new Error('تعذر الاتصال بمشروع Supabase.');
    }

    const result = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(result?.error || 'فشل تنفيذ العملية.');
    }
    return result;
  }

  async function signIn(event: React.FormEvent) {
    event.preventDefault();
    setMessage('');
    setBusy(true);
    try {
      if (!endpoint || !anonKey) {
        throw new Error('إعدادات Supabase غير موجودة في إعدادات النشر.');
      }

      const response = await fetch(`${endpoint}/auth/v1/token?grant_type=password`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          apikey: anonKey,
        },
        body: JSON.stringify({ email: OWNER_EMAIL, password }),
      });
      const result = await response.json().catch(() => null);

      if (!response.ok || !result?.access_token) {
        throw new Error(result?.msg || result?.error_description || 'تعذر تسجيل الدخول. تحقق من كلمة المرور وحساب Supabase.');
      }

      const accessToken = String(result.access_token);
      setToken(accessToken);
      setPassword('');
      const dashboard = await call('owner-dashboard', {}, accessToken);
      setData(dashboard);
      setMessage('تم تسجيل الدخول وتحميل لوحة التراخيص.');
    } catch (error: any) {
      setToken('');
      setData(undefined);
      setMessage(error?.message || 'تعذر تسجيل الدخول.');
    } finally {
      setBusy(false);
    }
  }

  async function load() {
    setMessage('');
    setBusy(true);
    try {
      setData(await call('owner-dashboard'));
      setMessage('تم تحديث بيانات لوحة التراخيص.');
    } catch (error: any) {
      setMessage(error?.message || 'تعذر تحميل البيانات.');
    } finally {
      setBusy(false);
    }
  }

  async function createLicense() {
    const storeName = prompt('اسم المتجر')?.trim() || '';
    const ownerEmail = prompt('بريد مالك المتجر')?.trim() || '';
    const licenseType = (prompt('نوع الترخيص: ANNUAL أو LIFETIME', 'ANNUAL') || '').trim().toUpperCase();
    const businessTypeId = (prompt(`معرّف النشاط من القائمة:\n${ACTIVITY_IDS}`, 'pharmacy') || '').trim();
    const days = licenseType === 'ANNUAL' ? Number(prompt('مدة الترخيص بالأيام', '365') || 365) : undefined;

    if (!storeName || !ownerEmail || !businessTypeId || !['ANNUAL', 'LIFETIME'].includes(licenseType)) {
      setMessage('ألغيت العملية أو لم تكتمل البيانات المطلوبة.');
      return;
    }

    setMessage('');
    setBusy(true);
    try {
      const result = await call('owner-control', {
        operation: 'create_license',
        store_name: storeName,
        owner_email: ownerEmail,
        owner_name: storeName,
        business_type_id: businessTypeId,
        license_type: licenseType,
        days,
      });
      setMessage(JSON.stringify(result, null, 2));
      setData(await call('owner-dashboard'));
    } catch (error: any) {
      setMessage(error?.message || 'تعذر إصدار الترخيص.');
    } finally {
      setBusy(false);
    }
  }

  async function runLicenseAction(operation: 'suspend' | 'revoke' | 'extend' | 'unbind_device') {
    const licenseKey = prompt('أدخل مفتاح الترخيص')?.trim() || '';
    if (!licenseKey) return;

    setMessage('');
    setBusy(true);
    try {
      const result = await call('owner-control', {
        operation,
        license_key: licenseKey,
      });
      setMessage(JSON.stringify(result, null, 2));
      setData(await call('owner-dashboard'));
    } catch (error: any) {
      setMessage(error?.message || 'تعذر تنفيذ الإجراء.');
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    setToken('');
    setData(undefined);
    setPassword('');
    setMessage('تم تسجيل الخروج.');
  }

  return (
    <main>
      <h1>لوحة إدارة تراخيص النجاح</h1>

      {!token ? (
        <form className="card formgrid" onSubmit={signIn}>
          <p>أدخل كلمة مرور حساب مسؤول المنصة للمتابعة.</p>
          <label className="field">
            <span>كلمة المرور</span>
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
            />
          </label>
          <button className="primary" disabled={busy}>
            {busy ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
          </button>
        </form>
      ) : (
        <>
          <div className="card formgrid">
            <button onClick={load} disabled={busy}>تحديث البيانات</button>
            <button onClick={createLicense} disabled={busy}>إصدار ترخيص</button>
            <button onClick={() => runLicenseAction('suspend')} disabled={busy}>إيقاف الترخيص</button>
            <button onClick={() => runLicenseAction('revoke')} disabled={busy}>إلغاء الترخيص</button>
            <button onClick={() => runLicenseAction('extend')} disabled={busy}>تمديد الترخيص</button>
            <button onClick={() => runLicenseAction('unbind_device')} disabled={busy}>فك ربط الأجهزة</button>
            <button className="ghost" onClick={signOut}>تسجيل الخروج</button>
          </div>

          {data && (
            <>
              <div className="grid cards">
                {Object.entries(data.stats || {}).map(([key, value]) => (
                  <div className="card stat" key={key}>
                    <span>{key}</span>
                    <b>{String(value)}</b>
                  </div>
                ))}
              </div>

              <div className="card">
                <h3>التراخيص القريبة من الانتهاء</h3>
                <table>
                  <tbody>
                    {(data.expiring || []).map((license: any) => (
                      <tr key={license.id}>
                        <td>{license.store_name}</td>
                        <td>{license.business_type_id}</td>
                        <td>{license.expires_at}</td>
                        <td>{license.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {!data.expiring?.length && <p className="empty">لا توجد تراخيص قريبة من الانتهاء.</p>}
              </div>

              <div className="card">
                <h3>طلبات التفعيل</h3>
                <table>
                  <tbody>
                    {(data.requests || []).map((request: any) => (
                      <tr key={request.id}>
                        <td>{request.status}</td>
                        <td>{request.created_at}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {!data.requests?.length && <p className="empty">لا توجد طلبات تفعيل.</p>}
              </div>
            </>
          )}
        </>
      )}

      {message && <pre className="card">{message}</pre>}
    </main>
  );
}

createRoot(document.getElementById('owner-root')!).render(
  <React.StrictMode>
    <Owner />
  </React.StrictMode>,
);