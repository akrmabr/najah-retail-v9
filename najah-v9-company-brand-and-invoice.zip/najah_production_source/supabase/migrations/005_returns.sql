create table if not exists public.returns (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete restrict,
  branch_id uuid references public.branches(id) on delete set null, sale_id uuid references public.sales(id) on delete set null, purchase_id uuid references public.purchases(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null, supplier_id uuid references public.suppliers(id) on delete set null,
  return_number text not null, return_type text not null check (return_type in ('sale_return','purchase_return')), status text not null default 'completed' check (status in ('draft','completed','cancelled')),
  total numeric(14,3) not null default 0, refund_amount numeric(14,3) not null default 0, reason text, created_by uuid references auth.users(id), created_at timestamptz not null default now(), unique (business_id,return_number)
);
create table if not exists public.return_items (
  id uuid primary key default gen_random_uuid(), return_id uuid not null references public.returns(id) on delete cascade, business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid not null references public.products(id), variant_id uuid references public.product_variants(id), batch_id uuid references public.product_batches(id), serial_id uuid references public.product_serial_numbers(id), quantity numeric(14,3) not null check(quantity>0), unit_price numeric(14,3) not null check(unit_price>=0), total numeric(14,3) not null default 0
);
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references public.businesses(id) on delete cascade, branch_id uuid references public.branches(id) on delete set null,
  document_type text not null check(document_type in ('sale','purchase','sale_return','purchase_return','payment','customer_statement','supplier_statement','report','barcode_label')),
  source_id uuid, invoice_number text, template jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create table if not exists public.business_settings (
  business_id uuid primary key references public.businesses(id) on delete cascade, invoice_footer text, date_format text not null default 'YYYY-MM-DD', invoice_numbering jsonb not null default '{}'::jsonb,
  payment_methods jsonb not null default '["cash","card","bank_transfer","credit"]'::jsonb, inventory_rules jsonb not null default '{}'::jsonb, appearance jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now()
);

create index if not exists idx_returns_business_created on public.returns(business_id,created_at desc);
create index if not exists idx_return_items_business_product on public.return_items(business_id,product_id);
create index if not exists idx_invoices_business_type on public.invoices(business_id,document_type,created_at desc);

-- Add the remaining tenant policies.
do $$
declare t text;
begin
  foreach t in array array['returns','return_items','invoices','business_settings'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists tenant_select on public.%I', t);
    execute format('drop policy if exists tenant_insert on public.%I', t);
    execute format('drop policy if exists tenant_update on public.%I', t);
    execute format('drop policy if exists tenant_delete on public.%I', t);
    if t = 'business_settings' then
      execute 'create policy tenant_select on public.business_settings for select using (business_id = public.app_business_id())';
      execute 'create policy tenant_insert on public.business_settings for insert with check (business_id = public.app_business_id())';
      execute 'create policy tenant_update on public.business_settings for update using (business_id = public.app_business_id() and public.app_is_admin()) with check (business_id = public.app_business_id() and public.app_is_admin())';
      execute 'create policy tenant_delete on public.business_settings for delete using (business_id = public.app_business_id() and public.app_is_admin())';
    else
      execute format('create policy tenant_select on public.%I for select using (business_id = public.app_business_id())', t);
      execute format('create policy tenant_insert on public.%I for insert with check (business_id = public.app_business_id())', t);
      execute format('create policy tenant_update on public.%I for update using (business_id = public.app_business_id()) with check (business_id = public.app_business_id())', t);
      execute format('create policy tenant_delete on public.%I for delete using (business_id = public.app_business_id() and public.app_is_admin())', t);
    end if;
  end loop;
end $$;

create or replace function public.record_sale_return(
  p_business_id uuid, p_branch_id uuid, p_sale_id uuid, p_customer_id uuid, p_return_number text, p_reason text, p_items jsonb
) returns uuid language plpgsql security invoker set search_path=public as $$
declare v_id uuid:=gen_random_uuid(); v jsonb; v_product uuid; v_variant uuid; v_batch uuid; v_qty numeric; v_price numeric; v_total numeric:=0; v_sold numeric; v_returned numeric;
begin
  if public.app_business_id() is distinct from p_business_id then raise exception 'business_access_denied'; end if;
  if exists(select 1 from public.returns where business_id=p_business_id and return_number=p_return_number) then select id into v_id from public.returns where business_id=p_business_id and return_number=p_return_number; return v_id; end if;
  for v in select value from jsonb_array_elements(p_items) loop
    v_product:=(v->>'product_id')::uuid; v_variant:=nullif(v->>'variant_id','')::uuid; v_batch:=nullif(v->>'batch_id','')::uuid; v_qty:=(v->>'quantity')::numeric; v_price:=(v->>'unit_price')::numeric;
    if v_qty<=0 or v_price<0 then raise exception 'invalid_return_item'; end if;
    select coalesce(sum(quantity),0) into v_sold from public.sale_items where sale_id=p_sale_id and business_id=p_business_id and product_id=v_product and variant_id is not distinct from v_variant and batch_id is not distinct from v_batch;
    select coalesce(sum(quantity),0) into v_returned from public.return_items ri join public.returns r on r.id=ri.return_id where r.sale_id=p_sale_id and ri.business_id=p_business_id and ri.product_id=v_product and ri.variant_id is not distinct from v_variant and ri.batch_id is not distinct from v_batch and r.status='completed';
    if v_sold=0 or v_returned+v_qty>v_sold then raise exception 'return_quantity_exceeds_sale'; end if;
    v_total:=v_total+v_qty*v_price;
  end loop;
  insert into public.returns(id,business_id,branch_id,sale_id,customer_id,return_number,return_type,total,refund_amount,reason,created_by) values(v_id,p_business_id,p_branch_id,p_sale_id,p_customer_id,p_return_number,'sale_return',v_total,v_total,p_reason,auth.uid());
  for v in select value from jsonb_array_elements(p_items) loop
    v_product:=(v->>'product_id')::uuid; v_variant:=nullif(v->>'variant_id','')::uuid; v_batch:=nullif(v->>'batch_id','')::uuid; v_qty:=(v->>'quantity')::numeric; v_price:=(v->>'unit_price')::numeric;
    insert into public.return_items(return_id,business_id,product_id,variant_id,batch_id,quantity,unit_price,total) values(v_id,p_business_id,v_product,v_variant,v_batch,v_qty,v_price,v_qty*v_price);
    insert into public.stock_movements(business_id,branch_id,product_id,variant_id,batch_id,movement_type,quantity_delta,source_type,source_id,created_by) values(p_business_id,p_branch_id,v_product,v_variant,v_batch,'sale_return',v_qty,'return',v_id,auth.uid());
  end loop;
  insert into public.audit_logs(business_id,branch_id,user_id,action,entity_type,entity_id,details) values(p_business_id,p_branch_id,auth.uid(),'sale.returned','return',v_id,jsonb_build_object('return_number',p_return_number,'total',v_total));
  return v_id;
end; $$;

