import { useState } from 'react';
import { validateLicense } from '../services/license';
import { BUSINESS_TYPE_OPTIONS } from '../config/businessTypes';

const DEFAULT_LICENSE_SERVER = String(import.meta.env.VITE_LICENSE_SERVER || '');

export default function Activation({ onActivated }: { onActivated: () => void }) {
  const [licenseKey, setLicenseKey] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [server, setServer] = useState(localStorage.getItem('alshifaa_license_endpoint') || DEFAULT_LICENSE_SERVER);
  const [showServer, setShowServer] = useState(true);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage('');
    setLoading(true);
    try {
      localStorage.setItem('alshifaa_license_endpoint', server);
      if (!businessType) throw new Error('اختر نوع النشاط قبل التفعيل.');
      await validateLicense(server, licenseKey.trim(), businessType);
      setMessage('تم تفعيل الترخيص بنجاح. سيتم الآن إعداد حساب مالك النشاط.');
      setTimeout(onActivated, 600);
    } catch (error: any) {
      setMessage(error?.message || 'تعذر تفعيل الترخيص. تأكد من المفتاح أو الاتصال بالإنترنت.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="onboarding">
      <form onSubmit={submit} className="onboarding-card">
        <img src="brand-logo.png" alt="النجاح لإدارة المحال التجارية" />
        <h1>تفعيل الترخيص</h1>
        <p>أدخل مفتاح الترخيص الذي حصلت عليه من مزود النظام لتشغيل النسخة على هذا الجهاز، ويجب أن يطابق النشاط نوع الترخيص.</p>
        <select value={businessType} onChange={(e) => setBusinessType(e.target.value)} required>
          <option value="">اختر نوع النشاط</option>
          {BUSINESS_TYPE_OPTIONS.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
        </select>
        <input
          value={licenseKey}
          onChange={(e) => setLicenseKey(e.target.value)}
          placeholder="مفتاح الترخيص"
          autoComplete="off"
          required
        />
        {showServer && (
          <input
            value={server}
            onChange={(e) => setServer(e.target.value)}
            placeholder="رابط خادم التراخيص"
            dir="ltr"
            required
          />
        )}
        <button className="primary" disabled={loading}>{loading ? 'جاري التفعيل...' : 'تفعيل النسخة'}</button>
        <button type="button" className="link-button" onClick={() => setShowServer(!showServer)}>
          إعدادات خادم التراخيص
        </button>
        {message && <div className="alert">{message}</div>}
        <div className="login-support">الدعم والمبيعات: <a href="tel:0121164581">0121164581</a> — واتساب: <a href="https://wa.me/249969696787">0969696787</a></div>
      </form>
    </div>
  );
}
