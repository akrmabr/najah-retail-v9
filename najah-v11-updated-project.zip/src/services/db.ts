import Dexie, { Table } from 'dexie';
import type {
  Account, AppNotification, AuditLog, Batch, Branch, Brand, CashMovement, CashShift,
  Category, CrashReport, Customer, Expense, JournalEntry, JournalLine,
  LoyaltyTransaction, Payment, PriceList, Product, ProductVariant, Promotion,
  Purchase, PurchaseItem, Return, Sale, SaleItem, SerialNumber, Settings,
  StockCount, StockCountItem, StockMovement, StockTransfer, StockTransferItem,
  Supplier, SyncOperation, TaxRule, Unit, User, Warranty, WarrantyTicket,
} from '../types/models';
import { migrateLegacyStorageKeys, STORAGE_KEYS } from './storageKeys';

const DATABASE_NAME = 'NAJAH_RETAIL_LOCAL_DB';
const LEGACY_DATABASE_NAME = 'ALSHIFAA_LOCAL_DB';

const stores = {
  categories: 'id,pharmacy_id,name,active',
  brands: 'id,pharmacy_id,name,active',
  units: 'id,pharmacy_id,name,symbol',
  branches: 'id,pharmacy_id,code,active',
  serial_numbers: 'id,pharmacy_id,product_id,variant_id,serial_number,imei,status',
  tax_rules: 'id,pharmacy_id,scope,scope_id,active',
  price_lists: 'id,pharmacy_id,code,active',
  promotions: 'id,pharmacy_id,type,product_id,category,active,starts_at,ends_at',
  cash_shifts: 'id,pharmacy_id,user_id,status,opened_at',
  cash_movements: 'id,pharmacy_id,shift_id,type,created_at',
  accounts: 'id,pharmacy_id,code,type,active',
  journal_entries: 'id,pharmacy_id,reference_type,reference_id,date,posted',
  journal_lines: 'id,pharmacy_id,entry_id,account_id',
  stock_transfers: 'id,pharmacy_id,from_branch_id,to_branch_id,status,created_at',
  stock_transfer_items: 'id,pharmacy_id,transfer_id,product_id,batch_id',
  warranties: 'id,pharmacy_id,product_id,serial_id,customer_id,status,end_date',
  warranty_tickets: 'id,pharmacy_id,status,customer_id,product_id',
  loyalty_transactions: 'id,pharmacy_id,customer_id,type,created_at',
  notifications: 'id,pharmacy_id,type,severity,read,created_at',
  crash_reports: 'id,pharmacy_id,user_id,created_at',
  products: 'id,pharmacy_id,arabic_name,english_name,generic_name,barcode,alternative_barcode,sku,manufacturer,active',
  product_variants: 'id,pharmacy_id,product_id,sku,barcode,active',
  stock_counts: 'id,pharmacy_id,status,created_at',
  stock_count_items: 'id,pharmacy_id,stock_count_id,product_id,batch_id',
  batches: 'id,pharmacy_id,branch_id,product_id,batch_number,expiry_date,quantity',
  customers: 'id,pharmacy_id,name,phone,balance',
  suppliers: 'id,pharmacy_id,name,company,balance',
  sales: 'id,pharmacy_id,branch_id,invoice_no,created_at,customer_id,status',
  sale_items: 'id,pharmacy_id,sale_id,product_id,batch_id',
  purchases: 'id,pharmacy_id,branch_id,invoice_no,date,supplier_id,status',
  purchase_items: 'id,pharmacy_id,purchase_id,product_id,batch_id',
  expenses: 'id,pharmacy_id,date,category',
  payments: 'id,pharmacy_id,party_type,party_id,date',
  returns: 'id,pharmacy_id,type,source_id,product_id',
  stock_movements: 'id,pharmacy_id,product_id,batch_id,type,created_at',
  users: 'id,pharmacy_id,username,email,role,active',
  settings: 'id,pharmacy_id',
  audit_logs: 'id,pharmacy_id,timestamp,action,entity',
  sync_operations: 'id,pharmacy_id,operation_key,status,created_at,updated_at',
};

class NajahRetailDB extends Dexie {
  categories!: Table<Category, string>; brands!: Table<Brand, string>;
  units!: Table<Unit, string>; branches!: Table<Branch, string>;
  serial_numbers!: Table<SerialNumber, string>; tax_rules!: Table<TaxRule, string>;
  price_lists!: Table<PriceList, string>; promotions!: Table<Promotion, string>;
  cash_shifts!: Table<CashShift, string>; cash_movements!: Table<CashMovement, string>;
  accounts!: Table<Account, string>; journal_entries!: Table<JournalEntry, string>;
  journal_lines!: Table<JournalLine, string>; stock_transfers!: Table<StockTransfer, string>;
  stock_transfer_items!: Table<StockTransferItem, string>; warranties!: Table<Warranty, string>;
  warranty_tickets!: Table<WarrantyTicket, string>; loyalty_transactions!: Table<LoyaltyTransaction, string>;
  notifications!: Table<AppNotification, string>; crash_reports!: Table<CrashReport, string>;
  product_variants!: Table<ProductVariant, string>; stock_counts!: Table<StockCount, string>;
  stock_count_items!: Table<StockCountItem, string>; products!: Table<Product, string>;
  batches!: Table<Batch, string>; customers!: Table<Customer, string>;
  suppliers!: Table<Supplier, string>; sales!: Table<Sale, string>;
  sale_items!: Table<SaleItem, string>; purchases!: Table<Purchase, string>;
  purchase_items!: Table<PurchaseItem, string>; expenses!: Table<Expense, string>;
  payments!: Table<Payment, string>; returns!: Table<Return, string>;
  stock_movements!: Table<StockMovement, string>; users!: Table<User, string>;
  settings!: Table<Settings, string>; audit_logs!: Table<AuditLog, string>;
  sync_operations!: Table<SyncOperation, string>;

  constructor() {
    super(DATABASE_NAME);
    this.version(1).stores({ ...stores });
    this.version(2).stores({ ...stores });
    this.version(3).stores({ ...stores });
    this.version(4).stores(stores);
    this.version(5).stores(stores);
    this.version(6).stores(stores);
    this.version(7).stores(stores);
  }
}

export const db = new NajahRetailDB();
export const PHARMACY_ID_KEY = STORAGE_KEYS.pharmacyId;

export function getPharmacyId() {
  let id = localStorage.getItem(PHARMACY_ID_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(PHARMACY_ID_KEY, id);
  }
  return id;
}

async function migrateLegacyDatabase() {
  const marker = 'najah_retail_legacy_db_migrated_v1';
  if (localStorage.getItem(marker) === 'true' ||
      !(await Dexie.exists(LEGACY_DATABASE_NAME)) ||
      await db.settings.count() > 0) return;
  const legacy = new Dexie(LEGACY_DATABASE_NAME);
  try {
    await legacy.open();
    const available = new Set(legacy.tables.map((table) => table.name));
    const names = db.tables.map((table) => table.name).filter((name) => available.has(name));
    const data: Record<string, unknown[]> = {};
    for (const name of names) data[name] = await legacy.table(name).toArray();
    await (db.transaction as any)('rw', names.map((name) => db.table(name)), async () => {
      for (const name of names) {
        if (data[name].length) await db.table(name).bulkPut(data[name]);
      }
    });
    localStorage.setItem(marker, 'true');
  } finally {
    legacy.close();
  }
}

export async function ensureBootstrap() {
  migrateLegacyStorageKeys();
  await migrateLegacyDatabase();
  const pharmacy_id = getPharmacyId();
  if (await db.settings.count() === 0) {
    const timestamp = new Date().toISOString();
    await db.settings.add({
      id: 'settings', pharmacy_id, created_at: timestamp, updated_at: timestamp,
      pharmacy_name: 'اسم المتجر / النشاط', currency: 'SDG', currency_symbol: 'ج.س',
      invoice_footer: 'تم التشغيل بواسطة النجاح لإدارة المحال التجارية — اتصال 0121164581 — واتساب 0969696787',
      default_paper: '80mm', tax_rate: 0, offline_grace_days: 7,
      session_timeout_minutes: 30,
    });
  }
  const currentSettings=await db.settings.get('settings');
  if(await db.users.count()>0&&await db.branches.count()===0){
    const timestamp=new Date().toISOString(),branchId=crypto.randomUUID();
    await (db.transaction as any)('rw',[db.branches,db.settings,db.batches],async()=>{
      await db.branches.add({id:branchId,pharmacy_id,name:'الفرع الرئيسي',code:'MAIN',active:true,created_at:timestamp,updated_at:timestamp});
      await db.settings.update('settings',{branch_id:branchId,updated_at:timestamp});
      const legacyBatches=await db.batches.toArray();
      for(const batch of legacyBatches)if(!batch.branch_id)await db.batches.update(batch.id,{branch_id:branchId,updated_at:timestamp});
    });
  }else if(!currentSettings?.branch_id){
    const first=await db.branches.filter((branch)=>branch.active).first()||await db.branches.toCollection().first();
    if(first)await db.settings.update('settings',{branch_id:first.id,updated_at:new Date().toISOString()});
  }
  return pharmacy_id;
}