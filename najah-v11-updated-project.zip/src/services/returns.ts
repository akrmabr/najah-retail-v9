import { db, getPharmacyId } from './db';
import type { CashMovement, Return as ReturnRow } from '../types/models';
import { now, uid } from '../utils/ids';
import { audit } from './audit';
import { enqueueOperation } from './sync';
import { ensureChartOfAccounts, postJournalInCurrentTransaction } from './accounting';
import { roundMoney } from '../domain/calculations';

export type ReturnLine = { sale_item_id: string; quantity: number };

async function shiftMovement(
  userId: string, type: CashMovement['type'], amount: number,
  referenceId: string, timestamp: string,
) {
  if (amount <= 0) return;
  const shift = await db.cash_shifts.where('user_id').equals(userId).filter((row) => row.status === 'OPEN').first();
  if (!shift) return;
  await db.cash_movements.add({
    id: uid('cash'), pharmacy_id: getPharmacyId(), shift_id: shift.id,
    type, amount, reference_id: referenceId, created_at: timestamp,
  });
  const sign = type === 'return' ? -1 : 1;
  await db.cash_shifts.update(shift.id, {
    expected_cash: roundMoney(shift.expected_cash + sign * amount), updated_at: timestamp,
  });
}

export async function returnSale(user_id: string, sale_id: string, reason: string) {
  const items = await db.sale_items.where('sale_id').equals(sale_id).toArray();
  if (!items.length) throw new Error('لا توجد أصناف في الفاتورة');
  return returnSaleItems(user_id, sale_id,
    items.map((item) => ({ sale_item_id: item.id, quantity: item.quantity })), reason);
}

export async function returnSaleItems(
  user_id: string, sale_id: string, lines: ReturnLine[], reason: string,
) {
  const sale = await db.sales.get(sale_id);
  if (!sale || !['COMPLETED', 'PARTIAL_RETURN'].includes(sale.status)) {
    throw new Error('الفاتورة غير قابلة للترجيع');
  }
  if (!lines.length || !reason.trim()) throw new Error('أكمل بيانات المرتجع.');
  await ensureChartOfAccounts();
  const saleItems = await db.sale_items.where('sale_id').equals(sale_id).toArray();
  const pharmacy_id = getPharmacyId(), timestamp = now();
  let totalReturned = 0, taxReturned = 0, costReturned = 0;
  const created: ReturnRow[] = [];
  await (db.transaction as any)('rw', [
    db.sales, db.sale_items, db.batches, db.serial_numbers, db.warranties,
    db.returns, db.stock_movements, db.customers, db.audit_logs,
    db.sync_operations, db.accounts, db.journal_entries, db.journal_lines,
    db.cash_shifts, db.cash_movements,
  ], async () => {
    for (const line of lines) {
      const item = saleItems.find((candidate) => candidate.id === line.sale_item_id);
      if (!item) throw new Error('صنف المرتجع غير موجود في الفاتورة.');
      if (!Number.isFinite(line.quantity) || line.quantity <= 0) throw new Error('كمية المرتجع غير صالحة.');
      const returnedBefore = (await db.returns.where('source_id').equals(sale_id).toArray())
        .filter((row) => row.product_id === item.product_id && row.batch_id === item.batch_id)
        .reduce((sum, row) => sum + row.quantity, 0);
      if (returnedBefore + line.quantity > item.quantity) {
        throw new Error('لا يمكن ترجيع كمية أكبر من الكمية المباعة.');
      }
      if (item.serial_id && line.quantity !== item.quantity) {
        throw new Error('الجهاز المرتبط برقم تسلسلي يجب إرجاعه كوحدة كاملة.');
      }
      const batch = await db.batches.get(item.batch_id);
      if (!batch) throw new Error('لم يتم العثور على دفعة الصنف.');
      const before = batch.quantity, after = before + line.quantity;
      await db.batches.update(batch.id, { quantity: after, updated_at: timestamp });
      const ratio = line.quantity / item.quantity;
      const amount = roundMoney(item.line_total * ratio);
      const returnedTax = roundMoney(item.tax * ratio);
      const returnedCost = roundMoney(item.cost * ratio);
      totalReturned = roundMoney(totalReturned + amount);
      taxReturned = roundMoney(taxReturned + returnedTax);
      costReturned = roundMoney(costReturned + returnedCost);
      const row: ReturnRow = {
        id: uid('return'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
        type: 'SALE_RETURN', source_id: sale_id, product_id: item.product_id,
        batch_id: item.batch_id, quantity: line.quantity, amount,
        reason: reason.trim(), status: 'COMPLETED',
      };
      created.push(row);
      await db.returns.add(row);
      await db.stock_movements.add({
        id: uid('move'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
        product_id: item.product_id, batch_id: item.batch_id, type: 'return',
        quantity: line.quantity, before_qty: before, after_qty: after,
        reference_id: sale_id, user_id, notes: reason.trim(),
      });
      if (item.serial_id) {
        await db.serial_numbers.update(item.serial_id, {
          status: 'in_stock', sale_id: undefined, customer_id: undefined, updated_at: timestamp,
        });
        const warranty = await db.warranties.where('serial_id').equals(item.serial_id).first();
        if (warranty) await db.warranties.update(warranty.id, { status: 'VOID', updated_at: timestamp });
      }
    }
    const allReturned = (await db.returns.where('source_id').equals(sale_id).toArray())
      .reduce((sum, row) => sum + row.amount, 0);
    await db.sales.update(sale_id, {
      status: allReturned >= sale.total ? 'RETURNED' : 'PARTIAL_RETURN', updated_at: timestamp,
    });
    const receivableReduction = Math.min(sale.remaining, totalReturned);
    const cashRefund = roundMoney(totalReturned - receivableReduction);
    if (sale.customer_id && receivableReduction > 0) {
      const customer = await db.customers.get(sale.customer_id);
      if (customer) await db.customers.update(customer.id, {
        balance: Math.max(0, roundMoney(customer.balance - receivableReduction)), updated_at: timestamp,
      });
    }
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'sale_return', reference_id: created[0]?.id || sale_id,
      description: `مرتجع فاتورة ${sale.invoice_no}`,
      lines: [
        { accountCode: '4100', debit: roundMoney(totalReturned - taxReturned), credit: 0 },
        { accountCode: '2100', debit: taxReturned, credit: 0 },
        { accountCode: '1200', debit: 0, credit: receivableReduction },
        { accountCode: sale.payment_method === 'Cash' ? '1000' : '1100', debit: 0, credit: cashRefund },
        { accountCode: '1300', debit: costReturned, credit: 0 },
        { accountCode: '5000', debit: 0, credit: costReturned },
      ],
    });
    if (sale.payment_method === 'Cash') await shiftMovement(user_id, 'return', cashRefund, sale_id, timestamp);
    await audit(user_id, 'sale_return', 'returns', sale_id, {
      reason, sale_id, item_count: created.length, total: totalReturned,
    });
    await enqueueOperation('sale_return', {
      sale_id, customer_id: sale.customer_id || null, return_number: created[0]?.id,
      reason, items: created.map((row) => {
        const item = saleItems.find((candidate) =>
          candidate.product_id === row.product_id && candidate.batch_id === row.batch_id);
        return {
          product_id: row.product_id, variant_id: item?.variant_id || null,
          batch_id: row.batch_id || null, serial_id: item?.serial_id || null,
          quantity: row.quantity, unit_price: row.amount / Math.max(1, row.quantity),
        };
      }),
    }, `return:${created.map((row) => row.id).join('-')}`);
  });
  return created;
}

export type PurchaseReturnLine = { purchase_item_id: string; quantity: number };

export async function returnPurchaseItems(
  user_id: string, purchase_id: string, lines: PurchaseReturnLine[], reason: string,
) {
  const purchase = await db.purchases.get(purchase_id);
  if (!purchase || !['POSTED', 'PARTIAL_RETURN'].includes(purchase.status)) {
    throw new Error('فاتورة الشراء غير قابلة للمرتجع.');
  }
  if (!lines.length || !reason.trim()) throw new Error('أكمل بيانات المرتجع.');
  await ensureChartOfAccounts();
  const items = await db.purchase_items.where('purchase_id').equals(purchase_id).toArray();
  const pharmacy_id = getPharmacyId(), timestamp = now();
  const created: ReturnRow[] = [];
  let total = 0, taxReturned = 0;
  await (db.transaction as any)('rw', [
    db.purchases, db.purchase_items, db.batches, db.serial_numbers,
    db.returns, db.stock_movements, db.suppliers, db.audit_logs,
    db.sync_operations, db.accounts, db.journal_entries, db.journal_lines,
    db.cash_shifts, db.cash_movements,
  ], async () => {
    for (const line of lines) {
      const item = items.find((candidate) => candidate.id === line.purchase_item_id);
      if (!item || !Number.isFinite(line.quantity) || line.quantity <= 0) {
        throw new Error('صنف أو كمية المرتجع غير صالحة.');
      }
      const returned = (await db.returns.where('source_id').equals(purchase_id).toArray())
        .filter((row) => row.type === 'PURCHASE_RETURN' && row.product_id === item.product_id && row.batch_id === item.batch_id)
        .reduce((sum, row) => sum + row.quantity, 0);
      if (returned + line.quantity > item.quantity) throw new Error('لا يمكن ترجيع كمية أكبر من المستلمة.');
      const batch = await db.batches.get(item.batch_id);
      if (!batch || batch.quantity < line.quantity) throw new Error('الكمية الحالية في المخزون أقل من كمية المرتجع.');
      const serialRows = await db.serial_numbers.where('product_id').equals(item.product_id)
        .filter((serial) => serial.purchase_id === purchase_id && serial.batch_id === item.batch_id && serial.status === 'in_stock').toArray();
      if (serialRows.length && serialRows.length < line.quantity) {
        throw new Error('بعض الأجهزة التسلسلية في هذه الدفعة تم بيعها ولا يمكن إرجاعها للمورد.');
      }
      const before = batch.quantity, after = before - line.quantity;
      const ratio = line.quantity / item.quantity;
      const amount = roundMoney((item.line_total || item.quantity * item.purchase_price) * ratio);
      const lineTax = roundMoney(Number(item.tax || 0) * ratio);
      await db.batches.update(batch.id, { quantity: after, updated_at: timestamp });
      if (serialRows.length) await db.serial_numbers.bulkDelete(serialRows.slice(0, line.quantity).map((serial) => serial.id));
      const row: ReturnRow = {
        id: uid('return'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
        type: 'PURCHASE_RETURN', source_id: purchase_id, product_id: item.product_id,
        batch_id: item.batch_id, quantity: line.quantity, amount,
        reason: reason.trim(), status: 'COMPLETED',
      };
      created.push(row); total = roundMoney(total + amount); taxReturned = roundMoney(taxReturned + lineTax);
      await db.returns.add(row);
      await db.stock_movements.add({
        id: uid('move'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
        product_id: item.product_id, batch_id: item.batch_id, type: 'return',
        quantity: -line.quantity, before_qty: before, after_qty: after,
        reference_id: purchase_id, user_id, notes: `مرتجع شراء — ${reason.trim()}`,
      });
    }
    const supplier = purchase.supplier_id ? await db.suppliers.get(purchase.supplier_id) : undefined;
    const payableReduction = Math.min(supplier?.balance || 0, total);
    const cashRefund = roundMoney(total - payableReduction);
    if (supplier && payableReduction > 0) {
      await db.suppliers.update(supplier.id, {
        balance: roundMoney(supplier.balance - payableReduction), updated_at: timestamp,
      });
    }
    await db.purchases.update(purchase_id, { status: 'PARTIAL_RETURN', updated_at: timestamp });
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'purchase_return', reference_id: created[0]?.id || purchase_id,
      description: `مرتجع شراء ${purchase.invoice_no}`,
      lines: [
        { accountCode: '2000', debit: payableReduction, credit: 0 },
        { accountCode: '1000', debit: cashRefund, credit: 0 },
        { accountCode: '1300', debit: 0, credit: roundMoney(total - taxReturned) },
        { accountCode: '1250', debit: 0, credit: taxReturned },
      ],
    });
    if (cashRefund > 0) await shiftMovement(user_id, 'cash_in', cashRefund, purchase_id, timestamp);
    await audit(user_id, 'purchase_return', 'returns', purchase_id, {
      reason, total, item_count: created.length,
    });
    await enqueueOperation('purchase_return', {
      purchase_id, supplier_id: purchase.supplier_id || null,
      return_number: created[0]?.id, reason,
      items: created.map((row) => {
        const item = items.find((candidate) =>
          candidate.product_id === row.product_id && candidate.batch_id === row.batch_id);
        return {
          product_id: row.product_id, variant_id: item?.variant_id || null,
          batch_id: row.batch_id || null, quantity: row.quantity,
          unit_price: row.amount / Math.max(1, row.quantity),
        };
      }),
    }, `purchase-return:${created.map((row) => row.id).join('-')}`);
  });
  return created;
}