import { db, getPharmacyId } from './db';
import type { Account, JournalEntry, JournalLine, User } from '../types/models';
import { now, uid } from '../utils/ids';
import { assertBalanced, roundMoney } from '../domain/calculations';
import { audit } from './audit';

const defaults = [
  ['1000', 'الصندوق', 'ASSET'],
  ['1100', 'البنك والبطاقات', 'ASSET'],
  ['1200', 'العملاء', 'ASSET'],
  ['1250', 'ضريبة مدخلات مستردة', 'ASSET'],
  ['1300', 'المخزون', 'ASSET'],
  ['2000', 'الموردون', 'LIABILITY'],
  ['2100', 'ضريبة مبيعات مستحقة', 'LIABILITY'],
  ['3000', 'رأس المال', 'EQUITY'],
  ['4000', 'إيرادات المبيعات', 'REVENUE'],
  ['4100', 'مردودات المبيعات', 'REVENUE'],
  ['5000', 'تكلفة البضاعة المباعة', 'COGS'],
  ['6000', 'المصروفات التشغيلية', 'EXPENSE'],
] as const;

export async function ensureChartOfAccounts() {
  const pharmacy_id = getPharmacyId();
  const existing = new Set((await db.accounts.toArray()).map((account) => account.code));
  const timestamp = now();
  const missing = defaults.filter(([code]) => !existing.has(code));
  if (missing.length) {
    await db.accounts.bulkAdd(missing.map(([code, name, type]) => ({
      id: uid('account'), pharmacy_id, code, name, type, active: true,
      created_at: timestamp, updated_at: timestamp,
    } as Account)));
  }
}

export type JournalInput = {
  reference_type: string;
  reference_id: string;
  description: string;
  date?: string;
  lines: { accountCode: string; debit: number; credit: number }[];
};

/** Must run inside a transaction containing accounts, journals and audit_logs. */
export async function postJournalInCurrentTransaction(userId: string, input: JournalInput) {
  const clean = input.lines
    .map((line) => ({ ...line, debit: roundMoney(line.debit), credit: roundMoney(line.credit) }))
    .filter((line) => line.debit !== 0 || line.credit !== 0);
  assertBalanced(clean);
  const accounts = await db.accounts.toArray();
  const resolved = clean.map((line) => {
    const account = accounts.find((candidate) => candidate.code === line.accountCode);
    if (!account) throw new Error(`الحساب ${line.accountCode} غير موجود`);
    return { ...line, account };
  });
  const timestamp = now();
  const entry: JournalEntry = {
    id: uid('journal'), pharmacy_id: getPharmacyId(),
    reference_type: input.reference_type, reference_id: input.reference_id,
    description: input.description, date: input.date || timestamp.slice(0, 10),
    posted: true, created_by: userId, created_at: timestamp, updated_at: timestamp,
  };
  await db.journal_entries.add(entry);
  await db.journal_lines.bulkAdd(resolved.map((line) => ({
    id: uid('jline'), pharmacy_id: entry.pharmacy_id, entry_id: entry.id,
    account_id: line.account.id, debit: line.debit, credit: line.credit,
    created_at: timestamp,
  } as JournalLine)));
  await audit(userId, 'journal_posted', 'journal_entries', entry.id, input);
  return entry;
}

export async function postJournal(user: User, input: JournalInput) {
  await ensureChartOfAccounts();
  return db.transaction('rw', db.accounts, db.journal_entries, db.journal_lines, db.audit_logs,
    () => postJournalInCurrentTransaction(user.id, input));
}

export async function trialBalance() {
  await ensureChartOfAccounts();
  const [accounts, lines] = await Promise.all([db.accounts.toArray(), db.journal_lines.toArray()]);
  return accounts.map((account) => {
    const related = lines.filter((line) => line.account_id === account.id);
    const debit = related.reduce((sum, line) => sum + line.debit, 0);
    const credit = related.reduce((sum, line) => sum + line.credit, 0);
    return { ...account, debit, credit, balance: debit - credit };
  });
}

export async function generalLedger() {
  await ensureChartOfAccounts();
  const [accounts, entries, lines] = await Promise.all([
    db.accounts.toArray(), db.journal_entries.toArray(), db.journal_lines.toArray(),
  ]);
  return lines.map((line) => {
    const entry = entries.find((candidate) => candidate.id === line.entry_id);
    const account = accounts.find((candidate) => candidate.id === line.account_id);
    return {
      id: line.id, date: entry?.date || line.created_at.slice(0, 10),
      reference_type: entry?.reference_type || '', reference_id: entry?.reference_id || '',
      description: entry?.description || '', account_code: account?.code || '',
      account_name: account?.name || '', debit: line.debit, credit: line.credit,
    };
  }).sort((a, b) => b.date.localeCompare(a.date));
}

export async function financialStatements() {
  const rows = await trialBalance();
  const sum = (type: Account['type']) => roundMoney(rows
    .filter((row) => row.type === type)
    .reduce((total, row) => total + (type === 'LIABILITY' || type === 'EQUITY' || type === 'REVENUE'
      ? row.credit - row.debit : row.debit - row.credit), 0));
  const assets = sum('ASSET'), liabilities = sum('LIABILITY'), equity = sum('EQUITY');
  const revenue = sum('REVENUE'), cogs = sum('COGS'), expenses = sum('EXPENSE');
  const netProfit = roundMoney(revenue - cogs - expenses);
  const movements = await db.cash_movements.toArray();
  const cashIn = roundMoney(movements.filter((row) => ['sale', 'cash_in'].includes(row.type))
    .reduce((total, row) => total + row.amount, 0));
  const cashOut = roundMoney(movements.filter((row) => ['return', 'expense', 'cash_out', 'transfer'].includes(row.type))
    .reduce((total, row) => total + row.amount, 0));
  return {
    income: { revenue, cogs, expenses, netProfit },
    balance: {
      assets, liabilities, equity, retainedEarnings: netProfit,
      liabilitiesAndEquity: roundMoney(liabilities + equity + netProfit),
      difference: roundMoney(assets - liabilities - equity - netProfit),
    },
    cashFlow: { cashIn, cashOut, net: roundMoney(cashIn - cashOut) },
  };
}