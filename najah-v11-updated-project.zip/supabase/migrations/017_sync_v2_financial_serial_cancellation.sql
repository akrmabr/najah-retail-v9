-- V10: preserve local financial totals, tracked units and cancellations during
-- offline sync. Additive migration; the v1 RPC remains available for rollback.

alter table public.sale_items add column if not exists tax numeric(14,3) not null default 0;
alter table public.purchase_items add column if not exists discount numeric(14,3) not null default 0;
alter table public.purchase_items add column if not exists tax numeric(14,3) not null default 0;

create or replace function public.apply_sync_operation_v2(
  p_operation_key text,
  p_operation_type text,
  p_payload jsonb
) returns jsonb
language plpgsql security invoker set search_path=public
as $$
declare
  v_business_id uuid := public.app_business_id();
  v_operation_id uuid;
  v_result uuid;
  v_existing_status text;
  v_existing_result uuid;
  v_item jsonb;
  v_serial jsonb;
  v_items jsonb;
  v_branch_id uuid;
  v_sale public.sales%rowtype;
  v_purchase public.purchases%rowtype;
  v_paid numeric;
  v_total numeric;
  v_serial_count integer;
begin
  if p_operation_type not in ('sale','purchase','sale_cancel','purchase_cancel') then
    return public.apply_sync_operation(p_operation_key,p_operation_type,p_payload);
  end if;
  if v_business_id is null then raise exception 'business_not_authenticated'; end if;
  if nullif(trim(p_operation_key),'') is null then raise exception 'operation_key_required'; end if;
  if p_payload is null or jsonb_typeof(p_payload)<>'object' then raise exception 'invalid_operation_payload'; end if;

  select id,status,nullif(payload->>'result','')::uuid
    into v_operation_id,v_existing_status,v_existing_result
  from public.sync_operations
  where business_id=v_business_id and operation_key=p_operation_key;
  if v_operation_id is not null and v_existing_status='applied' then
    return jsonb_build_object('status','applied','operation_key',p_operation_key,'result',v_existing_result);
  end if;
  if v_operation_id is null then
    insert into public.sync_operations(business_id,operation_key,operation_type,payload,status)
    values(v_business_id,p_operation_key,p_operation_type,p_payload,'pending')
    returning id into v_operation_id;
  else
    update public.sync_operations set status='pending',payload=p_payload,error_message=null
    where id=v_operation_id;
  end if;
  v_branch_id:=nullif(p_payload->>'branch_id','')::uuid;

  if p_operation_type='sale' then
    v_paid:=coalesce((p_payload->>'paid')::numeric,0);
    v_total:=coalesce((p_payload->>'total')::numeric,0);
    if v_paid<0 or v_paid>v_total or v_total<0 then raise exception 'invalid_sale_totals'; end if;
    for v_item in select value from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
      if nullif(v_item->>'serial_id','') is not null then
        perform 1 from public.product_serial_numbers
        where id=(v_item->>'serial_id')::uuid and business_id=v_business_id
          and product_id=(v_item->>'product_id')::uuid and status='in_stock';
        if not found then raise exception 'serial_not_available'; end if;
      end if;
    end loop;
    v_result:=public.complete_sale(
      v_business_id,v_branch_id,nullif(p_payload->>'customer_id','')::uuid,
      p_payload->>'invoice_number',coalesce(p_payload->>'payment_method','cash'),
      0,coalesce(p_payload->'items','[]'::jsonb)
    );
    update public.sales set
      subtotal=coalesce((p_payload->>'subtotal')::numeric,subtotal),
      discount=coalesce((p_payload->>'discount')::numeric,discount),
      tax=coalesce((p_payload->>'tax')::numeric,tax),
      total=v_total,paid=v_paid,remaining=greatest(0,v_total-v_paid),
      metadata=coalesce(metadata,'{}'::jsonb)||jsonb_build_object('offline_operation_key',p_operation_key)
    where id=v_result and business_id=v_business_id;
    if v_paid>0 and not exists(select 1 from public.payments where business_id=v_business_id and sale_id=v_result) then
      insert into public.payments(business_id,customer_id,sale_id,amount,payment_method,created_by)
      values(v_business_id,nullif(p_payload->>'customer_id','')::uuid,v_result,v_paid,coalesce(p_payload->>'payment_method','cash'),auth.uid());
    end if;
    for v_item in select value from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
      update public.sale_items set
        tax=coalesce((v_item->>'tax')::numeric,0),
        activity_data=coalesce(v_item->'activity_data','{}'::jsonb),
        serial_id=nullif(v_item->>'serial_id','')::uuid
      where id=(
        select id from public.sale_items
        where sale_id=v_result and business_id=v_business_id
          and product_id=(v_item->>'product_id')::uuid
          and variant_id is not distinct from nullif(v_item->>'variant_id','')::uuid
          and batch_id is not distinct from nullif(v_item->>'batch_id','')::uuid
          and serial_id is null
        order by id limit 1
      );
      if nullif(v_item->>'serial_id','') is not null then
        update public.product_serial_numbers
        set status='sold',warranty_start=current_date
        where id=(v_item->>'serial_id')::uuid and business_id=v_business_id and status='in_stock';
        if not found then raise exception 'serial_already_sold'; end if;
      end if;
    end loop;

  elsif p_operation_type='purchase' then
    v_paid:=coalesce((p_payload->>'paid')::numeric,0);
    v_total:=coalesce((p_payload->>'total')::numeric,0);
    if v_paid<0 or v_paid>v_total or v_total<0 then raise exception 'invalid_purchase_totals'; end if;
    v_result:=public.receive_purchase(
      v_business_id,v_branch_id,nullif(p_payload->>'supplier_id','')::uuid,
      p_payload->>'invoice_number',coalesce(p_payload->>'payment_method','cash'),
      0,coalesce(p_payload->'items','[]'::jsonb)
    );
    update public.purchases set
      subtotal=coalesce((p_payload->>'subtotal')::numeric,subtotal),
      discount=coalesce((p_payload->>'discount')::numeric,discount),
      tax=coalesce((p_payload->>'tax')::numeric,tax),
      total=v_total,paid=v_paid,remaining=greatest(0,v_total-v_paid)
    where id=v_result and business_id=v_business_id;
    if v_paid>0 and not exists(select 1 from public.payments where business_id=v_business_id and purchase_id=v_result) then
      insert into public.payments(business_id,supplier_id,purchase_id,amount,payment_method,created_by)
      values(v_business_id,nullif(p_payload->>'supplier_id','')::uuid,v_result,v_paid,coalesce(p_payload->>'payment_method','cash'),auth.uid());
    end if;
    for v_item in select value from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
      update public.purchase_items set
        discount=coalesce((v_item->>'discount')::numeric,0),
        tax=coalesce((v_item->>'tax')::numeric,0),
        activity_data=coalesce(v_item->'activity_data','{}'::jsonb)
      where id=(
        select id from public.purchase_items
        where purchase_id=v_result and business_id=v_business_id
          and product_id=(v_item->>'product_id')::uuid
          and variant_id is not distinct from nullif(v_item->>'variant_id','')::uuid
          and batch_id is not distinct from nullif(v_item->>'batch_id','')::uuid
        order by id limit 1
      );
      v_serial_count:=jsonb_array_length(coalesce(v_item->'serials','[]'::jsonb));
      if v_serial_count>0 and v_serial_count<>(v_item->>'quantity')::integer then
        raise exception 'serial_count_mismatch';
      end if;
      for v_serial in select value from jsonb_array_elements(coalesce(v_item->'serials','[]'::jsonb)) loop
        insert into public.product_serial_numbers(
          id,business_id,product_id,variant_id,serial_number,imei,warranty_end,status
        ) values(
          coalesce(nullif(v_serial->>'id','')::uuid,gen_random_uuid()),v_business_id,
          (v_item->>'product_id')::uuid,nullif(v_item->>'variant_id','')::uuid,
          v_serial->>'serial_number',nullif(v_serial->>'imei',''),
          nullif(v_serial->>'warranty_end','')::date,'in_stock'
        );
      end loop;
    end loop;

  elsif p_operation_type='sale_cancel' then
    select * into v_sale from public.sales
    where id=(p_payload->>'sale_id')::uuid and business_id=v_business_id for update;
    if v_sale.id is null then raise exception 'sale_not_found'; end if;
    if v_sale.status='cancelled' then v_result:=v_sale.id;
    else
      select coalesce(jsonb_agg(jsonb_build_object(
        'product_id',product_id,'variant_id',variant_id,'batch_id',batch_id,
        'serial_id',serial_id,'quantity',quantity,
        'unit_price',case when quantity=0 then 0 else total/quantity end
      )),'[]'::jsonb) into v_items
      from public.sale_items where sale_id=v_sale.id and business_id=v_business_id;
      v_result:=public.record_sale_return(
        v_business_id,v_sale.branch_id,v_sale.id,v_sale.customer_id,
        p_operation_key,coalesce(p_payload->>'reason','إلغاء فاتورة'),v_items
      );
      update public.sales set status='cancelled' where id=v_sale.id;
      update public.product_serial_numbers ps set status='in_stock'
      where ps.business_id=v_business_id and ps.id in(
        select serial_id from public.sale_items where sale_id=v_sale.id and serial_id is not null
      );
    end if;

  elsif p_operation_type='purchase_cancel' then
    select * into v_purchase from public.purchases
    where id=(p_payload->>'purchase_id')::uuid and business_id=v_business_id for update;
    if v_purchase.id is null then raise exception 'purchase_not_found'; end if;
    if v_purchase.status='cancelled' then v_result:=v_purchase.id;
    else
      select coalesce(jsonb_agg(jsonb_build_object(
        'product_id',product_id,'variant_id',variant_id,'batch_id',batch_id,
        'serial_id',serial_id,'quantity',quantity,
        'unit_price',unit_cost
      )),'[]'::jsonb) into v_items
      from public.purchase_items where purchase_id=v_purchase.id and business_id=v_business_id;
      v_result:=public.record_purchase_return(
        v_business_id,v_purchase.branch_id,v_purchase.id,v_purchase.supplier_id,
        p_operation_key,coalesce(p_payload->>'reason','إلغاء فاتورة شراء'),v_items
      );
      update public.purchases set status='cancelled' where id=v_purchase.id;
    end if;
  end if;

  update public.sync_operations
  set status='applied',applied_at=now(),
      payload=jsonb_set(p_payload,'{result}',to_jsonb(v_result),true),
      error_message=null
  where id=v_operation_id;
  return jsonb_build_object('status','applied','operation_key',p_operation_key,'result',v_result);
exception when others then
  update public.sync_operations set status='failed',error_message=sqlerrm where id=v_operation_id;
  raise;
end;
$$;

revoke all on function public.apply_sync_operation_v2(text,text,jsonb) from public;
grant execute on function public.apply_sync_operation_v2(text,text,jsonb) to authenticated;