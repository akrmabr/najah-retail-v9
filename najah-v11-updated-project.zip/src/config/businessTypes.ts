import {ACTIVITY_OPTIONS,ACTIVITY_REGISTRY,getActivityDefinition} from '../activity/registry';
import type {ActivityDefinition} from '../activity/types';
export type BusinessTypeId=keyof typeof ACTIVITY_REGISTRY;
export type BusinessField=string;
export type BusinessTypeConfig=ActivityDefinition&{productLabel:string;inventoryLabel:string;purchaseLabel:string;reportLabel:string;fields:string[];units:string[];variants:string[];supportsExpiry:boolean;supportsSerials:boolean;supportsImei:boolean};
function compat(a:ActivityDefinition):BusinessTypeConfig{return Object.assign({},a,{productLabel:a.productSchema.productLabel,inventoryLabel:a.terminology.inventory,purchaseLabel:a.terminology.purchases,reportLabel:a.terminology.reports,fields:a.productSchema.fields.map(f=>f.id),units:a.productSchema.units,variants:a.productSchema.variantFields,supportsExpiry:a.inventoryRules.requireExpiry,supportsSerials:a.inventoryRules.requireSerial,supportsImei:a.inventoryRules.requireImei});}
export const BUSINESS_TYPES=Object.fromEntries(Object.entries(ACTIVITY_REGISTRY).map(([id,a])=>[id,compat(a)])) as Record<string,BusinessTypeConfig>;
export const BUSINESS_TYPE_OPTIONS=ACTIVITY_OPTIONS.map(compat);
export const getBusinessType=(id?:string|null)=>compat(getActivityDefinition(id));
