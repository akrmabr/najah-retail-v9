import { db, getPharmacyId } from './db'; import type {Batch,Product,ProductVariant,StockMovement} from '../types/models'; import { now, uid } from '../utils/ids'; import { audit } from './audit'; import { enqueueOperation } from './sync';
export async function productSearch(q:string){ const s=q.trim().toLowerCase(); const [all,variants]=await Promise.all([db.products.toArray(),db.product_variants.toArray()]); const variantProductIds=new Set(variants.filter(v=>!s||[v.name,v.sku,v.barcode].some(value=>String(value||'').toLowerCase().includes(s))).map(v=>v.product_id)); return all.filter(p=>p.active && (!s||variantProductIds.has(p.id)||[p.arabic_name,p.english_name,p.generic_name,p.barcode,p.alternative_barcode,p.sku,p.manufacturer].some(v=>String(v||'').toLowerCase().includes(s)))).slice(0,50); }
export async function availableBatches(product_id:string){ const rows=await db.batches.where('product_id').equals(product_id).toArray(); const today=new Date().toISOString().slice(0,10); return rows.filter(b=>b.quantity>0 && (!b.expiry_date || b.expiry_date>=today)).sort((a,b)=>(a.expiry_date||'9999').localeCompare(b.expiry_date||'9999')); }
export async function adjustStock(user_id: string, product_id: string, batch_id: string | undefined, qtyDelta: number, type: StockMovement['type'], notes?: string) {
 const pharmacy_id = getPharmacyId(); if (!product_id || !Number.isFinite(qtyDelta) || qtyDelta === 0) throw new Error('بيانات تسوية المخزون غير صالحة');
 await (db.transaction as any)('rw', [db.batches, db.stock_movements, db.audit_logs, db.sync_operations], async () => {
   if (!batch_id) throw new Error('اختر دفعة قبل إجراء التسوية'); const batch = await db.batches.get(batch_id); if (!batch) throw new Error('لم يتم العثور على الدفعة');
   const before = batch.quantity, after = before + qtyDelta; if (after < 0) throw new Error('الكمية غير كافية'); await db.batches.update(batch_id, { quantity: after, updated_at: now() });
   const movement: StockMovement = { id: uid('move'), pharmacy_id, created_at: now(), updated_at: now(), product_id, batch_id, type, quantity: qtyDelta, before_qty: before, after_qty: after, user_id, notes };
   await db.stock_movements.add(movement); await audit(user_id, 'stock_adjustment', 'stock_movements', movement.id, movement);
   await enqueueOperation('stock_adjustment', { product_id, batch_id, quantity_delta: qtyDelta, movement_type: type, reason: notes || '' }, `stock:${movement.id}`);
 });
}
export async function lowStock(){ const products=await db.products.toArray(); const batches=await db.batches.toArray(); return products.filter(p=>batches.filter(b=>b.product_id===p.id).reduce((s,b)=>s+b.quantity,0)<=p.reorder_level); }
export async function expiryBuckets(){ const batches=await db.batches.toArray(); const today=new Date(); const diff=(d?:string)=>d?Math.ceil((new Date(d).getTime()-today.getTime())/86400000):99999; return {expired:batches.filter(b=>diff(b.expiry_date)<0),d7:batches.filter(b=>diff(b.expiry_date)>=0&&diff(b.expiry_date)<=7),d30:batches.filter(b=>diff(b.expiry_date)>7&&diff(b.expiry_date)<=30),d60:batches.filter(b=>diff(b.expiry_date)>30&&diff(b.expiry_date)<=60),d90:batches.filter(b=>diff(b.expiry_date)>60&&diff(b.expiry_date)<=90)}; }
export async function saveProduct(user_id: string, p: Partial<Product>) {
 const pharmacy_id = getPharmacyId();
 const name = String(p.arabic_name || '').trim();
 const variants = Array.isArray(p.variants) ? p.variants : [];
 const base = { pharmacy_id, updated_at: now(), active: true, tax: 0, reorder_level: 0, purchase_price: 0, selling_price: 0, ...p, arabic_name: name } as Product;
 if (!base.arabic_name) throw new Error('اسم المنتج مطلوب');
 if (!Number.isFinite(base.selling_price) || base.selling_price < 0 || !Number.isFinite(base.purchase_price) || base.purchase_price < 0) throw new Error('الأسعار غير صالحة');
 if (!base.id) { base.id = uid('prod'); base.created_at = now(); }
 const normalized: ProductVariant[] = variants.filter((v: any) => String(v.name || '').trim()).map((v: any) => ({ id: v.id || uid('variant'), pharmacy_id, product_id: base.id, name: String(v.name).trim(), sku: String(v.sku || '').trim() || undefined, barcode: String(v.barcode || '').trim() || undefined, attributes: v.attributes || {}, quantity: Number(v.quantity || 0), purchase_price: Number(v.purchase_price || base.purchase_price), selling_price: Number(v.selling_price || base.selling_price), active: true, created_at: v.created_at || now(), updated_at: now() }));
 await (db.transaction as any)('rw', [db.products, db.product_variants, db.audit_logs, db.sync_operations], async () => {
   if (p.id) await db.products.update(base.id, { ...base, updated_at: now() }); else await db.products.add(base);
   await db.product_variants.where('product_id').equals(base.id).delete();
   if (normalized.length) await db.product_variants.bulkAdd(normalized);
   await audit(user_id, p.id ? 'product_modification' : 'product_creation', 'products', base.id, base);
   await enqueueOperation('product', { id: base.id, name: base.arabic_name, sku: base.sku || null, base_barcode: base.barcode || null, purchase_price: base.purchase_price, sale_price: base.selling_price, wholesale_price: base.wholesale_price ?? null, minimum_stock: base.reorder_level, attributes: { ...(base.attributes || {}), variants: normalized }, is_active: base.active }, `product:${base.id}:${base.updated_at}`);
 });
 return { ...base, variants: normalized };
}
export async function saveBatch(user_id: string, b: Partial<Batch>) {
 const pharmacy_id = getPharmacyId(); const row = { pharmacy_id, updated_at: now(), quantity: 0, initial_quantity: 0, purchase_price: 0, selling_price: 0, ...b } as Batch;
 if (!row.product_id || !row.batch_number?.trim()) throw new Error('اختر المنتج وأدخل رقم الدفعة'); if (!Number.isFinite(row.quantity) || row.quantity < 0) throw new Error('الكمية غير صالحة');
 if (!row.id) { row.id = uid('batch'); row.created_at = now(); row.initial_quantity = row.quantity; }
 await (db.transaction as any)('rw', [db.batches, db.stock_movements, db.audit_logs, db.sync_operations], async () => {
   if (b.id) { const existing = await db.batches.get(row.id); if (!existing) throw new Error('لم يتم العثور على الدفعة'); const delta = row.quantity - existing.quantity; if (delta < 0 && existing.quantity + delta < 0) throw new Error('الكمية غير صالحة'); await db.batches.update(row.id, row); if (delta !== 0) await db.stock_movements.add({ id: uid('move'), pharmacy_id, created_at: now(), updated_at: now(), product_id: row.product_id, batch_id: row.id, type: 'adjustment', quantity: delta, before_qty: existing.quantity, after_qty: row.quantity, user_id, notes: 'تعديل بيانات الدفعة' }); } else { await db.batches.add(row); if (row.quantity > 0) await db.stock_movements.add({ id: uid('move'), pharmacy_id, created_at: now(), updated_at: now(), product_id: row.product_id, batch_id: row.id, type: 'opening', quantity: row.quantity, before_qty: 0, after_qty: row.quantity, user_id }); }
   await audit(user_id, 'batch_save', 'batches', row.id, row); await enqueueOperation('stock_opening', { product_id: row.product_id, batch_id: row.id, quantity_delta: row.quantity, batch_number: row.batch_number, expiry_date: row.expiry_date || null, purchase_price: row.purchase_price, selling_price: row.selling_price }, `batch:${row.id}:${row.updated_at}`);
 }); return row;
}

