import {useLiveQuery} from 'dexie-react-hooks';
import {useState} from 'react';
import {createUser,permissionOptions,roleLabels,setUserActive} from '../services/auth';
import {db} from '../services/db';
import type {Role,User} from '../types/models';
const roles:Role[]=['ADMIN','PHARMACIST','CASHIER','INVENTORY','ACCOUNTANT','VIEWER'];
const defaults:Record<string,string[]>={ADMIN:['*'],PHARMACIST:['dashboard','pos','products','inventory','customers','reports'],CASHIER:['dashboard','pos','customers'],INVENTORY:['dashboard','products','inventory','purchases','suppliers','reports'],ACCOUNTANT:['dashboard','expenses','payments','reports','customers','suppliers'],VIEWER:['dashboard','reports']};
export default function Users({user}:{user:User}){
 const rows=useLiveQuery(()=>db.users.toArray(),[])||[];
 const [f,setF]=useState({name:'',email:'',username:'',password:'',role:'CASHIER' as Role,permissions:defaults.CASHIER});
 const [msg,setMsg]=useState(''); const [busy,setBusy]=useState(false);
 function setRole(role:Role){setF(x=>({...x,role,permissions:defaults[role]||[]}))}
 function togglePermission(id:string){setF(x=>({...x,permissions:x.permissions.includes(id)?x.permissions.filter(p=>p!==id):[...x.permissions,id]}))}
 async function save(e:any){e.preventDefault();setMsg('');setBusy(true);try{await createUser(user,f);setF({name:'',email:'',username:'',password:'',role:'CASHIER',permissions:defaults.CASHIER});setMsg('تم إنشاء المستخدم وتحديد صلاحياته.')}catch(e:any){setMsg(e?.message||'تعذر إنشاء المستخدم.')}finally{setBusy(false)}}
 async function toggle(target:User){try{await setUserActive(user,target,!target.active);setMsg(target.active?'تم إيقاف المستخدم.':'تم تفعيل المستخدم.')}catch(e:any){setMsg(e?.message||'تعذر تعديل حالة المستخدم.')}}
 return <section><h1>المستخدمون والصلاحيات</h1><div className="card"><p>أنشئ حساباً للمدير أو الصيدلي أو الكاشير، ثم حدد الصفحات التي يستطيع استخدامها. المدير يمتلك كل الصلاحيات تلقائياً.</p><form className="formgrid" onSubmit={save}>
  <input required value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="اسم المستخدم"/>
  <input required type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} placeholder="البريد الإلكتروني"/>
  <input required value={f.username} onChange={e=>setF({...f,username:e.target.value})} placeholder="اسم الدخول"/>
  <input required minLength={8} type="password" value={f.password} onChange={e=>setF({...f,password:e.target.value})} placeholder="كلمة المرور (8 أحرف على الأقل)"/>
  <select value={f.role} onChange={e=>setRole(e.target.value as Role)}>{roles.map(r=><option key={r} value={r}>{roleLabels[r]}</option>)}</select>
  {f.role!=='ADMIN'&&<div className="permission-grid">{permissionOptions.map(p=><label key={p.id}><input type="checkbox" checked={f.permissions.includes(p.id)} onChange={()=>togglePermission(p.id)}/>{p.label}</label>)}</div>}
  <button className="primary" disabled={busy}>إضافة المستخدم</button></form></div>{msg&&<div className="alert">{msg}</div>}
  <div className="card"><table><thead><tr><th>الاسم</th><th>اسم الدخول</th><th>الدور</th><th>الصلاحيات</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.name}</td><td>{r.username}</td><td>{roleLabels[r.role]||r.role}</td><td>{r.role==='OWNER'||r.role==='ADMIN'?'كل الصلاحيات':(r.permissions?.map(p=>permissionOptions.find(x=>x.id===p)?.label||p).join('، ')||'حسب الدور')}</td><td>{r.active?'نشط':'موقوف'}</td><td>{r.id!==user.id&&r.role!=='OWNER'&&<button className={r.active?'danger':'primary'} onClick={()=>toggle(r)}>{r.active?'إيقاف':'تفعيل'}</button>}</td></tr>)}</tbody></table></div>
 </section>
}