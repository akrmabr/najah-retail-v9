import { db, getPharmacyId } from './db';
import { now, uid } from '../utils/ids';
import type { CashMovement, PaymentMethod, Purchase, SerialNumber } from '../types/models';
import { audit } from './audit';
import { enqueueOperation } from './sync';
import { ensureChartOfAccounts, postJournalInCurrentTransaction } from './accounting';
import { roundMoney } from '../domain/calculations';

export interface PurchaseLine {
  product_id: string;
  variant_id?: string;
  batch_number: string;
  quantity: number;
  purchase_price: number;
  selling_price: number;
  expiry_date?: string;
  manufacture_date?: string;
  discount: number;
  tax: number;
  serials?: { serial_number: string; imei?: string; warranty_end?: string }[];
}

async function recordShiftMovement(
  userId: string, type: CashMovement['type'], amount: number,
  referenceId: string, timestamp: string,
) {
  if (amount <= 0) return;
  const shift = await db.cash_shifts.where('user_id').equals(userId).filter((row) => row.status === 'OPEN').first();
  if (!shift) return;
  await db.cash_movements.add({
    id: uid('cash'), pharmacy_id: getPharmacyId(), shift_id: shift.id,
    type, amount, reference_id: referenceId, created_at: timestamp,
  });
  const sign = ['return', 'expense', 'cash_out', 'transfer'].includes(type) ? -1 : 1;
  await db.cash_shifts.update(shift.id, {
    expected_cash: roundMoney(shift.expected_cash + sign * amount), updated_at: timestamp,
  });
}

export async function postPurchase(
  user_id: string, supplier_id: string | undefined, invoice_no: string,
  paid: number, lines: PurchaseLine[],
) {
  if (!lines.length) throw new Error('أضف صنفاً واحداً على الأقل');
  if (!Number.isFinite(paid) || paid < 0) throw new Error('المبلغ المدفوع غير صالح');
  for (const line of lines) {
    if (!line.product_id || !line.batch_number?.trim() ||
        !Number.isFinite(line.quantity) || line.quantity <= 0 ||
        !Number.isFinite(line.purchase_price) || line.purchase_price < 0 ||
        !Number.isFinite(line.selling_price) || line.selling_price < 0 ||
        !Number.isFinite(line.discount) || line.discount < 0 ||
        !Number.isFinite(line.tax) || line.tax < 0 || line.tax > 100) {
      throw new Error('بيانات الشراء غير صالحة');
    }
    if (line.serials?.length && line.serials.length !== line.quantity) {
      throw new Error('عدد الأرقام التسلسلية/IMEI يجب أن يساوي الكمية المستلمة.');
    }
  }
  await ensureChartOfAccounts();
  const pharmacy_id = getPharmacyId();
  const settings = await db.settings.get('settings');
  const timestamp = now();
  let purchase!: Purchase;
  await (db.transaction as any)('rw', [
    db.purchases, db.purchase_items, db.batches, db.serial_numbers,
    db.stock_movements, db.suppliers, db.audit_logs, db.sync_operations,
    db.accounts, db.journal_entries, db.journal_lines, db.cash_shifts,
    db.cash_movements,
  ], async () => {
    let subtotal = 0, discount = 0, tax = 0;
    for (const line of lines) {
      const base = roundMoney(line.quantity * line.purchase_price);
      if (line.discount > base) throw new Error('خصم أحد الأصناف أكبر من قيمته.');
      subtotal = roundMoney(subtotal + base);
      discount = roundMoney(discount + line.discount);
      tax = roundMoney(tax + (base - line.discount) * (line.tax / 100));
    }
    const total = roundMoney(subtotal - discount + tax);
    if (paid > total) throw new Error('المبلغ المدفوع أكبر من إجمالي الشراء');
    const normalizedInvoice = String(invoice_no || '').trim() || `P-${Date.now()}`;
    if (await db.purchases.where('invoice_no').equals(normalizedInvoice).count()) {
      throw new Error('رقم فاتورة الشراء مستخدم مسبقاً');
    }
    purchase = {
      id: uid('pur'), pharmacy_id, branch_id:settings?.branch_id, created_at: timestamp, updated_at: timestamp,
      supplier_id, invoice_no: normalizedInvoice, date: timestamp.slice(0, 10),
      subtotal, discount, tax, total, paid: roundMoney(paid),
      remaining: roundMoney(total - paid), status: 'POSTED',
    };
    await db.purchases.add(purchase);
    const syncedItems: any[] = [];
    for (const line of lines) {
      const batch = {
        id: uid('batch'), pharmacy_id, branch_id:settings?.branch_id, created_at: timestamp, updated_at: timestamp,
        product_id: line.product_id, variant_id: line.variant_id,
        batch_number: line.batch_number.trim(), quantity: line.quantity,
        initial_quantity: line.quantity, purchase_price: line.purchase_price,
        selling_price: line.selling_price, manufacture_date: line.manufacture_date,
        expiry_date: line.expiry_date, supplier_id,
      };
      await db.batches.add(batch);
      const item = {
        id: uid('pitem'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
        purchase_id: purchase.id, product_id: line.product_id,
        variant_id: line.variant_id, batch_id: batch.id, quantity: line.quantity,
        purchase_price: line.purchase_price, selling_price: line.selling_price,
        discount: line.discount,
        tax: roundMoney((line.quantity * line.purchase_price - line.discount) * (line.tax / 100)),
        line_total: roundMoney(line.quantity * line.purchase_price - line.discount),
      };
      await db.purchase_items.add(item);
      syncedItems.push(item);
      await db.stock_movements.add({
        id: uid('move'), pharmacy_id, branch_id:settings?.branch_id, created_at: timestamp, updated_at: timestamp,
        product_id: line.product_id, batch_id: batch.id, type: 'purchase',
        quantity: line.quantity, before_qty: 0, after_qty: line.quantity,
        reference_id: purchase.id, user_id,
      });
      for (const input of line.serials || []) {
        const duplicate = await db.serial_numbers.where('serial_number').equals(input.serial_number.trim()).first();
        const duplicateImei = input.imei ? await db.serial_numbers.where('imei').equals(input.imei.trim()).first() : undefined;
        if (duplicate || duplicateImei) throw new Error('يوجد رقم تسلسلي أو IMEI مسجل مسبقاً.');
        const serial: SerialNumber = {
          id: uid('serial'), pharmacy_id, product_id: line.product_id,
          variant_id: line.variant_id, batch_id: batch.id, purchase_id: purchase.id,
          serial_number: input.serial_number.trim(),
          imei: input.imei?.trim() || undefined, warranty_end: input.warranty_end,
          status: 'in_stock', created_at: timestamp, updated_at: timestamp,
        };
        await db.serial_numbers.add(serial);
      }
    }
    if (supplier_id && purchase.remaining > 0) {
      const supplier = await db.suppliers.get(supplier_id);
      if (supplier) await db.suppliers.update(supplier.id, {
        balance: roundMoney(supplier.balance + purchase.remaining), updated_at: timestamp,
      });
    }
    const inventory = roundMoney(subtotal - discount);
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'purchase', reference_id: purchase.id,
      description: `فاتورة شراء ${purchase.invoice_no}`,
      lines: [
        { accountCode: '1300', debit: inventory, credit: 0 },
        { accountCode: '1250', debit: tax, credit: 0 },
        { accountCode: '1000', debit: 0, credit: purchase.paid },
        { accountCode: '2000', debit: 0, credit: purchase.remaining },
      ],
    });
    await recordShiftMovement(user_id, 'cash_out', purchase.paid, purchase.id, timestamp);
    await audit(user_id, 'purchase', 'purchases', purchase.id, purchase);
    const syncItems = [];
    for (const item of syncedItems) {
      const source = lines.find((line) => line.product_id === item.product_id && line.variant_id === item.variant_id);
      const itemSerials = await db.serial_numbers.where('purchase_id').equals(purchase.id)
        .filter((serial) => serial.product_id === item.product_id && serial.batch_id === item.batch_id).toArray();
      syncItems.push({
        product_id: item.product_id, variant_id: item.variant_id || null,
        batch_id: item.batch_id, batch_number: source?.batch_number || null,
        expiry_date: source?.expiry_date || null, quantity: item.quantity,
        unit_cost: item.purchase_price, discount: item.discount || 0,
        tax: item.tax || 0,
        serials: itemSerials.map((serial) => ({
          id: serial.id, serial_number: serial.serial_number, imei: serial.imei || null,
          warranty_end: serial.warranty_end || null,
        })),
      });
    }
    await enqueueOperation('purchase', {
      invoice_number: purchase.invoice_no, supplier_id: supplier_id || null,
      branch_id:purchase.branch_id||null,
      payment_method: 'cash', paid: purchase.paid,
      subtotal: purchase.subtotal, discount: purchase.discount,
      tax: purchase.tax, total: purchase.total, items: syncItems,
    }, `purchase:${purchase.invoice_no}`);
  });
  return purchase;
}

export async function recordPayment(
  user_id: string, party_type: 'customer' | 'supplier', party_id: string,
  amount: number, method: PaymentMethod, notes?: string,
) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('المبلغ غير صالح.');
  await ensureChartOfAccounts();
  const pharmacy_id = getPharmacyId();
  const party = party_type === 'customer'
    ? await db.customers.get(party_id) : await db.suppliers.get(party_id);
  if (!party) throw new Error('الحساب المحدد غير موجود.');
  if (amount > party.balance) throw new Error('المبلغ أكبر من الرصيد المستحق.');
  const timestamp = now();
  await (db.transaction as any)('rw', [
    db.payments, db.customers, db.suppliers, db.audit_logs, db.sync_operations,
    db.accounts, db.journal_entries, db.journal_lines, db.cash_shifts, db.cash_movements,
  ], async () => {
    const payment = {
      id: uid('pay'), pharmacy_id, created_at: timestamp, updated_at: timestamp,
      party_type, party_id, amount: roundMoney(amount), date: timestamp.slice(0, 10),
      method, payment_method: method, notes,
    };
    await db.payments.add(payment);
    const table = party_type === 'customer' ? db.customers : db.suppliers;
    await table.update(party_id, {
      balance: roundMoney(Math.max(0, party.balance - amount)), updated_at: timestamp,
    });
    const cashAccount = method === 'Cash' ? '1000' : '1100';
    await postJournalInCurrentTransaction(user_id, {
      reference_type: `${party_type}_payment`, reference_id: payment.id,
      description: party_type === 'customer' ? 'تحصيل من عميل' : 'سداد لمورد',
      lines: party_type === 'customer'
        ? [{ accountCode: cashAccount, debit: amount, credit: 0 }, { accountCode: '1200', debit: 0, credit: amount }]
        : [{ accountCode: '2000', debit: amount, credit: 0 }, { accountCode: cashAccount, debit: 0, credit: amount }],
    });
    if (method === 'Cash') {
      await recordShiftMovement(user_id, party_type === 'customer' ? 'cash_in' : 'cash_out', amount, payment.id, timestamp);
    }
    await audit(user_id, 'payment', 'payments', payment.id, payment);
    await enqueueOperation('payment', {
      party_type, party_id, amount, payment_method: method.toLowerCase(), notes: notes || '',
    }, `payment:${payment.id}`);
  });
}

export async function cancelPurchase(user_id: string, purchase_id: string, reason: string) {
  const purchase = await db.purchases.get(purchase_id);
  if (!purchase || purchase.status !== 'POSTED') throw new Error('فاتورة الشراء غير قابلة للإلغاء');
  if (!reason.trim()) throw new Error('سبب الإلغاء مطلوب.');
  await ensureChartOfAccounts();
  const timestamp = now();
  await (db.transaction as any)('rw', [
    db.purchases, db.purchase_items, db.batches, db.serial_numbers,
    db.stock_movements, db.suppliers, db.audit_logs, db.sync_operations,
    db.accounts, db.journal_entries, db.journal_lines, db.cash_shifts, db.cash_movements,
  ], async () => {
    const items = await db.purchase_items.where('purchase_id').equals(purchase_id).toArray();
    for (const item of items) {
      const batch = await db.batches.get(item.batch_id);
      if (batch) {
        if (batch.quantity < item.quantity) throw new Error('لا يمكن إلغاء الشراء لأن جزءاً من الكمية تم بيعه أو تسويته');
        await db.batches.update(batch.id, { quantity: batch.quantity - item.quantity, updated_at: timestamp });
        await db.stock_movements.add({
          id: uid('move'), pharmacy_id: purchase.pharmacy_id, created_at: timestamp,
          updated_at: timestamp, product_id: item.product_id, batch_id: batch.id,
          type: 'adjustment', quantity: -item.quantity, before_qty: batch.quantity,
          after_qty: batch.quantity - item.quantity, reference_id: purchase_id,
          user_id, notes: reason.trim(),
        });
      }
      const serialRows = await db.serial_numbers.where('product_id').equals(item.product_id)
        .filter((serial) => serial.status === 'in_stock' && serial.purchase_id === purchase_id &&
          serial.batch_id === item.batch_id && (!item.variant_id || serial.variant_id === item.variant_id)).toArray();
      if (item.serial_id) {
        const serial = await db.serial_numbers.get(item.serial_id);
        if (serial?.status !== 'in_stock') throw new Error('لا يمكن الإلغاء لأن الجهاز التسلسلي تم بيعه.');
        await db.serial_numbers.delete(item.serial_id);
      } else if (serialRows.length && serialRows.length >= item.quantity) {
        await db.serial_numbers.bulkDelete(serialRows.slice(0, item.quantity).map((serial) => serial.id));
      }
    }
    await db.purchases.update(purchase_id, { status: 'CANCELLED', updated_at: timestamp });
    if (purchase.supplier_id && purchase.remaining > 0) {
      const supplier = await db.suppliers.get(purchase.supplier_id);
      if (supplier) await db.suppliers.update(supplier.id, {
        balance: Math.max(0, roundMoney(supplier.balance - purchase.remaining)), updated_at: timestamp,
      });
    }
    const inventory = roundMoney(purchase.subtotal - purchase.discount);
    await postJournalInCurrentTransaction(user_id, {
      reference_type: 'purchase_cancel', reference_id: purchase.id,
      description: `إلغاء فاتورة شراء ${purchase.invoice_no}`,
      lines: [
        { accountCode: '1300', debit: 0, credit: inventory },
        { accountCode: '1250', debit: 0, credit: purchase.tax },
        { accountCode: '1000', debit: purchase.paid, credit: 0 },
        { accountCode: '2000', debit: purchase.remaining, credit: 0 },
      ],
    });
    await recordShiftMovement(user_id, 'cash_in', purchase.paid, purchase.id, timestamp);
    await audit(user_id, 'purchase_cancellation', 'purchases', purchase_id, { reason: reason.trim(), purchase });
    await enqueueOperation('purchase_cancel', { purchase_id, reason: reason.trim() }, `purchase-cancel:${purchase_id}`);
  });
}