import { db, getPharmacyId } from './db';
import type { CashMovement, PaymentMethod } from '../types/models';
import { now, uid } from '../utils/ids';
import { audit } from './audit';
import { enqueueOperation } from './sync';
import { ensureChartOfAccounts, postJournalInCurrentTransaction } from './accounting';
import { roundMoney } from '../domain/calculations';

export async function recordExpense(
  userId: string, amount: number, category: string, description: string,
  method: PaymentMethod = 'Cash',
) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('أدخل مبلغاً صحيحاً أكبر من صفر.');
  if (!category.trim()) throw new Error('فئة المصروف مطلوبة.');
  await ensureChartOfAccounts();
  const timestamp = now(), pharmacy_id = getPharmacyId(), id = uid('exp');
  await (db.transaction as any)('rw', [
    db.expenses, db.audit_logs, db.sync_operations, db.accounts,
    db.journal_entries, db.journal_lines, db.cash_shifts, db.cash_movements,
  ], async () => {
    const expense = {
      id, pharmacy_id, created_at: timestamp, updated_at: timestamp,
      amount: roundMoney(amount), date: timestamp.slice(0, 10),
      category: category.trim(), description: description.trim(),
      payment_method: method, created_by: userId,
    };
    await db.expenses.add(expense);
    await postJournalInCurrentTransaction(userId, {
      reference_type: 'expense', reference_id: id,
      description: `${category.trim()} — ${description.trim() || 'مصروف تشغيلي'}`,
      lines: [
        { accountCode: '6000', debit: amount, credit: 0 },
        { accountCode: method === 'Cash' ? '1000' : '1100', debit: 0, credit: amount },
      ],
    });
    if (method === 'Cash') {
      const shift = await db.cash_shifts.where('user_id').equals(userId).filter((row) => row.status === 'OPEN').first();
      if (shift) {
        const movement: CashMovement = {
          id: uid('cash'), pharmacy_id, shift_id: shift.id, type: 'expense',
          amount: roundMoney(amount), reference_id: id, notes: description.trim(),
          created_at: timestamp,
        };
        await db.cash_movements.add(movement);
        await db.cash_shifts.update(shift.id, {
          expected_cash: roundMoney(shift.expected_cash - amount), updated_at: timestamp,
        });
      }
    }
    await audit(userId, 'expense_creation', 'expenses', id, expense);
    await enqueueOperation('expense', {
      category: expense.category, amount: expense.amount,
      description: expense.description, payment_method: method.toLowerCase(),
      date: expense.date,
    }, `expense:${id}`);
  });
  return id;
}