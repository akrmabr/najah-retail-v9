import { db, getPharmacyId } from './db'; import { availableBatches } from './inventory'; import type {PaymentMethod,Sale,SaleItem} from '../types/models'; import { now, uid } from '../utils/ids'; import { audit } from './audit'; import { enqueueOperation } from './sync'; import { licenseGate } from './license';
export interface CartLine{product_id:string; quantity:number; unit_price:number; discount:number; tax:number;}
export async function completeSale(user_id:string, lines:CartLine[], paid:number, method:PaymentMethod, customer_id?:string){
 const gate=licenseGate(); if(!gate.ok) throw new Error(gate.message);
 if(!lines.length) throw new Error('السلة فارغة');
 if(!Number.isFinite(paid)||paid<0) throw new Error('قيمة المدفوع غير صالحة');
 for(const l of lines){ if(!l.product_id||!Number.isFinite(l.quantity)||l.quantity<=0||!Number.isFinite(l.unit_price)||l.unit_price<0||!Number.isFinite(l.discount)||l.discount<0||l.discount>l.unit_price||!Number.isFinite(l.tax)||l.tax<0) throw new Error('بيانات أحد أصناف الفاتورة غير صالحة'); }
 const pharmacy_id=getPharmacyId(); const invoice_no=`S-${Date.now()}-${Math.floor(Math.random()*1000)}`; let sale!:Sale;
 await (db.transaction as any)('rw',[db.sales,db.sale_items,db.batches,db.stock_movements,db.customers,db.audit_logs,db.sync_operations],async()=>{
  let subtotal=0,tax=0,discount=0,profit=0; const items:SaleItem[]=[];
  for(const l of lines){
   let remaining=l.quantity; const batches=await availableBatches(l.product_id);
   for(const b of batches){ if(remaining<=0) break; const q=Math.min(remaining,b.quantity); const lineSubtotal=q*l.unit_price; const lineDiscount=q*l.discount; const lineTax=(lineSubtotal-lineDiscount)*(l.tax/100); const cost=q*b.purchase_price; const lineTotal=lineSubtotal-lineDiscount+lineTax; const before=b.quantity, after=before-q; await db.batches.update(b.id,{quantity:after,updated_at:now()}); const item:SaleItem={id:uid('saleitem'),pharmacy_id,created_at:now(),updated_at:now(),sale_id:'pending',product_id:l.product_id,batch_id:b.id,quantity:q,unit_price:l.unit_price,discount:lineDiscount,tax:lineTax,line_total:lineTotal,cost,profit:lineTotal-cost}; items.push(item); subtotal+=lineSubtotal; discount+=lineDiscount; tax+=lineTax; profit+=lineTotal-cost; await db.stock_movements.add({id:uid('move'),pharmacy_id,created_at:now(),updated_at:now(),product_id:l.product_id,batch_id:b.id,type:'sale',quantity:-q,before_qty:before,after_qty:after,reference_id:invoice_no,user_id}); remaining-=q; }
   if(remaining>0) throw new Error('الكمية غير كافية أو التشغيلة منتهية');
  }
  const total=subtotal-discount+tax;
  if(method!=='Credit' && paid<total) throw new Error('المبلغ المدفوع أقل من إجمالي الفاتورة');
  const remaining=Math.max(0,total-paid);
  sale={id:uid('sale'),pharmacy_id,created_at:now(),updated_at:now(),invoice_no,customer_id,subtotal,discount,tax,total,paid,remaining,payment_method:method,cashier_id:user_id,profit,status:'COMPLETED'};
  await db.sales.add(sale); for(const item of items){item.sale_id=sale.id; await db.sale_items.add(item)}
  if(customer_id && remaining>0){const c=await db.customers.get(customer_id); if(c) await db.customers.update(customer_id,{balance:c.balance+remaining,updated_at:now()});}
  await audit(user_id,'sale','sales',sale.id,sale);
  await enqueueOperation('sale',{invoice_number:sale.invoice_no,customer_id:customer_id||null,payment_method:method,paid,items:items.map((item)=>({product_id:item.product_id,batch_id:item.batch_id,quantity:item.quantity,unit_price:item.unit_price,discount:item.discount,tax:item.tax}))},`sale:${sale.invoice_no}`);
 });
 return sale;
}
export async function cancelSale(user_id:string,sale_id:string,reason:string){ const sale=await db.sales.get(sale_id); if(!sale||sale.status!=='COMPLETED') throw new Error('الفاتورة غير قابلة للإلغاء'); await (db.transaction as any)('rw',[db.sales,db.sale_items,db.batches,db.stock_movements,db.customers,db.audit_logs,db.sync_operations],async()=>{ const items=await db.sale_items.where('sale_id').equals(sale_id).toArray(); for(const it of items){const b=await db.batches.get(it.batch_id); if(b){await db.batches.update(b.id,{quantity:b.quantity+it.quantity,updated_at:now()}); await db.stock_movements.add({id:uid('move'),pharmacy_id:sale.pharmacy_id,created_at:now(),updated_at:now(),product_id:it.product_id,batch_id:b.id,type:'return',quantity:it.quantity,before_qty:b.quantity,after_qty:b.quantity+it.quantity,reference_id:sale_id,user_id,notes:reason});}} await db.sales.update(sale_id,{status:'CANCELLED',updated_at:now()}); if(sale.customer_id&&sale.remaining>0){const c=await db.customers.get(sale.customer_id); if(c) await db.customers.update(c.id,{balance:Math.max(0,c.balance-sale.remaining),updated_at:now()});} await audit(user_id,'sale_cancellation','sales',sale_id,reason); }); }
