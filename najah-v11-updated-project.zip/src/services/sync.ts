import { db, getPharmacyId } from './db';
import { STORAGE_KEYS } from './storageKeys';
import { planAllows } from './plans';
import type { SyncOperation, SyncStatus } from '../types/models';
import { now, uid } from '../utils/ids';
import { getValidAccessToken } from './remoteAuth';

/**
 * Offline-first queue.
 *
 * The queue is deliberately independent from the UI: every write can be
 * recorded before the network request is attempted. The server must accept
 * operation_key as an idempotency key and acknowledge it only after the
 * transaction commits.
 */
export async function enqueueOperation(operation_type: string, payload: unknown, operation_key: string = uid('op')) {
  const pharmacy_id = getPharmacyId();
  const settings = await db.settings.get('settings');
  if (!planAllows(String(settings?.plan_code || 'basic'), 'sync')) return undefined;
  const existing = await db.sync_operations.where('operation_key').equals(operation_key).first();
  if (existing) return existing;
  const operation: SyncOperation = {
    id: uid('sync'),
    pharmacy_id,
    operation_key,
    operation_type,
    payload,
    status: 'pending',
    attempts: 0,
    created_at: now(),
    updated_at: now(),
  };
  await db.sync_operations.add(operation);
  return operation;
}

export async function updateOperation(id: string, patch: Partial<SyncOperation>) {
  await db.sync_operations.update(id, { ...patch, updated_at: now() });
}

export async function listSyncOperations(status?: SyncStatus) {
  const rows: SyncOperation[] = await db.sync_operations.toArray();
  return rows
    .filter((row: SyncOperation) => !status || row.status === status)
    .sort((a: SyncOperation, b: SyncOperation) => a.created_at.localeCompare(b.created_at));
}

export async function markOperationApplied(id: string, server_version?: string) {
  await updateOperation(id, { status: 'applied', acknowledged_at: now(), server_version, last_error: undefined });
}

export async function markOperationFailed(id: string, error: unknown, conflict = false) {
  const row = await db.sync_operations.get(id);
  await updateOperation(id, {
    status: conflict ? 'conflict' : 'failed',
    attempts: (row?.attempts || 0) + 1,
    last_error: error instanceof Error ? error.message : String(error),
  });
}

export async function pendingSyncCount() {
  const rows = await listSyncOperations();
  return rows.filter((row: SyncOperation) => row.status === 'pending' || row.status === 'failed').length;
}
export async function retryOperation(id:string){const row=await db.sync_operations.get(id);if(!row)throw new Error('عملية المزامنة غير موجودة');await updateOperation(id,{status:'pending',last_error:undefined})}
export async function retryAllFailed(){const rows=(await listSyncOperations()).filter(r=>r.status==='failed'||r.status==='conflict');for(const row of rows)await retryOperation(row.id);return rows.length}
export async function syncPendingOperations() {
  if (!navigator.onLine) return { attempted: 0, applied: 0, failed: 0 };
  const settings: any = await db.settings.get('settings');
  if (!planAllows(String(settings?.plan_code || 'basic'), 'sync')) return { attempted: 0, applied: 0, failed: 0 };
  const endpoint = String(settings?.supabase_url || localStorage.getItem(STORAGE_KEYS.licenseEndpoint) || '').replace(/\/+$/, '');
  const anonKey = String(settings?.supabase_anon_key || import.meta.env.VITE_SUPABASE_ANON_KEY || '');
  const accessToken = await getValidAccessToken().catch(()=>String(settings?.supabase_access_token||''));
  if (!endpoint || !anonKey || !accessToken) return { attempted: 0, applied: 0, failed: 0 };
  const rows = (await listSyncOperations()).filter((row) => row.status === 'pending' || row.status === 'failed').slice(0, 25);
  let applied = 0, failed = 0;
  for (const row of rows) {
    if (row.status === 'failed' && row.updated_at && Date.now() - Date.parse(row.updated_at) < Math.min(30000, Math.max(2000, row.attempts * 5000))) continue;
    await updateOperation(row.id, { status: 'syncing' });
    try {
      const outbound: any = { ...((row.payload as any) || {}) };
      if ((row.operation_type === 'sale_return' || row.operation_type === 'sale_cancel') && outbound.sale_id) {
        const source = await db.sales.get(outbound.sale_id);
        outbound.sale_id = source?.server_id || source?.id || outbound.sale_id;
      }
      if (row.operation_type === 'purchase_return' && outbound.purchase_id) {
        const source = await db.purchases.get(outbound.purchase_id);
        outbound.purchase_id = source?.server_id || source?.id || outbound.purchase_id;
      }
      const rpc=row.operation_type.startsWith('stock_transfer_')?'apply_stock_transfer_sync':row.operation_type==='product'?'apply_product_sync':'apply_sync_operation_v2';
      const response = await fetch(`${endpoint}/rest/v1/rpc/${rpc}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', apikey: anonKey, authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ p_operation_key: row.operation_key, p_operation_type: row.operation_type, p_payload: outbound }),
      });
      const data: any = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.message || data?.hint || data?.error || `sync_${response.status}`);
      if (data?.result && row.operation_type === 'sale' && outbound.invoice_number) {
        const local = await db.sales.where('invoice_no').equals(outbound.invoice_number).first();
        if (local) await db.sales.update(local.id, { server_id: String(data.result) });
      }
      if (data?.result && row.operation_type === 'purchase' && outbound.invoice_number) {
        const local = await db.purchases.where('invoice_no').equals(outbound.invoice_number).first();
        if (local) await db.purchases.update(local.id, { server_id: String(data.result) });
      }
      await markOperationApplied(row.id, String(data?.result || ''));
      applied += 1;
    } catch (error) {
      await markOperationFailed(row.id, error, false);
      failed += 1;
    }
  }
  if (settings) await db.settings.update('settings', { last_sync_at: new Date().toISOString() });
  return { attempted: applied + failed, applied, failed };
}
export async function pullServerSnapshot(){
 if(!navigator.onLine)throw new Error('لا يوجد اتصال لتنزيل التحديثات.');
 if(await pendingSyncCount())throw new Error('يجب مزامنة العمليات المحلية أولاً قبل تنزيل بيانات الخادم.');
 const settings:any=await db.settings.get('settings');if(!planAllows(String(settings?.plan_code||'basic'),'sync'))throw new Error('المزامنة السحابية غير متاحة في خطة الاشتراك الحالية.');const endpoint=String(settings?.supabase_url||'').replace(/\/+$/,''),anonKey=String(settings?.supabase_anon_key||''),token=await getValidAccessToken();if(!endpoint||!anonKey||!token)throw new Error('جلسة Supabase غير متاحة.');
 const response=await fetch(`${endpoint}/rest/v1/rpc/get_sync_snapshot`,{method:'POST',headers:{'content-type':'application/json',apikey:anonKey,authorization:`Bearer ${token}`},body:JSON.stringify({p_since:settings?.last_pull_at||null})});const data:any=await response.json().catch(()=>null);if(!response.ok)throw new Error(data?.message||'تعذر تنزيل بيانات الخادم.');const pharmacy_id=getPharmacyId(),time=now();
 await (db.transaction as any)('rw',[db.products,db.product_variants,db.batches,db.serial_numbers,db.customers,db.suppliers,db.branches,db.sales,db.sale_items,db.purchases,db.purchase_items,db.settings],async()=>{
  if(data.business)await db.settings.update('settings',{business_name:data.business.name,pharmacy_name:data.business.name,business_type:data.business.business_type_id,updated_at:time});
  if(Array.isArray(data.products))await db.products.bulkPut(data.products.map((p:any)=>({id:p.id,pharmacy_id,created_at:p.created_at||time,updated_at:p.updated_at||time,arabic_name:p.name,barcode:p.base_barcode||undefined,sku:p.sku||undefined,category:p.category_id||undefined,brand:p.brand_id||undefined,unit:p.unit_id||undefined,purchase_price:Number(p.purchase_price||0),selling_price:Number(p.sale_price||0),wholesale_price:p.wholesale_price==null?undefined:Number(p.wholesale_price),reorder_level:Number(p.minimum_stock||0),maximum_stock:p.maximum_stock==null?undefined:Number(p.maximum_stock),tax:Number(p.tax_rate||0),active:p.is_active!==false,attributes:p.attributes||{}})));
  if(Array.isArray(data.variants))await db.product_variants.bulkPut(data.variants.map((v:any)=>({id:v.id,pharmacy_id,product_id:v.product_id,name:Object.values(v.attributes||{}).join(' / ')||v.sku||'متغير',sku:v.sku||undefined,barcode:v.barcode||undefined,attributes:v.attributes||{},quantity:0,purchase_price:Number(v.purchase_price||0),selling_price:Number(v.sale_price||0),active:v.is_active!==false,created_at:v.created_at||time,updated_at:v.updated_at||time})));
  if(Array.isArray(data.batches))await db.batches.bulkPut(data.batches.map((b:any)=>({id:b.id,pharmacy_id,product_id:b.product_id,variant_id:b.variant_id||undefined,batch_number:b.batch_number||b.id,expiry_date:b.expiry_date||undefined,quantity:Number(b.quantity||0),initial_quantity:Number(b.quantity||0),purchase_price:Number(b.purchase_price||0),selling_price:0,created_at:b.created_at||time,updated_at:b.updated_at||time})));
  if(Array.isArray(data.serials))await db.serial_numbers.bulkPut(data.serials.map((s:any)=>({id:s.id,pharmacy_id,product_id:s.product_id,variant_id:s.variant_id||undefined,serial_number:s.serial_number,imei:s.imei||undefined,warranty_start:s.warranty_start||undefined,warranty_end:s.warranty_end||undefined,status:s.status,created_at:s.created_at||time,updated_at:time})));
  if(Array.isArray(data.customers))await db.customers.bulkPut(data.customers.map((c:any)=>({id:c.id,pharmacy_id,name:c.name,phone:c.phone||undefined,email:c.email||undefined,address:c.address||undefined,balance:Number(c.balance||0),created_at:c.created_at||time,updated_at:c.updated_at||time})));
  if(Array.isArray(data.suppliers))await db.suppliers.bulkPut(data.suppliers.map((c:any)=>({id:c.id,pharmacy_id,name:c.name,company:c.company||undefined,phone:c.phone||undefined,email:c.email||undefined,address:c.address||undefined,balance:Number(c.balance||0),created_at:c.created_at||time,updated_at:c.updated_at||time})));
  if(Array.isArray(data.branches)){await db.branches.bulkPut(data.branches.map((b:any)=>({id:b.id,pharmacy_id,name:b.name,code:b.code||b.id,address:b.address||undefined,active:b.is_active!==false,created_at:b.created_at||time,updated_at:b.updated_at||time})));const current=await db.settings.get('settings');if(data.branches.length&&!data.branches.some((b:any)=>b.id===current?.branch_id)){const main=data.branches.find((b:any)=>b.code==='MAIN')||data.branches[0];await db.settings.update('settings',{branch_id:main.id,updated_at:time});}}
  const saleIds=new Map<string,string>();
  for(const remote of Array.isArray(data.sales)?data.sales:[]){
   const existing=await db.sales.where('invoice_no').equals(remote.invoice_number).first();
   const localId=existing?.id||remote.id;saleIds.set(remote.id,localId);
   const status=String(remote.status||'completed').toUpperCase();
   await db.sales.put({id:localId,server_id:remote.id,pharmacy_id,branch_id:remote.branch_id||undefined,invoice_no:remote.invoice_number,customer_id:remote.customer_id||undefined,cashier_id:remote.cashier_id||existing?.cashier_id||'remote',subtotal:Number(remote.subtotal||0),discount:Number(remote.discount||0),tax:Number(remote.tax||0),total:Number(remote.total||0),paid:Number(remote.paid||0),remaining:Number(remote.remaining||0),payment_method:remote.payment_method||'Cash',profit:existing?.profit??Number(remote.metadata?.profit||0),status,created_at:remote.created_at||time,updated_at:remote.updated_at||remote.created_at||time});
  }
  for(const remote of Array.isArray(data.sale_items)?data.sale_items:[]){
   const saleId=saleIds.get(remote.sale_id)||remote.sale_id;
   const existing=await db.sale_items.where('sale_id').equals(saleId).filter((item)=>item.product_id===remote.product_id&&item.batch_id===(remote.batch_id||item.batch_id)).first();
   const cost=Number(remote.cost_total||0),lineTotal=Number(remote.total||0);
   await db.sale_items.put({id:existing?.id||remote.id,pharmacy_id,sale_id:saleId,product_id:remote.product_id,variant_id:remote.variant_id||undefined,serial_id:remote.serial_id||undefined,batch_id:remote.batch_id||existing?.batch_id||'',quantity:Number(remote.quantity||0),unit_price:Number(remote.unit_price||0),discount:Number(remote.discount||0),tax:Number(remote.tax||0),line_total:lineTotal,cost,profit:lineTotal-cost,activity_data:remote.activity_data||{},created_at:remote.created_at||time,updated_at:remote.updated_at||remote.created_at||time});
  }
  const purchaseIds=new Map<string,string>();
  for(const remote of Array.isArray(data.purchases)?data.purchases:[]){
   const existing=await db.purchases.where('invoice_no').equals(remote.invoice_number).first();
   const localId=existing?.id||remote.id;purchaseIds.set(remote.id,localId);
   const status=String(remote.status||'received').toUpperCase()==='RECEIVED'?'POSTED':String(remote.status||'received').toUpperCase();
   await db.purchases.put({id:localId,server_id:remote.id,pharmacy_id,branch_id:remote.branch_id||undefined,invoice_no:remote.invoice_number,supplier_id:remote.supplier_id||undefined,date:String(remote.created_at||time).slice(0,10),subtotal:Number(remote.subtotal||0),discount:Number(remote.discount||0),tax:Number(remote.tax||0),total:Number(remote.total||0),paid:Number(remote.paid||0),remaining:Number(remote.remaining||0),status,created_at:remote.created_at||time,updated_at:remote.updated_at||remote.created_at||time});
  }
  for(const remote of Array.isArray(data.purchase_items)?data.purchase_items:[]){
   const purchaseId=purchaseIds.get(remote.purchase_id)||remote.purchase_id;
   const existing=await db.purchase_items.where('purchase_id').equals(purchaseId).filter((item)=>item.product_id===remote.product_id&&item.batch_id===(remote.batch_id||item.batch_id)).first();
   await db.purchase_items.put({id:existing?.id||remote.id,pharmacy_id,purchase_id:purchaseId,product_id:remote.product_id,variant_id:remote.variant_id||undefined,serial_id:remote.serial_id||undefined,batch_id:remote.batch_id||existing?.batch_id||'',quantity:Number(remote.quantity||0),purchase_price:Number(remote.unit_cost||0),selling_price:existing?.selling_price??Number(remote.unit_cost||0),discount:Number(remote.discount||0),tax:Number(remote.tax||0),line_total:Number(remote.total||0),created_at:remote.created_at||time,updated_at:remote.updated_at||remote.created_at||time});
  }
  await db.settings.update('settings',{last_pull_at:data.server_time||time,last_sync_at:time});
 });
 return {server_time:data.server_time,downloaded:{products:data.products?.length||0,variants:data.variants?.length||0,batches:data.batches?.length||0,serials:data.serials?.length||0,customers:data.customers?.length||0,suppliers:data.suppliers?.length||0,sales:data.sales?.length||0,purchases:data.purchases?.length||0}};
}
