-- Restrictive policies are ANDed with tenant policies, so direct REST calls
-- cannot bypass paid feature entitlements by unhiding frontend controls.

alter table public.sync_operations enable row level security;
drop policy if exists plan_sync_operations on public.sync_operations;
create policy plan_sync_operations on public.sync_operations as restrictive
for all to authenticated
using (public.app_has_feature('sync'))
with check (public.app_has_feature('sync'));

alter table public.accounts enable row level security;
alter table public.journal_entries enable row level security;
alter table public.journal_lines enable row level security;
drop policy if exists plan_accounts on public.accounts;
drop policy if exists plan_journal_entries on public.journal_entries;
drop policy if exists plan_journal_lines on public.journal_lines;
create policy plan_accounts on public.accounts as restrictive for all to authenticated
using (public.app_has_feature('accounting')) with check (public.app_has_feature('accounting'));
create policy plan_journal_entries on public.journal_entries as restrictive for all to authenticated
using (public.app_has_feature('accounting')) with check (public.app_has_feature('accounting'));
create policy plan_journal_lines on public.journal_lines as restrictive for all to authenticated
using (public.app_has_feature('accounting')) with check (public.app_has_feature('accounting'));

alter table public.stock_transfers enable row level security;
alter table public.stock_transfer_items enable row level security;
drop policy if exists plan_stock_transfers on public.stock_transfers;
drop policy if exists plan_stock_transfer_items on public.stock_transfer_items;
create policy plan_stock_transfers on public.stock_transfers as restrictive for all to authenticated
using (public.app_has_feature('multi_branch')) with check (public.app_has_feature('multi_branch'));
create policy plan_stock_transfer_items on public.stock_transfer_items as restrictive for all to authenticated
using (public.app_has_feature('multi_branch')) with check (public.app_has_feature('multi_branch'));

alter table public.warranties enable row level security;
alter table public.warranty_tickets enable row level security;
drop policy if exists plan_warranties on public.warranties;
drop policy if exists plan_warranty_tickets on public.warranty_tickets;
create policy plan_warranties on public.warranties as restrictive for all to authenticated
using (public.app_has_feature('warranty')) with check (public.app_has_feature('warranty'));
create policy plan_warranty_tickets on public.warranty_tickets as restrictive for all to authenticated
using (public.app_has_feature('warranty')) with check (public.app_has_feature('warranty'));