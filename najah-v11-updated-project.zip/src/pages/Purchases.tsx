import { useLiveQuery } from 'dexie-react-hooks';
import { useState } from 'react';
import { db } from '../services/db';
import { cancelPurchase, postPurchase } from '../services/purchases';
import type { User } from '../types/models';
import { money } from '../utils/ids';
import { getBusinessContext } from '../services/businessContext';
import ActionDialog from '../components/ActionDialog';
import { roundMoney } from '../domain/calculations';

export default function Purchases({ user }: { user: User }) {
  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const variants = useLiveQuery(() => db.product_variants.toArray(), []) || [];
  const suppliers = useLiveQuery(() => db.suppliers.toArray(), []) || [];
  const purchases = useLiveQuery(async () =>
    (await db.purchases.toArray()).sort((a, b) =>
      String(b.created_at || b.date).localeCompare(String(a.created_at || a.date))), []) || [];
  const activity = useLiveQuery(getBusinessContext, []) || null;
  const [form, setForm] = useState<any>({ invoice_no: '', paid: 0, quantity: 1, discount: 0, tax: 0 });
  const [message, setMessage] = useState('');
  const [cancelId, setCancelId] = useState('');
  const set = (key: string, value: string | number) =>
    setForm((current: any) => ({ ...current, [key]: value }));
  const productVariants = variants.filter((variant) => variant.product_id === form.product_id && variant.active);
  const tracked = Boolean(activity?.supportsSerials || activity?.supportsImei);
  const quantity = Number(form.quantity || 0), cost = Number(form.purchase_price || 0);
  const discount = Number(form.discount || 0), taxRate = Number(form.tax || 0);
  const subtotal = roundMoney(quantity * cost);
  const total = roundMoney(Math.max(0, subtotal - discount) * (1 + Math.max(0, taxRate) / 100));

  function parseSerials() {
    if (!tracked) return undefined;
    return String(form.serials || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => {
      const [serial_number, imei, warranty_end] = line.split(/[,;\t]/).map((value) => value.trim());
      return { serial_number, imei: imei || undefined, warranty_end: warranty_end || undefined };
    });
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setMessage('');
    try {
      await postPurchase(user.id, form.supplier_id || undefined,
        form.invoice_no || `P-${Date.now()}`, Number(form.paid), [{
          product_id: form.product_id, variant_id: form.variant_id || undefined,
          batch_number: form.batch_number, quantity, purchase_price: cost,
          selling_price: Number(form.selling_price), expiry_date: form.expiry_date,
          discount, tax: taxRate, serials: parseSerials(),
        }]);
      setForm({ paid: 0, quantity: 1, discount: 0, tax: 0 });
      setMessage('تم ترحيل فاتورة الشراء وتحديث المخزون والحسابات.');
    } catch (error: any) {
      setMessage(error?.message || 'تعذر ترحيل الشراء.');
    }
  }

  return (
    <section>
      <div className="section-heading"><div>
        <h1>{activity?.purchaseLabel || 'المشتريات'}</h1>
        <p className="muted">شراء وتكلفة {activity?.label || 'النشاط'} مع تحديث المخزون ورصيد المورد.</p>
      </div></div>
      {message && <div className="alert">{message}</div>}
      <form className="card formgrid" onSubmit={save}>
        <select value={form.supplier_id || ''} onChange={(event) => set('supplier_id', event.target.value)}>
          <option value="">شراء نقدي دون مورد محدد</option>
          {suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
        </select>
        <select required value={form.product_id || ''} onChange={(event) => {
          setForm((current: any) => ({ ...current, product_id: event.target.value, variant_id: '' }));
        }}>
          <option value="">اختر المنتج</option>
          {products.map((product) => <option key={product.id} value={product.id}>{product.arabic_name}</option>)}
        </select>
        {productVariants.length > 0 && <select required value={form.variant_id || ''} onChange={(event) => set('variant_id', event.target.value)}>
          <option value="">اختر المتغير/المقاس/اللون</option>
          {productVariants.map((variant) => <option key={variant.id} value={variant.id}>{variant.name}</option>)}
        </select>}
        <input value={form.invoice_no || ''} onChange={(event) => set('invoice_no', event.target.value)} placeholder="رقم فاتورة الشراء" />
        <input required value={form.batch_number || ''} onChange={(event) => set('batch_number', event.target.value)}
          placeholder={activity?.supportsExpiry ? 'رقم التشغيلة' : 'رقم الدفعة / المرجع'} />
        <input required type="number" min={activity?.inventoryRules.allowFractional ? 0.001 : 1}
          step={activity?.inventoryRules.allowFractional ? 0.001 : 1}
          value={form.quantity || ''} onChange={(event) => set('quantity', event.target.value)} placeholder="الكمية" />
        <input required type="number" min="0" step="0.01" value={form.purchase_price || ''}
          onChange={(event) => set('purchase_price', event.target.value)} placeholder="سعر الشراء" />
        <input required type="number" min="0" step="0.01" value={form.selling_price || ''}
          onChange={(event) => set('selling_price', event.target.value)} placeholder="سعر البيع" />
        {activity?.supportsExpiry && <input required={activity.inventoryRules.requireExpiry} type="date"
          value={form.expiry_date || ''} onChange={(event) => set('expiry_date', event.target.value)} />}
        <input type="number" min="0" max={subtotal} step="0.01" value={form.discount || ''}
          onChange={(event) => set('discount', event.target.value)} placeholder="الخصم" />
        <input type="number" min="0" max="100" step="0.01" value={form.tax || ''}
          onChange={(event) => set('tax', event.target.value)} placeholder="نسبة الضريبة %" />
        {tracked && <textarea required rows={5} value={form.serials || ''} onChange={(event) => set('serials', event.target.value)}
          placeholder={activity?.supportsImei
            ? 'كل جهاز في سطر: Serial, IMEI, WarrantyEnd (اختياري)'
            : 'كل رقم تسلسلي في سطر: Serial, IMEI اختياري, WarrantyEnd اختياري'} />}
        <div className="invoice-summary">
          <p>الفرعي: {money(subtotal)}</p><p>الخصم: {money(discount)}</p><p>الإجمالي: {money(total)}</p>
        </div>
        <div className="payment-row">
          <input type="number" min="0" max={total} step="0.01" value={form.paid || ''}
            onChange={(event) => set('paid', event.target.value)} placeholder="المبلغ المدفوع" />
          <button type="button" onClick={() => set('paid', total)}>دفع الإجمالي</button>
        </div>
        <button className="primary">ترحيل فاتورة الشراء</button>
      </form>
      <div className="card">
        <table><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الإجمالي</th><th>المتبقي</th><th>الحالة</th><th>إجراء</th></tr></thead>
          <tbody>{purchases.map((purchase) => <tr key={purchase.id}>
            <td>{purchase.invoice_no}</td><td>{purchase.date || purchase.created_at}</td>
            <td>{money(purchase.total)}</td><td>{money(purchase.remaining)}</td><td>{purchase.status}</td>
            <td>{purchase.status === 'POSTED' && <button className="danger" onClick={() => setCancelId(purchase.id)}>إلغاء</button>}</td>
          </tr>)}</tbody></table>
        {!purchases.length && <p className="empty">لا توجد مشتريات بعد.</p>}
      </div>
      <ActionDialog open={!!cancelId} title="إلغاء فاتورة الشراء" danger onClose={() => setCancelId('')}
        onConfirm={async (reason) => {
          await cancelPurchase(user.id, cancelId, reason);
          setCancelId('');
          setMessage('تم إلغاء فاتورة الشراء وعكس المخزون والقيد المحاسبي.');
        }} />
    </section>
  );
}