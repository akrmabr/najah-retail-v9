import { db, getPharmacyId } from './db'; import { signInRemote, clearRemoteSession } from './remoteAuth'; import type {Role,User} from '../types/models'; import { now, uid } from '../utils/ids'; import { audit } from './audit';
const enc=new TextEncoder();
async function derive(value:string,salt:string){ const key=await crypto.subtle.importKey('raw',enc.encode(value),{name:'PBKDF2'},false,['deriveBits']); const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(salt),iterations:120000,hash:'SHA-256'},key,256); return Array.from(new Uint8Array(bits)).map(b=>b.toString(16).padStart(2,'0')).join(''); }
async function legacyDigest(value:string,salt:string){ const hash=await crypto.subtle.digest('SHA-256',enc.encode(`${salt}:${value}`)); return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join(''); }
export async function hashPassword(v:string){ const salt=crypto.randomUUID(); return `pbkdf2:${salt}:${await derive(v,salt)}`; }
export async function verify(v:string, stored:string){ const parts=String(stored||'').split(':'); if(parts[0]==='pbkdf2'&&parts.length===3) return (await derive(v,parts[1]))===parts[2]; if(parts.length===2) return (await legacyDigest(v,parts[0]))===parts[1]; return false; }
export async function ensureOwner(){ const pharmacy_id=getPharmacyId(); const count=await db.users.count(); if(count===0){ const u:User={id:uid('user'),pharmacy_id,created_at:now(),updated_at:now(),name:'مدير النظام',email:'owner@local',username:'owner',password_hash:await hashPassword('ChangeMe123!'),role:'OWNER',active:true}; await db.users.add(u); await audit(u.id,'user_creation','users',u.id,'Initial local owner created; change password immediately.'); }}
export async function login(username:string,password:string){ const u=await db.users.where('username').equals(username).or('email').equals(username).first(); if(!u||!u.active||!(await verify(password,u.password_hash))) throw new Error('بيانات الدخول غير صحيحة'); if(navigator.onLine){ try{ await signInRemote(u.email,password); }catch(error){ if(String(import.meta.env.VITE_SUPABASE_ANON_KEY||'')) throw error; } } localStorage.setItem('alshifaa_session',JSON.stringify({userId:u.id,ts:Date.now()})); await db.users.update(u.id,{last_login:now(),updated_at:now()}); await audit(u.id,'login','users',u.id); return u; }
export async function currentUser(){
 const raw=localStorage.getItem('alshifaa_session');
 if(!raw) return null;
 try {
  const s=JSON.parse(raw);
  if(!s?.userId||!Number.isFinite(Number(s.ts))) return null;
  const settings=await db.settings.get('settings');
  const timeout=Number(settings?.session_timeout_minutes||30)*60*1000;
  if(Date.now()-Number(s.ts)>timeout){ logout(); return null; }
  const user=await db.users.get(s.userId);
  if(!user?.active){ logout(); return null; }
  return user;
 } catch { logout(); return null; }
}
export function logout(){localStorage.removeItem('alshifaa_session'); void clearRemoteSession()}
export const permissions:Record<Role,string[]>={OWNER:['*'],ADMIN:['*'],PHARMACIST:['dashboard','pos','products','inventory','customers','reports'],CASHIER:['dashboard','pos','customers'],INVENTORY:['dashboard','products','inventory','purchases','suppliers','reports'],ACCOUNTANT:['dashboard','expenses','payments','reports','customers','suppliers'],VIEWER:['dashboard','reports']};
export function can(user:User|Role|undefined,area:string){
 if(!user) return false;
 const role=typeof user==='string'?user:user.role;
 if(role==='OWNER'||role==='ADMIN') return true;
 if(typeof user!=='string'&&user.permissions?.includes('*')) return true;
 if(typeof user!=='string'&&user.permissions) return user.permissions.includes(area);
 return permissions[role]?.includes(area) || false;
}
export const permissionOptions=[
 {id:'dashboard',label:'لوحة التحكم'},{id:'pos',label:'نقطة البيع'},{id:'sales',label:'سجل المبيعات'},
 {id:'products',label:'المنتجات'},{id:'inventory',label:'المخزون'},{id:'purchases',label:'المشتريات'},
 {id:'customers',label:'العملاء'},{id:'suppliers',label:'الموردون'},{id:'returns',label:'المرتجعات'},
 {id:'expenses',label:'المصروفات'},{id:'payments',label:'المدفوعات'},{id:'reports',label:'التقارير'},
 {id:'users',label:'المستخدمون'},{id:'settings',label:'الإعدادات'},{id:'license',label:'الترخيص'},{id:'backup',label:'النسخ الاحتياطي'}
];
export const roleLabels:Record<Role,string>={OWNER:'مالك النظام',ADMIN:'مدير',PHARMACIST:'صيدلي',CASHIER:'كاشير',INVENTORY:'مسؤول مخزون',ACCOUNTANT:'محاسب',VIEWER:'مشاهد'};
export async function createUser(actor:User,input:{name:string;email:string;username:string;password:string;role:Role;permissions:string[]}){
 if(!can(actor,'users')) throw new Error('ليس لديك صلاحية إدارة المستخدمين.');
 if(!input.name.trim()||!input.email.trim()||!input.username.trim()) throw new Error('أكمل بيانات المستخدم.');
 if(input.password.length<8) throw new Error('كلمة المرور يجب ألا تقل عن 8 أحرف.');
 if(input.role==='OWNER') throw new Error('لا يمكن إنشاء مالك نظام إضافي.');
 if(input.role==='ADMIN'&&actor.role!=='OWNER') throw new Error('إنشاء حساب مدير متاح لمالك النظام فقط.');
 const username=input.username.trim(), email=input.email.trim(), existing=await db.users.toArray();
 if(existing.some(u=>u.username.toLowerCase()===username.toLowerCase()||u.email.toLowerCase()===email.toLowerCase())) throw new Error('اسم المستخدم أو البريد مستخدم مسبقاً.');
 const u:User={id:uid('user'),pharmacy_id:actor.pharmacy_id,created_at:now(),updated_at:now(),name:input.name.trim(),email,username,password_hash:await hashPassword(input.password),role:input.role,permissions:input.role==='ADMIN'?['*']:[...new Set(input.permissions)],active:true};
 await db.transaction('rw',db.users,db.audit_logs,async()=>{await db.users.add(u);await audit(actor.id,'إنشاء مستخدم','users',u.id,{name:u.name,username:u.username,role:u.role,permissions:u.permissions});});
 return u;
}
export async function setUserActive(actor:User,target:User,active:boolean){
 if(!can(actor,'users')) throw new Error('ليس لديك صلاحية إدارة المستخدمين.');
 if(target.id===actor.id) throw new Error('لا يمكنك إيقاف حسابك أثناء تسجيل الدخول.');
 if(target.role==='OWNER') throw new Error('لا يمكن إيقاف حساب مالك النظام.');
 if(target.role==='ADMIN'&&actor.role!=='OWNER') throw new Error('إيقاف حساب المدير متاح لمالك النظام فقط.');
 await db.users.update(target.id,{active,updated_at:now()}); await audit(actor.id,active?'تفعيل مستخدم':'إيقاف مستخدم','users',target.id,{active});
}

export async function usersCount(){ return db.users.count(); }
export async function createInitialOwner(input:{pharmacyName:string; ownerName:string; email:string; phone?:string; password:string; businessType?:string}){
 if(!input.pharmacyName.trim()||!input.ownerName.trim()||!input.email.trim()) throw new Error('أكمل بيانات النشاط والمالك.');
 const existing=await db.users.count(); if(existing>0) throw new Error('تم إعداد حساب المالك مسبقاً');
 const pharmacy_id=getPharmacyId();
 const u:User={id:uid('user'),pharmacy_id,created_at:now(),updated_at:now(),name:input.ownerName,email:input.email,username:input.email,password_hash:await hashPassword(input.password),role:'OWNER',active:true};
  await db.transaction('rw',db.users,db.settings,db.audit_logs,async()=>{
  await db.users.add(u);
  await db.settings.update('settings',{pharmacy_name:input.pharmacyName,business_name:input.pharmacyName,business_type:input.businessType||'general',email:input.email,phone:input.phone||'',updated_at:now()});
  await audit(u.id,'إنشاء حساب المالك','users',u.id,{businessName:input.pharmacyName,businessType:input.businessType||'general',email:input.email});
 });
 localStorage.setItem('alshifaa_setup_completed','true');
 localStorage.setItem('alshifaa_session',JSON.stringify({userId:u.id,ts:Date.now()}));
 return u;
}
