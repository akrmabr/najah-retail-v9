export const PLAN_FEATURES: Record<string, Set<string>> = {
  basic: new Set(['pos', 'inventory', 'reports', 'backup']),
  professional: new Set(['pos', 'inventory', 'reports', 'backup', 'sync', 'promotions', 'loyalty']),
  business: new Set(['pos', 'inventory', 'reports', 'backup', 'sync', 'promotions', 'loyalty', 'accounting', 'multi_branch', 'warranty']),
  enterprise: new Set(['*']),
};
export const PLAN_LIMITS:Record<string,{branches:number;users:number;devices:number}>={
 basic:{branches:1,users:3,devices:1},professional:{branches:2,users:10,devices:3},
 business:{branches:10,users:50,devices:20},enterprise:{branches:999,users:999,devices:999},
};

const areaFeature: Record<string, string> = {
  dashboard: 'reports', search: 'inventory', notifications: 'inventory',
  pos: 'pos', sales: 'pos', returns: 'pos', cash: 'pos',
  products: 'inventory', inventory: 'inventory', serials: 'inventory',
  purchases: 'inventory', customers: 'pos', suppliers: 'inventory',
  expenses: 'accounting', payments: 'accounting', accounting: 'accounting',
  branches:'multi_branch',
  reports: 'reports', backup: 'backup', sync: 'sync', warranty: 'warranty',
};

export function planAllows(planCode: string | undefined, area: string) {
  if (['users', 'settings', 'license', 'help'].includes(area)) return true;
  const features = PLAN_FEATURES[planCode || 'basic'] || PLAN_FEATURES.basic;
  const feature = areaFeature[area] || area;
  return features.has('*') || features.has(feature);
}