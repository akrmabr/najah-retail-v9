import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    sourcemap: true,
    rollupOptions: {
      input: {
        app: 'index.html',
        owner: 'owner.html',
      },
    },
  },
});