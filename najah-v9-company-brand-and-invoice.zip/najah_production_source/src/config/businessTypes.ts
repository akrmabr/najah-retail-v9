export type BusinessTypeId =
  | 'clothing' | 'shoes' | 'homeware' | 'cosmetics' | 'grocery'
  | 'supermarket' | 'building_materials' | 'electrical' | 'electronics'
  | 'mobile' | 'furniture' | 'home_furnishings' | 'hardware' | 'stationery'
  | 'perfume' | 'pharmacy' | 'spare_parts' | 'car_accessories' | 'general' | 'other';

export type BusinessField =
  | 'brand' | 'model' | 'size' | 'color' | 'gender' | 'material' | 'fabric'
  | 'season' | 'style' | 'shade' | 'weight' | 'unit' | 'pack' | 'carton'
  | 'batch_number' | 'expiry_date' | 'serial_number' | 'imei' | 'warranty'
  | 'warranty_start' | 'warranty_end' | 'voltage' | 'power' | 'dimensions'
  | 'length' | 'width' | 'height' | 'scientific_name' | 'dosage' | 'form'
  | 'prescription_required' | 'manufacturer' | 'vehicle' | 'year' | 'part_number'
  | 'tool_type' | 'fragrance_family' | 'pattern' | 'pieces' | 'set';

export type BusinessTypeConfig = {
  id: BusinessTypeId;
  label: string;
  productLabel: string;
  inventoryLabel: string;
  purchaseLabel: string;
  reportLabel: string;
  fields: BusinessField[];
  units: string[];
  variants: BusinessField[];
  supportsExpiry?: boolean;
  supportsSerials?: boolean;
  supportsImei?: boolean;
};

const common = {
  general: ['قطعة', 'عبوة', 'كرتون'],
  clothing: ['قطعة', 'طقم'],
  pharmacy: ['قرص', 'علبة', 'زجاجة', 'أنبوب', 'حقنة', 'كرتون'],
  weight: ['قطعة', 'كجم', 'جرام', 'لتر', 'مل', 'عبوة', 'كرتون'],
  building: ['قطعة', 'متر', 'متر مربع', 'متر مكعب', 'كجم', 'طن', 'كيس', 'كرتون'],
} as const;

export const BUSINESS_TYPES: Record<BusinessTypeId, BusinessTypeConfig> = {
  clothing: { id: 'clothing', label: 'محل ملابس', productLabel: 'الملابس', inventoryLabel: 'مخزون الملابس', purchaseLabel: 'مشتريات الملابس', reportLabel: 'تقارير المقاسات والمبيعات', fields: ['size','color','gender','brand','fabric','season','style'], units: [...common.clothing], variants: ['size','color'] },
  shoes: { id: 'shoes', label: 'محل أحذية', productLabel: 'الأحذية', inventoryLabel: 'مخزون الأحذية', purchaseLabel: 'مشتريات الأحذية', reportLabel: 'تقارير المقاسات والمبيعات', fields: ['size','color','gender','brand','material','style'], units: ['زوج','قطعة'], variants: ['size','color'] },
  homeware: { id: 'homeware', label: 'محل أواني منزلية', productLabel: 'الأواني المنزلية', inventoryLabel: 'مخزون الأواني', purchaseLabel: 'مشتريات الأواني', reportLabel: 'تقارير الأواني والأطقم', fields: ['material','size','color','brand','pieces','set','weight'], units: ['قطعة','طقم','كرتون'], variants: ['size','color'] },
  cosmetics: { id: 'cosmetics', label: 'مستحضرات تجميل', productLabel: 'المستحضرات', inventoryLabel: 'مخزون المستحضرات', purchaseLabel: 'مشتريات المستحضرات', reportLabel: 'تقارير العلامات والصلاحية', fields: ['brand','shade','size','batch_number','expiry_date'], units: [...common.general], variants: ['shade','size'], supportsExpiry: true },
  grocery: { id: 'grocery', label: 'بقالة / مواد غذائية', productLabel: 'المواد الغذائية', inventoryLabel: 'مخزون المواد الغذائية', purchaseLabel: 'مشتريات المواد الغذائية', reportLabel: 'تقارير الأصناف والصلاحية', fields: ['unit','weight','pack','carton','batch_number','expiry_date'], units: [...common.weight], variants: [], supportsExpiry: true },
  supermarket: { id: 'supermarket', label: 'سوبر ماركت', productLabel: 'أصناف السوبر ماركت', inventoryLabel: 'مخزون السوبر ماركت', purchaseLabel: 'مشتريات السوبر ماركت', reportLabel: 'تقارير الأقسام والمبيعات', fields: ['unit','weight','pack','carton','batch_number','expiry_date'], units: [...common.weight], variants: [], supportsExpiry: true },
  building_materials: { id: 'building_materials', label: 'محل مواد بناء', productLabel: 'مواد البناء', inventoryLabel: 'مخزون مواد البناء', purchaseLabel: 'مشتريات مواد البناء', reportLabel: 'تقارير الوحدات والكميات', fields: ['material','unit','weight','length','width','height','brand'], units: [...common.building], variants: [] },
  electrical: { id: 'electrical', label: 'أجهزة كهربائية', productLabel: 'الأجهزة الكهربائية', inventoryLabel: 'مخزون الأجهزة والضمان', purchaseLabel: 'مشتريات الأجهزة', reportLabel: 'تقارير الضمان والأرقام التسلسلية', fields: ['brand','model','serial_number','warranty','warranty_start','warranty_end','voltage','power','color'], units: ['قطعة','كرتون'], variants: ['color'], supportsSerials: true },
  electronics: { id: 'electronics', label: 'محل إلكترونيات', productLabel: 'الإلكترونيات', inventoryLabel: 'مخزون الإلكترونيات', purchaseLabel: 'مشتريات الإلكترونيات', reportLabel: 'تقارير الموديلات والضمان', fields: ['brand','model','serial_number','warranty','color'], units: ['قطعة','كرتون'], variants: ['color'], supportsSerials: true },
  mobile: { id: 'mobile', label: 'هواتف وإكسسوارات', productLabel: 'الهواتف والإكسسوارات', inventoryLabel: 'مخزون الهواتف وIMEI', purchaseLabel: 'مشتريات الهواتف', reportLabel: 'تقارير IMEI والضمان', fields: ['brand','model','size','color','imei','serial_number','warranty'], units: ['جهاز','قطعة','كرتون'], variants: ['size','color'], supportsSerials: true, supportsImei: true },
  furniture: { id: 'furniture', label: 'محل أثاث', productLabel: 'الأثاث', inventoryLabel: 'مخزون الأثاث', purchaseLabel: 'مشتريات الأثاث', reportLabel: 'تقارير الموديلات والأبعاد', fields: ['material','color','dimensions','brand'], units: ['قطعة','طقم','كرتون'], variants: ['color','dimensions'] },
  home_furnishings: { id: 'home_furnishings', label: 'مفروشات منزلية', productLabel: 'المفروشات', inventoryLabel: 'مخزون المفروشات', purchaseLabel: 'مشتريات المفروشات', reportLabel: 'تقارير المقاسات والألوان', fields: ['size','color','material','pattern','brand'], units: ['قطعة','متر','طقم','كرتون'], variants: ['size','color'] },
  hardware: { id: 'hardware', label: 'العدد والأدوات', productLabel: 'العدد والأدوات', inventoryLabel: 'مخزون العدد والأدوات', purchaseLabel: 'مشتريات العدد والأدوات', reportLabel: 'تقارير الأدوات والماركات', fields: ['tool_type','material','size','brand'], units: ['قطعة','طقم','علبة','كرتون'], variants: [] },
  stationery: { id: 'stationery', label: 'مكتبة وقرطاسية', productLabel: 'الكتب والقرطاسية', inventoryLabel: 'مخزون المكتبة', purchaseLabel: 'مشتريات المكتبة', reportLabel: 'تقارير الكتب والقرطاسية', fields: ['brand','color','size'], units: ['قطعة','علبة','كرتون'], variants: ['color'] },
  perfume: { id: 'perfume', label: 'محل عطور', productLabel: 'العطور', inventoryLabel: 'مخزون العطور والصلاحية', purchaseLabel: 'مشتريات العطور', reportLabel: 'تقارير العطور والماركات', fields: ['brand','fragrance_family','size','batch_number','expiry_date'], units: ['زجاجة','عبوة','كرتون'], variants: ['size'], supportsExpiry: true },
  pharmacy: { id: 'pharmacy', label: 'صيدلية / مستلزمات طبية', productLabel: 'الأدوية والمستلزمات الطبية', inventoryLabel: 'مخزون الأدوية والصلاحية', purchaseLabel: 'المشتريات الدوائية', reportLabel: 'تقارير الأدوية والصلاحية', fields: ['scientific_name','dosage','form','manufacturer','batch_number','expiry_date','prescription_required'], units: [...common.pharmacy], variants: ['dosage','form','batch_number'], supportsExpiry: true },
  spare_parts: { id: 'spare_parts', label: 'محل قطع غيار', productLabel: 'قطع الغيار', inventoryLabel: 'مخزون قطع الغيار', purchaseLabel: 'مشتريات قطع الغيار', reportLabel: 'تقارير الموديلات والتوافق', fields: ['part_number','brand','model','vehicle','year','serial_number'], units: ['قطعة','طقم','كرتون'], variants: [], supportsSerials: true },
  car_accessories: { id: 'car_accessories', label: 'إكسسوارات سيارات', productLabel: 'إكسسوارات السيارات', inventoryLabel: 'مخزون إكسسوارات السيارات', purchaseLabel: 'مشتريات إكسسوارات السيارات', reportLabel: 'تقارير السيارات والموديلات', fields: ['model','color','vehicle','brand'], units: ['قطعة','طقم','كرتون'], variants: ['color'] },
  general: { id: 'general', label: 'تجارة عامة', productLabel: 'المنتجات', inventoryLabel: 'المخزون', purchaseLabel: 'المشتريات', reportLabel: 'التقارير العامة', fields: ['brand','model'], units: [...common.general], variants: [] },
  other: { id: 'other', label: 'نشاط آخر', productLabel: 'المنتجات', inventoryLabel: 'المخزون', purchaseLabel: 'المشتريات', reportLabel: 'التقارير', fields: ['brand','model'], units: [...common.general], variants: [] },
};

export const BUSINESS_TYPE_OPTIONS = Object.values(BUSINESS_TYPES);
export const getBusinessType = (id?: string | null) => BUSINESS_TYPES[(id as BusinessTypeId) || 'general'] || BUSINESS_TYPES.general;