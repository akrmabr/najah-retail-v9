const CACHE = 'najah-retail-shell-v11';
const SHELL = [
  './', './index.html', './owner.html', './manifest.webmanifest',
  './brand-logo.png', './icon-192.png', './icon-512.png',
];

async function precacheShell() {
  const cache = await caches.open(CACHE);
  await cache.addAll(SHELL);
  const response = await fetch('./index.html', { cache: 'no-store' });
  const html = await response.text();
  const assets = [...html.matchAll(/(?:src|href)=\"(\\.\\/assets\\/[^\"?]+)\"/g)].map((match) => match[1]);
  if (assets.length) await cache.addAll([...new Set(assets)]);
}
self.addEventListener('install', (event) => {
  event.waitUntil(precacheShell().then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) caches.open(CACHE).then((cache) => cache.put(request, response.clone()));
          return response;
        })
        .catch(async () => (await caches.match(request)) || (await caches.match('./index.html'))),
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request).then((response) => {
        if (response.ok) caches.open(CACHE).then((cache) => cache.put(request, response.clone()));
        return response;
      }).catch(() => cached || new Response('offline', { status: 503, statusText: 'Offline' }));
      return cached || network;
    }),
  );
});