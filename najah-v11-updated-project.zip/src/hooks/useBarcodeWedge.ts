import { useEffect, useRef } from 'react';

/**
 * USB and Bluetooth scanners usually behave like a fast keyboard and finish
 * with Enter. This listener works even when the POS search input lost focus.
 */
export function useBarcodeWedge(onCode: (code: string) => void) {
  const callback = useRef(onCode);
  callback.current = onCode;
  useEffect(() => {
    let buffer = '', last = 0;
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) return;
      const current = performance.now();
      if (current - last > 120) buffer = '';
      last = current;
      if (event.key === 'Enter') {
        const code = buffer.trim(); buffer = '';
        if (code.length >= 3) { event.preventDefault(); callback.current(code); }
        return;
      }
      if (event.key.length === 1 && !event.ctrlKey && !event.altKey && !event.metaKey) buffer += event.key;
    };
    addEventListener('keydown', handler);
    return () => removeEventListener('keydown', handler);
  }, []);
}